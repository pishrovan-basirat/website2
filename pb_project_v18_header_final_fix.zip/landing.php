<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

if (isLoggedIn()) {
    header('Location: home.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="پیشروان بصیرت؛ قرار روزانه مطالعه و معرفت‌افزایی برای برداشتن قدمی در مسیر زمینه‌سازی ظهور حضرت بقیه‌الله (عج)." />
    <title>پیشروان بصیرت | قرار روزانه</title>
    <link rel="stylesheet" href="assets/css/style.css?v=20261001-landing-v13" />
    <style>
        :root {
            --green-900: #0d5a3d;
            --green-800: #147241;
            --green-700: #1b8a52;
            --green-600: #24a76a;
            --green-100: #eaf8f0;
            --gold: #e5ae18;
            --gold-soft: #fff6d8;
            --ink: #18221d;
            --muted: #66746c;
            --surface: rgba(255,255,255,.88);
            --line: rgba(19, 78, 49, .12);
        }

        * { box-sizing: border-box; }
        html { scroll-behavior: smooth; }
        /* Landing page must not inherit the global site's flex-body layout.
           The shared style.css intentionally uses flex on body for app pages,
           but that makes the landing page children shrink to content width. */
        html,
        body.landing-page {
            width: 100%;
            max-width: 100%;
        }
        body.landing-page {
            display: block !important;
            margin: 0;
            min-height: 100vh;
            padding: 0 !important;
            align-items: initial !important;
            justify-content: initial !important;
            flex-direction: initial !important;
            font-family: 'Dana', -apple-system, BlinkMacSystemFont, sans-serif;
            color: var(--ink);
            background:
                radial-gradient(circle at 8% 8%, rgba(36,167,106,.13), transparent 28%),
                radial-gradient(circle at 92% 12%, rgba(229,174,24,.09), transparent 24%),
                linear-gradient(180deg, #f7fbf8 0%, #edf5f0 55%, #f7faf8 100%);
            overflow-x: hidden;
            position: relative;
        }

        a { color: inherit; }
        img { max-width: 100%; }
        body.landing-page > main {
            display: block;
            width: 100%;
            min-width: 0;
        }
        .landing-bg {
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: -1;
            background:
                linear-gradient(180deg, rgba(255,255,255,.18), rgba(255,255,255,0)),
                radial-gradient(circle at 50% 55%, rgba(36,167,106,.05), transparent 35%);
        }


        /* ===== منوی شیشه‌ای لندینگ ===== */
        .landing-glass-btn {
            position: fixed;
            top: 24px;
            width: 56px;
            height: 56px;
            border-radius: 18px;
            border: 1px solid rgba(0, 200, 100, .30);
            cursor: pointer;
            z-index: 1000;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, rgba(255,255,255,.85) 0%, rgba(0,255,136,.15) 50%, rgba(255,255,255,.70) 100%);
            backdrop-filter: blur(16px) saturate(170%);
            -webkit-backdrop-filter: blur(16px) saturate(170%);
            box-shadow: 0 8px 30px rgba(0,200,100,.28), 0 0 50px rgba(0,255,136,.15), inset 0 1px 1px rgba(255,255,255,.9), inset 0 -1px 1px rgba(0,255,136,.35);
            transition: transform .4s cubic-bezier(.34,1.56,.64,1), box-shadow .3s ease, border-color .3s ease;
            overflow: hidden;
            isolation: isolate;
            will-change: transform;
            -webkit-tap-highlight-color: transparent;
        }
        .landing-glass-btn::before {
            content:'';
            position:absolute;
            inset:-60%;
            z-index:-1;
            background: radial-gradient(circle at 30% 40%, rgba(0,255,136,.75), transparent 40%), radial-gradient(circle at 70% 60%, rgba(0,255,170,.5), transparent 42%), radial-gradient(circle at 50% 20%, rgba(255,255,255,.5), transparent 35%);
            filter:blur(14px);
            opacity:.85;
            animation: landingLiquidMove 9s ease-in-out infinite;
            animation-play-state:paused;
        }
        .landing-glass-btn:hover::before,
        .landing-glass-btn:focus-visible::before { animation-play-state:running; }
        .landing-glass-btn::after {
            content:'';
            position:absolute;
            top:2px;
            left:15%; right:15%; height:42%;
            border-radius:18px 18px 50% 50% / 18px 18px 30% 30%;
            background:linear-gradient(to bottom, rgba(255,255,255,.85), transparent);
            pointer-events:none;
            filter:blur(1px);
        }
        .landing-glass-btn:hover {
            transform:scale(1.08);
            border-color:rgba(0,200,100,.7);
            box-shadow:0 12px 40px rgba(0,200,100,.4), 0 0 70px rgba(0,255,136,.3), inset 0 1px 2px rgba(255,255,255,.95), inset 0 -1px 2px rgba(0,255,136,.5);
        }
        .landing-glass-btn:active { transform:scale(.96); }
        .landing-hamburger { right:24px; flex-direction:column; gap:6px; }
        .landing-user-btn { left:24px; }
        .landing-hamburger .line {
            display:block; width:26px; height:2.5px; border-radius:3px;
            background:#1b7a2e;
            box-shadow:0 0 6px rgba(0,200,100,.8), 0 0 12px rgba(0,255,136,.5);
            transition:transform .5s cubic-bezier(.68,-.55,.27,1.55), opacity .35s ease, width .4s ease;
            transform-origin:center; position:relative; z-index:2;
        }
        .landing-hamburger.active .line:nth-child(1){transform:translateY(8.5px) rotate(45deg);width:28px}
        .landing-hamburger.active .line:nth-child(2){opacity:0;transform:scaleX(0)}
        .landing-hamburger.active .line:nth-child(3){transform:translateY(-8.5px) rotate(-45deg);width:28px}
        .landing-user-btn svg {
            width:26px;height:26px;stroke:#1b7a2e;stroke-width:2.2;fill:none;stroke-linecap:round;stroke-linejoin:round;
            filter:drop-shadow(0 0 4px rgba(0,200,100,.7));
            transition:transform .4s cubic-bezier(.34,1.56,.64,1); position:relative; z-index:2;
        }
        .landing-user-btn:hover svg{transform:scale(1.1)}
        .landing-user-btn.active svg{transform:scale(.95)}
        .landing-glass-panel {
            position:fixed; top:96px; width:340px; max-width:calc(100vw - 48px); padding:22px; border-radius:28px; z-index:999;
            background:linear-gradient(135deg, rgba(255,255,255,.59) 0%, rgba(255,255,255,.45) 45%, rgba(255,255,255,.59) 100%);
            backdrop-filter:blur(20px) saturate(170%); -webkit-backdrop-filter:blur(20px) saturate(170%);
            border:1px solid rgba(0,200,100,.25);
            box-shadow:0 20px 60px rgba(0,200,100,.22), 0 0 100px rgba(0,255,136,.12), inset 0 1px 1px rgba(255,255,255,.95), inset 0 -1px 1px rgba(0,255,136,.3);
            overflow:hidden; isolation:isolate;
            opacity:0; visibility:hidden; transform:translateY(-20px) scale(.92);
            transition:opacity .4s ease, transform .5s cubic-bezier(.34,1.56,.64,1), visibility .4s;
        }
        .landing-glass-panel::before {
            content:''; position:absolute; inset:-60%; z-index:-1;
            background:radial-gradient(circle at 20% 30%, rgba(0,255,136,.6), transparent 35%), radial-gradient(circle at 75% 65%, rgba(0,255,170,.5), transparent 38%), radial-gradient(circle at 50% 15%, rgba(255,255,255,.5), transparent 30%), radial-gradient(circle at 85% 25%, rgba(0,200,100,.45), transparent 35%);
            filter:blur(22px); opacity:.9; animation:landingLiquidMove 11s ease-in-out infinite; animation-play-state:paused;
        }
        .landing-glass-panel.open::before{animation-play-state:running}
        .landing-glass-panel::after{content:'';position:absolute;top:2px;left:8%;right:8%;height:35%;border-radius:28px 28px 50% 50% / 28px 28px 30% 30%;background:linear-gradient(to bottom, rgba(255,255,255,.7), rgba(255,255,255,.1) 60%, transparent);pointer-events:none;filter:blur(1.5px)}
        .landing-glass-panel.right{right:24px;transform-origin:top right}
        .landing-glass-panel.left{left:24px;transform-origin:top left}
        .landing-glass-panel.open{opacity:1;visibility:visible;transform:translateY(0) scale(1)}
        .landing-menu-list{list-style:none;display:flex;flex-direction:column;gap:6px;position:relative;z-index:2}
        .landing-menu-link{display:flex;align-items:center;gap:14px;padding:13px 16px;border-radius:16px;text-decoration:none;color:#1b5e20;font-size:15px;font-weight:600;position:relative;overflow:hidden;transition:background .3s ease,color .3s ease,transform .3s cubic-bezier(.34,1.56,.64,1),box-shadow .3s ease}
        .landing-menu-link .icon{font-size:20px;width:30px;height:30px;display:flex;align-items:center;justify-content:center;border-radius:10px;background:linear-gradient(135deg, rgba(0,255,136,.25), rgba(255,255,255,.5));border:1px solid rgba(0,200,100,.25);transition:background .3s ease,transform .4s cubic-bezier(.34,1.56,.64,1),box-shadow .3s ease;flex-shrink:0}
        .landing-menu-link:hover{background:linear-gradient(135deg,rgba(0,255,136,.35),rgba(0,255,170,.18));color:#0d3b1f;transform:translateX(-6px);box-shadow:inset 0 1px 1px rgba(255,255,255,.8),0 4px 20px rgba(0,200,100,.25)}
        .landing-menu-link:hover .icon{background:linear-gradient(135deg,rgba(0,255,136,.55),rgba(0,255,170,.3));transform:scale(1.12) rotate(-6deg);box-shadow:0 4px 18px rgba(0,200,100,.5),inset 0 1px 1px rgba(255,255,255,.85)}
        .landing-menu-link.active{background:linear-gradient(135deg,rgba(0,255,136,.45),rgba(0,255,170,.2));color:#0d3b1f;box-shadow:inset 0 1px 1px rgba(255,255,255,.85),inset 0 -1px 1px rgba(0,200,100,.4),0 4px 20px rgba(0,200,100,.3)}
        .landing-menu-link.active .icon{background:linear-gradient(135deg,rgba(0,255,136,.7),rgba(0,255,170,.4));box-shadow:0 0 18px rgba(0,255,136,.6),inset 0 1px 1px rgba(255,255,255,.9)}
        .landing-menu-link.active::after{content:'';position:absolute;right:4px;top:50%;transform:translateY(-50%);width:4px;height:20px;border-radius:4px;background:#00cc66;box-shadow:0 0 12px #00cc66,0 0 22px rgba(0,255,136,.7)}
        .landing-solid-btn{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;margin-top:10px;padding:15px 20px;border-radius:18px;font-family:inherit;font-size:15px;font-weight:700;color:#fff;text-decoration:none;cursor:pointer;position:relative;overflow:hidden;isolation:isolate;border:1px solid rgba(255,255,255,.4);transition:transform .25s cubic-bezier(.34,1.56,.64,1),box-shadow .25s ease,background .2s ease,border-color .2s ease,color .2s ease}
        .landing-solid-btn::before{content:'';position:absolute;top:2px;left:12%;right:12%;height:45%;border-radius:18px;background:linear-gradient(to bottom,rgba(255,255,255,.55),transparent);pointer-events:none}
        .landing-solid-btn:hover{transform:translateY(-2px) scale(1.03)}
        .landing-solid-btn:active{transform:scale(.97)}
        .landing-solid-btn.green{font-weight:900!important;background:linear-gradient(135deg,#00cc66,#00994d);box-shadow:0 8px 25px rgba(0,200,100,.5),0 0 40px rgba(0,255,136,.3),inset 0 1px 2px rgba(255,255,255,.7),inset 0 -1px 2px rgba(0,80,40,.4);text-shadow:0 1px 4px rgba(0,80,40,.4)}
        .landing-solid-btn.green:hover{box-shadow:0 12px 35px rgba(0,200,100,.7),0 0 60px rgba(0,255,136,.4),inset 0 1px 2px rgba(255,255,255,.85),inset 0 -1px 2px rgba(0,80,40,.4)}
        .landing-logout-btn{background:linear-gradient(135deg,#ff5a52,#d9362e)!important;color:#fff!important;border-color:rgba(255,255,255,.55)!important;box-shadow:0 8px 22px rgba(217,54,46,.28)!important}.landing-solid-btn.ghost{background:linear-gradient(135deg,rgba(255,255,255,.7),rgba(0,255,136,.08));color:#1b7a2e;border:1px solid rgba(0,200,100,.45);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);box-shadow:0 4px 16px rgba(0,200,100,.15),inset 0 1px 1px rgba(255,255,255,.85)}
        .landing-solid-btn.ghost:hover{background:linear-gradient(135deg,rgba(0,255,136,.25),rgba(0,255,170,.15));color:#0d3b1f;border-color:rgba(0,200,100,.8);box-shadow:0 8px 28px rgba(0,200,100,.35),inset 0 1px 1px rgba(255,255,255,.95)}
        .landing-user-content{position:relative;z-index:2;display:flex;flex-direction:column;gap:10px}
        .landing-stagger{opacity:0;transform:translateY(-14px);transition:opacity .4s ease,transform .5s cubic-bezier(.34,1.56,.64,1)}
        .landing-glass-panel.open .landing-stagger{opacity:1;transform:translateY(0)}
        .landing-glass-panel.open .landing-stagger:nth-child(1){transition-delay:.1s}.landing-glass-panel.open .landing-stagger:nth-child(2){transition-delay:.15s}.landing-glass-panel.open .landing-stagger:nth-child(3){transition-delay:.2s}.landing-glass-panel.open .landing-stagger:nth-child(4){transition-delay:.25s}.landing-glass-panel.open .landing-stagger:nth-child(5){transition-delay:.3s}.landing-glass-panel.open .landing-stagger:nth-child(6){transition-delay:.35s}
        .landing-overlay{position:fixed;inset:0;background:rgba(255,255,255,.25);backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px);opacity:0;visibility:hidden;transition:opacity .4s ease,visibility .4s;z-index:998}
        .landing-overlay.open{opacity:1;visibility:visible}
        .landing-brand{display:block;width:fit-content;margin:0 auto;text-align:center;text-decoration:none;color:#0d5a3d;font-size:clamp(24px,3vw,32px);line-height:1.2;font-weight:900!important;letter-spacing:-.02em;-webkit-tap-highlight-color:transparent;transition:opacity .18s ease,transform .18s ease}
        .landing-brand-top{padding:22px 16px 4px;text-align:center}.landing-brand-top .landing-brand{margin:0 auto}
        .landing-brand:hover{opacity:.88;transform:translateY(-1px)}
        @media(max-width:480px){
            .landing-glass-btn{backdrop-filter:blur(10px) saturate(140%);-webkit-backdrop-filter:blur(10px) saturate(140%)}
            .landing-glass-btn::before{filter:blur(10px)}.landing-glass-panel::before{filter:blur(14px)}
            .landing-glass-panel{top:92px;width:calc(100vw - 32px);padding:18px}.landing-glass-panel.right{right:16px}.landing-glass-panel.left{left:16px}.landing-hamburger{top:20px;right:16px}.landing-user-btn{top:20px;left:16px}.landing-glass-btn{width:52px;height:52px}
        }
        @media(prefers-reduced-motion:reduce){.landing-glass-btn::before,.landing-glass-panel::before,.landing-stagger{animation:none!important;transition-duration:.01ms!important}}

        .container { width: min(1140px, calc(100% - 28px)); margin: 0 auto; }

        .hero {
            padding: 34px 0 18px;
        }
        .hero-card {
            display: grid;
            grid-template-columns: minmax(0, 1.02fr) minmax(360px, .98fr);
            gap: 0;
            align-items: stretch;
            background: var(--surface);
            border: 1px solid rgba(19,78,49,.14);
            border-radius: 32px;
            box-shadow: 0 24px 70px rgba(23,73,48,.10);
            overflow: hidden;
        }
        .hero-content {
            padding: 48px 46px 44px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .hero h1 {
            margin: 0 0 18px;
            font-size: clamp(30px, 4vw, 50px);
            line-height: 1.42;
            font-weight: 900 !important;
            color: #123e2a;
            letter-spacing: -.02em;
        }
        .hero h1 strong { color: var(--green-700); font-weight:900 !important; }
        .hero-lead {
            margin: 0;
            font-size: 17px;
            line-height: 2;
            color: #425149;
            max-width: 640px;
        }
        .hero-note {
            margin: 22px 0 26px;
            padding: 14px 16px;
            border-right: 4px solid var(--gold);
            background: var(--gold-soft);
            color: #5f4b0f;
            border-radius: 12px;
            font-size: 13px;
            line-height: 1.9;
            font-weight: 700;
        }
        .hero-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 16px;
        }
        .main-cta,
        .secondary-cta {
            -webkit-user-select: none;
            user-select: none;
            -webkit-touch-callout: none;
            -webkit-tap-highlight-color: transparent;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 60px;
            padding: 0 28px;
            border-radius: 16px;
            text-decoration: none;
            font-size: 18px;
            font-weight: 900;
            transition: transform .2s ease, box-shadow .2s ease, background .18s ease, color .18s ease, border-color .18s ease;
        }
        .main-cta {
            color: #fff;
            background: linear-gradient(135deg, #1b8a52, #0d5a3d);
            border: 2px solid transparent;
            box-shadow: 0 17px 28px rgba(13,90,61,.19), 0 4px 10px rgba(13,90,61,.07);
            transform: translateY(0);
        }
        .hero-main-cta {
            animation: landingCtaFloat 4.6s ease-in-out infinite;
        }
        .main-cta:hover {
            transform: translateY(-5px);
            box-shadow: 0 23px 36px rgba(13,90,61,.23), 0 7px 13px rgba(13,90,61,.09);
        }
        .hero-main-cta:hover {
            animation-play-state: paused;
        }
        @keyframes landingCtaFloat {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-7px); }
        }
        .main-cta:active,
        .main-cta:focus-visible {
            transform: translateY(0);
        }
        .secondary-cta { color: var(--green-900); background: #fff; border: 1px solid rgba(20,114,65,.16); }
        .secondary-cta:hover { transform: translateY(-2px); }
        .hero-main-cta .cta-arrow {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-right: 10px;
            width: 29px;
            height: 29px;
            border-radius: 50%;
            background: rgba(255,255,255,.14);
            color: currentColor;
            transition: background .18s ease, color .18s ease;
        }
        .hero-main-cta:active .cta-arrow,
        .hero-main-cta:focus-visible .cta-arrow {
            background: var(--green-100);
        }


        /* Liquid Glass CTA — uses the existing Dana font size/weight from .main-cta. */
        .hero-main-cta.liquid-cta {
            position:relative;
            overflow:hidden;
            isolation:isolate;
            min-height:60px;
            padding-inline:34px;
            border:1px solid rgba(0,255,136,.42);
            border-radius:100px;
            color:#1b7a2e !important;
            background:linear-gradient(135deg,rgba(255,255,255,.58) 0%,rgba(0,255,136,.20) 42%,rgba(255,255,255,.40) 100%) !important;
            backdrop-filter:blur(22px) saturate(180%);
            -webkit-backdrop-filter:blur(22px) saturate(180%);
            box-shadow:0 8px 32px rgba(0,200,100,.28),0 0 58px rgba(0,255,136,.28),inset 0 1px 1px rgba(255,255,255,.95),inset 0 -1px 2px rgba(0,255,136,.34),inset 0 0 20px rgba(255,255,255,.28);
            text-shadow:0 1px 6px rgba(0,255,136,.34);
            animation:landingLiquidPulse 3.5s ease-in-out infinite;
            transition:transform .4s cubic-bezier(.34,1.56,.64,1),box-shadow .35s ease,border-color .35s ease,color .25s ease;
        }
        .hero-main-cta.liquid-cta::before {
            content:'';
            position:absolute;
            inset:-55%;
            z-index:-1;
            background:radial-gradient(circle at 24% 28%,rgba(0,255,136,.72),transparent 34%),radial-gradient(circle at 72% 70%,rgba(0,255,170,.58),transparent 40%),radial-gradient(circle at 50% 50%,rgba(255,255,255,.50),transparent 30%),radial-gradient(circle at 82% 18%,rgba(0,200,100,.52),transparent 35%);
            background-size:200% 200%;
            filter:blur(25px);
            animation:landingLiquidMove 8s ease-in-out infinite;
            opacity:.82;
        }
        .hero-main-cta.liquid-cta::after {
            content:'';
            position:absolute;
            top:2px;
            left:8%;
            right:8%;
            height:45%;
            border-radius:100px 100px 60% 60% / 100px 100px 40% 40%;
            background:linear-gradient(to bottom,rgba(255,255,255,.88),rgba(255,255,255,.16) 60%,transparent);
            pointer-events:none;
            filter:blur(2px);
            opacity:.9;
        }
        .hero-main-cta.liquid-cta > span:first-child { position:relative; z-index:3; }
        .hero-main-cta.liquid-cta:hover {
            transform:translateY(-4px) scale(1.025);
            color:#0d5c1e !important;
            border-color:rgba(0,255,136,.88);
            box-shadow:0 15px 45px rgba(0,200,100,.42),0 0 96px rgba(0,255,136,.46),inset 0 1px 2px rgba(255,255,255,.98),inset 0 -1px 3px rgba(0,255,136,.55),inset 0 0 30px rgba(255,255,255,.38);
        }
        .hero-main-cta.liquid-cta:active { transform:translateY(-1px) scale(.975); }
        .hero-main-cta.liquid-cta.is-delaying { pointer-events:none; opacity:.96; animation:landingLiquidPulse 2.8s ease-in-out infinite; }
        @keyframes landingLiquidMove {
            0% { transform:translate(0,0) rotate(0deg) scale(1); }
            33% { transform:translate(8%,-6%) rotate(120deg) scale(1.1); }
            66% { transform:translate(-8%,6%) rotate(240deg) scale(.95); }
            100% { transform:translate(0,0) rotate(360deg) scale(1); }
        }
        @keyframes landingLiquidPulse {
            0%,100% { box-shadow:0 8px 32px rgba(0,200,100,.28),0 0 58px rgba(0,255,136,.28),inset 0 1px 1px rgba(255,255,255,.95); }
            50% { box-shadow:0 8px 44px rgba(0,200,100,.42),0 0 82px rgba(0,255,136,.42),inset 0 1px 1px rgba(255,255,255,.98); }
        }

        .hero-image-wrap {
            padding: 22px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background: linear-gradient(180deg, #eaf4ee 0%, #e4efe9 100%);
            border-right: 1px solid var(--line);
        }
        .hero-image {
            width: 100%;
            max-width: 520px;
            aspect-ratio: 1 / 1;
            object-fit: contain;
            display: block;
            border-radius: 20px;
            background: #111;
            box-shadow: 0 18px 42px rgba(18,48,34,.18);
        }

        .section { padding: 58px 0 0; }
        #how { padding-top: 40px; }
        .section-head { max-width: 760px; margin: 0 auto 28px; text-align: center; }
        .section-kicker {
            display: inline-block;
            color: var(--green-800);
            background: var(--green-100);
            border: 1px solid rgba(36,167,106,.13);
            border-radius: 999px;
            padding: 7px 12px;
            font-size: 12px;
            font-weight: 800;
            margin-bottom: 10px;
        }
        .section-head h2 { margin: 0 0 10px; font-size: clamp(24px, 3vw, 34px); line-height: 1.5; color: #153f2b; }
        .section-head p { margin: 0; color: var(--muted); font-size: 14px; line-height: 2; }

        .mission-card {
            background: #fff;
            border: 1px solid var(--line);
            border-radius: 22px;
            padding: 30px 28px;
            box-shadow: 0 16px 42px rgba(24,70,46,.07);
        }
        .mission-card p {
            margin: 0;
            font-size: 18px;
            line-height: 2.25;
            color: #29362f;
            text-align: justify;
        }
        .mission-accent { color: var(--green-800); font-weight: 900; }

        .steps {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 24px;
            align-items: stretch;
        }

        /* کارت‌های مراحل؛ الهام‌گرفته از نمونه ورق‌مانند، ساده و کم‌حجم */
        .step {
            --step-color: #10b981;
            --step-color-2: #34d399;
            position: relative;
            display: flex;
            align-items: center;
            gap: 20px;
            min-height: 204px;
            padding: 30px 26px 27px;
            overflow: hidden;
            border: 1px solid rgba(120, 53, 15, .08);
            border-radius: 20px;
            background: #fff;
            box-shadow: 0 12px 28px rgba(120, 53, 15, .10), 0 2px 7px rgba(120, 53, 15, .05);
            transition: transform .24s ease, box-shadow .24s ease, border-color .24s ease;
        }
        .step::before {
            content: "";
            position: absolute;
            top: -6px;
            left: 30%;
            right: 30%;
            height: 12px;
            border-radius: 999px;
            background: linear-gradient(90deg, var(--step-color), var(--step-color-2));
            box-shadow: 0 4px 10px rgba(16,185,129,.18);
            transition: left .24s ease, right .24s ease, transform .24s ease;
            pointer-events: none;
        }
        .step::after {
            content: "";
            position: absolute;
            width: 150px;
            height: 150px;
            left: -58px;
            bottom: -70px;
            border-radius: 50%;
            background: var(--step-color);
            opacity: .045;
            pointer-events: none;
        }
        .step:hover {
            transform: translateY(-6px) rotate(-.25deg);
            box-shadow: 0 22px 44px rgba(120, 53, 15, .15), 0 6px 13px rgba(120, 53, 15, .06);
            border-color: rgba(120, 53, 15, .12);
        }
        .step:hover::before {
            left: 16%;
            right: 16%;
            transform: rotate(-1deg);
        }
        .step-top {
            flex: 0 0 72px;
            width: 72px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
        }
        .step-icon {
            position: relative;
            width: 72px;
            height: 72px;
            flex: 0 0 72px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 24px 8px 24px 8px;
            background: linear-gradient(135deg, var(--step-color), var(--step-color-2));
            box-shadow: 0 9px 22px rgba(16,185,129,.18);
            font-size: 31px;
            line-height: 1;
            transition: transform .24s ease, border-radius .24s ease;
        }
        .step:hover .step-icon {
            transform: rotate(-5deg) scale(1.05);
            border-radius: 8px 24px 8px 24px;
        }
        .step-num {
            position: absolute;
            left: -9px;
            bottom: -9px;
            width: 30px;
            height: 30px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border: 2px solid #fff;
            border-radius: 50%;
            background: #fff;
            color: var(--step-color);
            box-shadow: 0 4px 10px rgba(0,0,0,.10);
            font-size: 13px;
            font-weight: 900;
        }
        .step-body {
            flex: 1;
            min-width: 0;
            position: relative;
            z-index: 1;
        }
        .step h3 {
            margin: 0 0 8px;
            font-size: 19px;
            line-height: 1.6;
            color: #5f2f0e;
            font-weight: 850;
        }
        .step p {
            margin: 0;
            font-size: 14px;
            line-height: 2;
            color: #756d64;
        }
        .step-green { --step-color: #10b981; --step-color-2: #34d399; }
        .step-gold { --step-color: #f59e0b; --step-color-2: #fbbf24; }
        .step-blue { --step-color: #3b82f6; --step-color-2: #60a5fa; }

        .features {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 16px;
        }
        .feature {
            -webkit-user-select: none;
            user-select: none;
            -webkit-touch-callout: none;
            -webkit-tap-highlight-color: transparent;
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: stretch;
            min-height: 178px;
            padding: 20px 20px 18px;
            background: rgba(255,255,255,.82);
            border: 1px solid var(--line);
            border-radius: 20px;
            box-shadow: 0 10px 28px rgba(24,70,46,.055);
            overflow: hidden;
            transition: transform .22s ease, box-shadow .22s ease, border-color .22s ease;
        }
        .feature::after {
            content: '';
            position: absolute;
            width: 120px;
            height: 120px;
            left: -45px;
            bottom: -60px;
            border-radius: 50%;
            background: var(--green-600);
            opacity: .045;
            pointer-events: none;
        }
        .feature:hover {
            transform: translateY(-3px);
            box-shadow: 0 16px 34px rgba(24,70,46,.09);
            border-color: rgba(20,114,65,.18);
        }
        .feature-highlight { background: linear-gradient(135deg, rgba(234,248,240,.96), rgba(255,255,255,.9)); }
        .feature-icon {
            flex: 0 0 auto;
            width: 54px;
            height: 54px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 16px;
            background: linear-gradient(135deg,#eaf8f0,#fff8dc);
            border: 1px solid rgba(20,114,65,.10);
            box-shadow: 0 8px 18px rgba(24,70,46,.07);
            font-size: 25px;
            margin-bottom: 14px;
        }
        .feature > div:last-child {
            position: relative;
            z-index: 1;
            width: 100%;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        .feature h3 { margin: 0; font-size: 16px; line-height: 1.7; color: #173e2b; }
        .feature p { margin: 0; font-size: 13.5px; line-height: 2; color: var(--muted); }

        .final-cta {
            margin: 68px 0 46px;
            padding: 36px 28px;
            text-align: center;
            background: linear-gradient(135deg, #0f6544, #1d8d57);
            border-radius: 24px;
            box-shadow: 0 22px 50px rgba(13,90,61,.18);
            color: #fff;
        }
        .final-cta h2 { margin: 0 0 10px; font-size: clamp(23px, 3vw, 31px); }
        .final-cta p { margin: 0 auto 22px; max-width: 700px; color: rgba(255,255,255,.86); line-height: 2; font-size: 14px; }
        .final-cta a { background: #fff; color: var(--green-900); }

        .footer-note {
            text-align: center;
            color: #77847c;
            font-size: 12px;
            padding: 0 0 30px;
        }
        .landing-footer {
            color: #77847c;
            padding-bottom: calc(30px + env(safe-area-inset-bottom));
        }

        @media (max-width: 900px) {
            .hero { padding: 18px 0 10px; }
            .hero-card { grid-template-columns: 1fr; }
            .hero-image-wrap {
                order: -1;
                border-right: 0;
                border-bottom: 1px solid var(--line);
                padding: 10px;
            }
            .hero-image {
                max-height: 340px;
                object-fit: contain;
            }
            .hero-content {
                padding: 24px 24px 26px;
            }
            .features { gap: 16px; }
            .final-cta { position: relative; overflow: hidden; }
            .final-cta::before {
                content:"";
                position:absolute;
                width:260px;
                height:260px;
                border-radius:50%;
                background:rgba(229,174,24,.12);
                top:-150px;
                left:-50px;
            }
            .final-cta > * { position:relative; z-index:1; }
            .final-cta .main-cta {
                margin:0 auto;
                display:inline-flex;
                background:#fff;
                color:var(--green-900);
                box-shadow:0 12px 28px rgba(0,0,0,.14);
            }
            .final-cta .cta-arrow { background:var(--green-100); color:var(--green-900); }
        }

        @media (max-width: 640px) {
            .hero { padding: 12px 0 4px; }
            .hero-card { border-radius: 26px; }
            .hero-image-wrap { padding: 6px; }
            .hero-image {
                max-height: 292px;
                border-radius: 18px;
            }
            .hero-content {
                padding: 22px 20px 24px;
            }
            .hero h1 {
                font-size: 28px;
                line-height: 1.55;
            }
            .hero-lead {
                text-align: right;
                font-size: 15px;
                line-height: 2.15;
            }
            .hero-actions { margin-top: 18px; }
            .main-cta {
                width: 100%;
                min-width: 0;
                min-height: 62px;
                font-size: 19px;
                padding-inline: 22px;
                border-radius: 17px;
            }
            .hero-main-cta {
                animation:landingLiquidPulse 3.5s ease-in-out infinite;
            }
            .hero-main-cta:active,
            .hero-main-cta:focus-visible {
                animation-play-state: paused;
            }
            .section { padding-top: 48px; }
            #how { padding-top: 34px; }
            .steps { grid-template-columns: 1fr; }
            .step {
                min-height: 0;
                align-items: flex-start;
                gap: 16px;
                padding: 24px 20px 22px;
            }
            .step-top { flex-basis: 58px; width: 58px; }
            .step-icon {
                width: 58px;
                height: 58px;
                flex-basis: 58px;
                border-radius: 19px 7px 19px 7px;
                font-size: 26px;
            }
            .step-num {
                width: 27px;
                height: 27px;
                left: -8px;
                bottom: -8px;
                font-size: 12px;
            }
            .step h3 { font-size: 17px; margin-bottom: 6px; }
            .step p { font-size: 13.5px; line-height: 1.95; }
        }

        @media (prefers-reduced-motion: reduce) {
            html { scroll-behavior: auto; }
            *, *::before, *::after { animation-duration: .01ms !important; animation-iteration-count: 1 !important; transition-duration: .01ms !important; }
            .hero-main-cta { animation:none !important; }
        }

        .hero-main-cta.is-delaying:active,
        .hero-main-cta.is-delaying:focus-visible { color:#0d5c1e !important; }
    </style>



</head>
<body class="landing-page">
<?php require __DIR__ . '/includes/page_loader.php'; ?>

<div class="landing-bg" aria-hidden="true"></div>

<button class="landing-glass-btn landing-hamburger" id="landingHamburgerBtn" type="button" aria-label="منو" aria-expanded="false">
    <span class="line"></span><span class="line"></span><span class="line"></span>
</button>
<button class="landing-glass-btn landing-user-btn" id="landingUserBtn" type="button" aria-label="حساب کاربری" aria-expanded="false">
    <svg viewBox="0 0 24 24" aria-hidden="true">
        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
        <circle cx="12" cy="7" r="4"/>
    </svg>
</button>
<div class="landing-overlay" id="landingOverlay"></div>
<nav class="landing-glass-panel right" id="landingMenuPanel" aria-label="منوی اصلی">
    <ul class="landing-menu-list">
        <li class="landing-stagger"><a class="landing-menu-link active" href="register.php"><span class="icon">🏠</span>خانه</a></li>
        <li class="landing-stagger"><a class="landing-menu-link" href="register.php"><span class="icon">👤</span>بخش کاربری</a></li>
        <li class="landing-stagger"><a class="landing-menu-link" href="register.php"><span class="icon">📚</span>مسیر مطالعه</a></li>
        <li class="landing-stagger"><a class="landing-menu-link" href="charter.php"><span class="icon">📜</span>مرامنامه</a></li>
        <li class="landing-stagger"><a class="landing-menu-link" href="invite.php"><span class="icon">🤝</span>دعوت از دوستان</a></li>
    </ul>
    <a class="landing-solid-btn green landing-stagger" href="register.php">✨ شروع قدم برداشتن</a>
</nav>
<aside class="landing-glass-panel left" id="landingUserPanel" aria-label="حساب کاربری">
    <div class="landing-user-content">
        <?php if (isLoggedIn()): ?>
            <?php $landingUser = getUser($pdo); $landingName = trim((string)($landingUser['full_name'] ?? 'کاربر')); ?>
            <div class="landing-stagger" style="padding:6px 4px;text-align:center;color:#1b5e20;font-weight:800;line-height:1.9">کاربر <?= e($landingName) ?> عزیز، خوش آمدید 🌷</div>
            <a class="landing-solid-btn landing-logout-btn landing-stagger" href="logout.php">خروج از حساب</a>
        <?php else: ?>
            <a class="landing-solid-btn ghost landing-stagger" href="login.php">ورود</a>
            <a class="landing-solid-btn green landing-stagger" href="register.php">ثبت نام</a>
        <?php endif; ?>
    </div>
</aside>

<div class="landing-brand-top"><a class="landing-brand" href="index.php" aria-label="پیشروان بصیرت">پیشروان بصیــرت</a></div>

<main>
    <section class="hero container">
        <div class="hero-card">
            <div class="hero-content">
                <h1>هر قدم برای احیای امر به معروف،<br><strong>قدمی به سوی ظهور</strong></h1>
                <p class="hero-lead">
                    ما اینجا گرد هم آمده‌ایم تا با احیای امر به معروف و نهی از منکر — که از مصادیق آن، تبلیغ و ترویج این فریضه است — قدمی در راه زمینه‌سازی ظهور حضرت بقیه‌الله (عج) برداریم.
                </p>
                <div class="hero-actions">
                    <a class="main-cta hero-main-cta liquid-cta" href="register.php"><span>شروع قدم برداشتن</span></a>
                </div>
            </div>
            <div class="hero-image-wrap">
                <img class="hero-image" src="assets/images/landing-hero.jpg" alt="تصویر مرتبط با امر به معروف و نهی از منکر" />
            </div>
        </div>
    </section>

    <section class="section container" id="how">
        <div class="section-head">
            <span class="section-kicker">ساده و روزانه</span>
            <h2>قرار روزانه چطور انجام می‌شود؟</h2>
            <p>سه قدم کوتاه؛ برای اینکه مطالعه و خودآزمایی، بخشی ثابت از روزت شود.</p>
        </div>
        <div class="steps">
            <article class="step step-green">
                <div class="step-top">
                    <div class="step-icon" aria-hidden="true">📖<span class="step-num">۱</span></div>
                </div>
                <div class="step-body">
                    <h3>مطالعه روز</h3>
                    <p>متن تعیین‌شده روز را با دقت بخوان و چند دقیقه برای مطالعه و توجه کنار بگذار.</p>
                </div>
            </article>
            <article class="step step-gold">
                <div class="step-top">
                    <div class="step-icon" aria-hidden="true">✍️<span class="step-num">۲</span></div>
                </div>
                <div class="step-body">
                    <h3>خودآزمایی</h3>
                    <p>پس از مطالعه، سؤال‌های همان روز را پاسخ بده تا میزان دریافتت را محک بزنی.</p>
                </div>
            </article>
            <article class="step step-blue">
                <div class="step-top">
                    <div class="step-icon" aria-hidden="true">🌱<span class="step-num">۳</span></div>
                </div>
                <div class="step-body">
                    <h3>ثبت قرار روزانه</h3>
                    <p>با انجام مطالعه و خودآزمایی، وضعیت روزانه‌ات ثبت می‌شود تا مسیرت را پیوسته دنبال کنی.</p>
                </div>
            </article>
        </div>
    </section>

    <section class="section container" id="features">
        <div class="section-head">
            <span class="section-kicker">در یک نگاه</span>
            <h2>برای ادامه‌دادن چه چیزهایی داری؟</h2>
            <p>یک مسیر روشن و بدون پیچیدگی، برای اینکه قرار روزانه‌ات را راحت‌تر ادامه بدهی.</p>
        </div>
        <div class="features">
            <article class="feature feature-highlight">
                <div class="feature-icon">📚</div>
                <div>
                    <h3>مطالعه کوتاه و منظم</h3>
                    <p>محتوای روزانه را در زمان کوتاه و با تمرکز دنبال می‌کنی.</p>
                </div>
            </article>
            <article class="feature">
                <div class="feature-icon">✅</div>
                <div>
                    <h3>خودآزمایی روزانه</h3>
                    <p>با سؤال‌های چهارگزینه‌ای، میزان یادگیری همان روز را بررسی می‌کنی.</p>
                </div>
            </article>
            <article class="feature">
                <div class="feature-icon">📈</div>
                <div>
                    <h3>پیگیری پیشرفت</h3>
                    <p>وضعیت مطالعه و آزمون‌های روزانه‌ات را در حساب کاربری می‌بینی.</p>
                </div>
            </article>
            <article class="feature">
                <div class="feature-icon">📱</div>
                <div>
                    <h3>دسترسی سریع</h3>
                    <p>با نصب برنامه، دسترسی به قرار روزانه از صفحه اصلی گوشی ساده‌تر می‌شود.</p>
                </div>
            </article>
        </div>
    </section>

    <section class="container">
        <div class="final-cta">
            <h2>از امروز، یک قرار کوچک برای یک قدم بزرگ</h2>
            <p>روزت را با چند دقیقه مطالعه و یک خودآزمایی کوتاه شروع کن.</p>
            <a class="main-cta" href="register.php">ثبت‌نام و شروع قرار روزانه <span class="cta-arrow" aria-hidden="true">←</span></a>
        </div>
    </section>
</main>

<footer class="footer-note landing-footer">طراحی شده با <span aria-hidden="true">❤️</span> توسط مردم مبعوث شده</footer>

<script>
(function(){
    const hamburgerBtn = document.getElementById('landingHamburgerBtn');
    const userBtn = document.getElementById('landingUserBtn');
    const menuPanel = document.getElementById('landingMenuPanel');
    const userPanel = document.getElementById('landingUserPanel');
    const overlay = document.getElementById('landingOverlay');
    if (!hamburgerBtn || !userBtn || !menuPanel || !userPanel || !overlay) return;
    let openPanel = null;
    function closeAll(){
        hamburgerBtn.classList.remove('active');
        userBtn.classList.remove('active');
        hamburgerBtn.setAttribute('aria-expanded','false');
        userBtn.setAttribute('aria-expanded','false');
        menuPanel.classList.remove('open');
        userPanel.classList.remove('open');
        overlay.classList.remove('open');
        openPanel = null;
    }
    function toggle(panel){
        if(openPanel === panel){ closeAll(); return; }
        closeAll();
        if(panel === 'menu'){
            hamburgerBtn.classList.add('active');
            hamburgerBtn.setAttribute('aria-expanded','true');
            menuPanel.classList.add('open');
        } else {
            userBtn.classList.add('active');
            userBtn.setAttribute('aria-expanded','true');
            userPanel.classList.add('open');
        }
        overlay.classList.add('open');
        openPanel = panel;
    }
    hamburgerBtn.addEventListener('click', function(){ toggle('menu'); });
    userBtn.addEventListener('click', function(){ toggle('user'); });
    overlay.addEventListener('click', closeAll);
    document.addEventListener('keydown', function(e){ if(e.key === 'Escape') closeAll(); });
    menuPanel.addEventListener('click', function(e){
        const link = e.target.closest('.landing-menu-link');
        if(!link) return;
        menuPanel.querySelectorAll('.landing-menu-link').forEach(function(item){ item.classList.remove('active'); });
        link.classList.add('active');
    });
})();
</script>
<script src="assets/js/app.js?v=20261001-v13" defer></script>

</body>
</html>
