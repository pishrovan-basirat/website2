<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

$user = isLoggedIn() ? getUser($pdo) : null;
$charterSettings = getSiteSettings($pdo, [
    'charter_title' => 'مرامنامه',
    'charter_lead' => 'هدف از این گروه یارگیری جهت خدمت به حضرت صاحب الزمان(عج) توسط احیای دو واجب فراموش شده امر به معروف و نهی از منکر در میان مردم مبعوث شده(مذهبی ها) است.',
    'charter_section_title' => 'چگونگی کار',
    'charter_section_text' => 'آگاهی در مورد این فریضتین از نگاه قرآن و روایات و نظر امامان انقلاب اسلامی و تعریف میدان های مختلف عملیاتی و نیز مطالعه روزانه میباشد.',
    'charter_slogan' => '✊ می‌خواهیم در کنارهم، اهلِ دعوت به امر به معروف و نهی از منکر بشویم.',
]);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($charterSettings['charter_title']) ?> | پیشروان بصیرت</title>
    <link rel="stylesheet" href="assets/css/style.css?v=20260918-charter1">
    <style>
        body.charter-page {
            display: block;
            min-height: 100vh;
            padding: 0;
            overflow-x: hidden;
        }
        body.charter-page .site-shell {
            width: min(1100px, 100%);
            margin: 0 auto;
            padding: 20px;
        }
        .charter-main {
            width: min(820px, 100%);
            margin: 28px auto 42px;
        }
        .charter-card {
            background: rgba(255,255,255,.70);
            border: 1px solid rgba(255,255,255,.7);
            border-radius: 30px;
            box-shadow: 0 24px 60px rgba(0,0,0,.08), inset 0 1px 0 rgba(255,255,255,.85);
            padding: 34px;
        }
        .charter-title {
            margin: 0 0 28px;
            text-align: center;
            font-size: clamp(28px, 4vw, 38px);
            font-weight: 900;
            color: #165f4b;
        }
        .charter-lead {
            font-size: 18px;
            line-height: 2.35;
            color: #202124;
            font-weight: 500;
            text-align: justify;
        }
        .charter-section {
            margin-top: 24px;
            padding-top: 22px;
            border-top: 1px solid rgba(22,95,75,.12);
        }
        .charter-section h2 {
            margin: 0 0 12px;
            font-size: 20px;
            color: #165f4b;
            font-weight: 800;
        }
        .charter-section p {
            margin: 0;
            font-size: 17px;
            line-height: 2.2;
            color: #303236;
        }
        .charter-slogan {
            margin-top: 28px;
            padding: 18px 20px;
            border-radius: 20px;
            background: linear-gradient(135deg, rgba(22,95,75,.10), rgba(31,160,126,.06));
            border: 1px solid rgba(31,160,126,.14);
            color: #165f4b !important;
            font-weight: 800;
            text-align: center;
        }
        @media (max-width: 700px) {
            body.charter-page .site-shell { padding: 10px; }
            .charter-main { margin-top: 16px; }
            .charter-card { padding: 24px 18px; border-radius: 24px; }
            .charter-title { font-size: 27px; margin-bottom: 22px; }
            .charter-lead { font-size: 16px; line-height: 2.2; text-align: right; }
            .charter-section p { font-size: 15.5px; line-height: 2.1; }
        }
    </style>
</head>
<body class="user-page charter-page">
    <div class="bg-mesh"><div class="blob blob-1"></div><div class="blob blob-2"></div><div class="blob blob-3"></div></div>
    <?php require __DIR__ . '/includes/page_loader.php'; ?>
    <div class="site-shell">
        <?php require __DIR__ . '/includes/site_header.php'; ?>
        <main class="charter-main">
            <article class="charter-card">
                <h1 class="charter-title"><?= e($charterSettings['charter_title']) ?></h1>
                <p class="charter-lead"><?= nl2br(e($charterSettings['charter_lead'])) ?></p>

                <section class="charter-section">
                    <h2><?= e($charterSettings['charter_section_title']) ?></h2>
                    <p><?= nl2br(e($charterSettings['charter_section_text'])) ?></p>
                </section>

                <p class="charter-slogan"><?= nl2br(e($charterSettings['charter_slogan'])) ?></p>
            </article>
        </main>
        <?php require __DIR__ . '/includes/site_footer.php'; ?>
    </div>
    <script src="assets/js/app.js?v=20261001-v13" defer></script>
</body>
</html>
