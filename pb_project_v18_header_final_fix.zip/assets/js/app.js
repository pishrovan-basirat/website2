(function () {
    'use strict';

    function initUserMenu() {
        const button = document.querySelector('[data-user-menu-button]');
        const dropdown = document.querySelector('[data-user-dropdown]');
        if (!button || !dropdown) return;

        function close() {
            dropdown.classList.remove('open');
            button.setAttribute('aria-expanded', 'false');
        }

        button.addEventListener('click', function (event) {
            event.stopPropagation();
            const open = dropdown.classList.toggle('open');
            button.setAttribute('aria-expanded', open ? 'true' : 'false');
        });

        document.addEventListener('click', function (event) {
            if (!dropdown.contains(event.target) && !button.contains(event.target)) close();
        });
    }


    function initNavMenu() {
        const button = document.querySelector('[data-nav-button]');
        const panel = document.querySelector('[data-nav-panel]');
        if (!button || !panel) return;

        function close() {
            panel.classList.remove('open');
            button.setAttribute('aria-expanded', 'false');
            panel.setAttribute('aria-hidden', 'true');
        }

        button.addEventListener('click', function (event) {
            event.stopPropagation();
            const open = panel.classList.toggle('open');
            button.setAttribute('aria-expanded', open ? 'true' : 'false');
            panel.setAttribute('aria-hidden', open ? 'false' : 'true');
        });

        document.addEventListener('click', function (event) {
            if (!panel.contains(event.target) && !button.contains(event.target)) close();
        });

        panel.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', close);
        });
    }

    function initPageLoader() {
        const loader = document.getElementById('pageLoader');
        if (!loader) return;

        const hide = function () {
            loader.classList.remove('show');
            loader.setAttribute('aria-hidden', 'true');
        };

        const show = function () {
            loader.classList.add('show');
            loader.setAttribute('aria-hidden', 'false');
        };

        window.addEventListener('pageshow', hide);
        window.addEventListener('load', hide);

        document.addEventListener('click', function (event) {
            const link = event.target.closest('a');
            if (!link) return;
            if (event.defaultPrevented) return;
            if (link.target === '_blank' || link.hasAttribute('download')) return;
            const href = link.getAttribute('href') || '';
            if (!href || href.startsWith('#') || href.startsWith('javascript:')) return;
            if (/^(mailto:|tel:|https?:\/\/)/i.test(href) && !href.startsWith(window.location.origin)) return;
            show();
        });

        document.addEventListener('submit', function (event) {
            if (event.defaultPrevented) return;
            const form = event.target.closest('form');
            if (!form) return;
            // فرم‌های AJAX/اعتباری که جلوی submit را بعداً می‌گیرند نباید لودر را بی‌جهت نگه دارند.
            show();
        });
    }

    function clearOfflineHomeBeforeLogout() {
        const logoutLink = document.querySelector('.user-dropdown-logout');
        if (!logoutLink) return;
        logoutLink.addEventListener('click', function () {
            if (!('serviceWorker' in navigator)) return;
            navigator.serviceWorker.ready.then(registration => {
                if (registration.active) registration.active.postMessage({ type: 'CLEAR_HOME_CACHE' });
            }).catch(() => {});
        });
    }


    function initEitaaMembership() {
        const card = document.getElementById('eitaaJoinCard');
        const button = document.getElementById('eitaaJoinedBtn');
        if (!card || !button) return;

        const userId = card.getAttribute('data-user-id') || 'guest';
        const storageKey = 'pbasirat_eitaa_joined_v1_' + userId;
        try {
            if (window.localStorage.getItem(storageKey) === '1') {
                card.remove();
                return;
            }
        } catch (_) {}

        button.addEventListener('click', function () {
            try { window.localStorage.setItem(storageKey, '1'); } catch (_) {}
            card.remove();
        });
    }

    function initPwaInstall() {
        const card = document.getElementById('pwaInstallCard');
        const button = document.getElementById('pwaInstallBtn');
        const hint = document.getElementById('pwaInstallHint');
        const modal = document.getElementById('pwaIosModal');
        const modalTitle = modal ? modal.querySelector('.pwa-modal-box h2') : null;
        const modalText = modal ? modal.querySelector('.pwa-modal-box p') : null;
        if (!card || !button) return;

        // This flag is deliberately versioned. The previous v5 flag could be
        // written on iOS merely by opening the instructions, which hid the
        // install card for other accounts on the same browser.
        const storageKey = 'pbasirat_pwa_installed_v6';
        const standaloneQuery = window.matchMedia('(display-mode: standalone)');
        const isStandalone = standaloneQuery.matches || window.navigator.standalone === true;
        const ua = window.navigator.userAgent || '';
        const isIos = /iphone|ipad|ipod/i.test(ua) ||
            (/macintosh/i.test(ua) && navigator.maxTouchPoints > 1);

        let alreadyInstalled = isStandalone;
        let deferredPrompt = null;
        let fallbackTimer = null;

        try {
            alreadyInstalled = alreadyInstalled || window.localStorage.getItem(storageKey) === '1';
        } catch (_) {}

        const setHint = (message) => {
            if (hint) hint.textContent = message;
        };

        const markInstalled = () => {
            alreadyInstalled = true;
            try { window.localStorage.setItem(storageKey, '1'); } catch (_) {}
            card.hidden = true;
        };

        const hideCard = () => { card.hidden = true; };
        const showCard = () => {
            if (!alreadyInstalled) card.hidden = false;
        };

        const setModal = (title, text) => {
            if (modalTitle) modalTitle.textContent = title;
            if (modalText) modalText.textContent = text;
        };

        const openInstallHelp = () => {
            if (!modal) return;

            if (isIos) {
                setModal(
                    'افزودن به صفحه اصلی',
                    'در iPhone یا iPad، دکمه اشتراک‌گذاری مرورگر را بزنید و گزینه «Add to Home Screen» یا «افزودن به صفحه اصلی» را انتخاب کنید.'
                );
            } else if (/android/i.test(ua)) {
                setModal(
                    'نصب برنامه',
                    'از منوی سه‌نقطه مرورگر گزینه «Install app» یا «Add to Home screen» را انتخاب کنید. در Chrome معمولاً گزینه نصب از منوی مرورگر در دسترس است.'
                );
            } else {
                setModal(
                    'نصب برنامه',
                    'در مرورگر خود، از منوی مرورگر یا آیکون نصب کنار نوار نشانی، گزینه «Install» یا «Install app» را انتخاب کنید.'
                );
            }
            modal.hidden = false;
        };

        const closeModal = () => {
            if (modal) modal.hidden = true;
        };

        if (alreadyInstalled) {
            hideCard();
            return;
        }

        // iOS does not expose beforeinstallprompt, so the card must be visible
        // and guide the user through Safari's manual install flow.
        if (isIos) {
            setHint('برای دسترسی سریع‌تر به انجام مطالعه روزانه، دکمه زیر را بزنید');
            showCard();
            button.addEventListener('click', openInstallHelp);
            modal?.querySelectorAll('[data-pwa-close]').forEach(el => {
                el.addEventListener('click', closeModal);
            });
            standaloneQuery.addEventListener?.('change', function (event) {
                if (event.matches || window.navigator.standalone === true) markInstalled();
            });
            return;
        }

        // Chromium exposes the real installation prompt through this event.
        // Keep listening from the moment this script runs so we do not miss it.
        window.addEventListener('beforeinstallprompt', event => {
            if (alreadyInstalled) return;
            event.preventDefault();
            deferredPrompt = event;
            if (fallbackTimer) window.clearTimeout(fallbackTimer);
            setHint('برای دسترسی سریع‌تر به انجام مطالعه روزانه، دکمه زیر را بزنید');
            showCard();
        });

        button.addEventListener('click', async () => {
            if (alreadyInstalled) return;

            if (deferredPrompt) {
                const promptEvent = deferredPrompt;
                deferredPrompt = null;
                try {
                    const result = await promptEvent.prompt();
                    const choice = result || await promptEvent.userChoice;
                    if (choice && choice.outcome === 'accepted') {
                        markInstalled();
                    } else {
                        setHint('برای نصب دوباره، از منوی مرورگر گزینه «Install app» یا «Add to Home screen» را انتخاب کنید.');
                        showCard();
                    }
                } catch (_) {
                    setHint('برای نصب، از منوی مرورگر گزینه «Install app» یا «Add to Home screen» را انتخاب کنید.');
                    showCard();
                }
                return;
            }

            // Some browsers/versions allow installation but do not expose the
            // non-standard beforeinstallprompt event. The old implementation
            // silently did nothing here, which made the card look broken.
            openInstallHelp();
        });

        window.addEventListener('appinstalled', () => {
            deferredPrompt = null;
            markInstalled();
        });

        // Do not leave the card permanently hidden just because the browser
        // has not dispatched beforeinstallprompt yet. A short grace period
        // gives Chromium time to announce installability, then we show a
        // manual-install fallback instead of presenting a dead/blank area.
        fallbackTimer = window.setTimeout(() => {
            fallbackTimer = null;
            if (!alreadyInstalled && !deferredPrompt) {
                setHint(/android/i.test(ua)
                    ? 'برای نصب، روی «نصب» بزنید؛ اگر پیام نصب باز نشد، از منوی مرورگر گزینه «Install app» را انتخاب کنید.'
                    : 'برای نصب، روی «نصب» بزنید یا از منوی مرورگر گزینه «Install app» را انتخاب کنید.');
                showCard();
            }
        }, 1200);

        standaloneQuery.addEventListener?.('change', function (event) {
            if (event.matches || window.navigator.standalone === true) markInstalled();
        });

        // If the prompt was already stored by the browser before this handler
        // ran, some browsers may not replay the event. There is no standard
        // API to retrieve that event, so the visible fallback above remains the
        // safe path for manual installation.
        showCard();

        modal?.querySelectorAll('[data-pwa-close]').forEach(el => {
            el.addEventListener('click', closeModal);
        });
    }

    function registerServiceWorker() {
        if (!('serviceWorker' in navigator)) return;
        // Register immediately. Waiting for window.load can delay service-worker
        // registration long enough for Chromium to evaluate installability
        // before the app is ready, which can prevent beforeinstallprompt from
        // being surfaced at the moment we expect.
        navigator.serviceWorker.register('/service-worker.js', { scope: '/' }).catch(() => {});
    }

    function initManifesto(){
        const btn=document.querySelector('.manifesto-toggle');
        const panel=document.getElementById('manifestoPanel');
        if(!btn||!panel) return;
        btn.addEventListener('click', function(){
            const open=btn.getAttribute('aria-expanded')==='true';
            btn.setAttribute('aria-expanded', open?'false':'true');
            panel.hidden=open;
        });
    }

    // Run DOM-dependent initializers as soon as the deferred bundle executes.
    // This is important for PWA install: beforeinstallprompt can fire before
    // DOMContentLoaded, so the listener must be attached without waiting for it.
    initUserMenu();
    initNavMenu();
    initPageLoader();
    initManifesto();
    initPwaInstall();
    initEitaaMembership();
    clearOfflineHomeBeforeLogout();
    registerServiceWorker();
})();
