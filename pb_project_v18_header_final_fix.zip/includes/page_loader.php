<div class="page-loader" id="pageLoader" aria-hidden="true">
    <div class="loader-diagonal" role="status" aria-label="در حال بارگذاری">
        <span class="slice"></span>
        <span class="slice"></span>
        <span class="slice"></span>
        <span class="slice"></span>
        <span class="center-glow"></span>
    </div>
</div>
