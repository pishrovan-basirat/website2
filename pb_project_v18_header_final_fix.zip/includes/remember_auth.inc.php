<?php
// Persistent PWA/browser login support. This file is loaded by functions.php only.

function ensureRememberTokenTable(PDO $pdo): bool {
    static $ready = null;
    if ($ready !== null) return $ready;

    // The application must never try to create/alter database tables during a normal page request.
    // The migration file is responsible for creating this table. This keeps the site working even
    // when the DB user has no CREATE privilege or the migration has not yet been applied.
    try {
        $pdo->query('SELECT 1 FROM user_remember_tokens LIMIT 1');
        $ready = true;
    } catch (Throwable $e) {
        $ready = false;
    }

    return $ready;
}

function setRememberCookie(string $token, int $expires): void {
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    setcookie('pb_remember', $token, [
        'expires' => $expires,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function clearRememberCookie(): void {
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    setcookie('pb_remember', '', [
        'expires' => time() - 3600,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function issueRememberToken(PDO $pdo, int $userId): void {
    if ($userId <= 0 || !ensureRememberTokenTable($pdo)) return;

    try {
        $token = bin2hex(random_bytes(32));
        $hash = hash('sha256', $token);
        $expires = date('Y-m-d H:i:s', time() + 31536000); // 1 year

        // Keep tokens per browser/device; only expired tokens are removed.
        $stmt = $pdo->prepare('DELETE FROM user_remember_tokens WHERE expires_at < NOW()');
        $stmt->execute();
        $stmt = $pdo->prepare('INSERT INTO user_remember_tokens (user_id, token_hash, expires_at, last_used_at) VALUES (?, ?, ?, NOW())');
        $stmt->execute([$userId, $hash, $expires]);
        setRememberCookie($token, strtotime($expires));
    } catch (Throwable $e) {
        error_log('Remember token issue failed: ' . $e->getMessage());
    }
}

function restoreRememberedLogin(PDO $pdo): void {
    if (isset($_SESSION['user_id']) || empty($_COOKIE['pb_remember']) || !ensureRememberTokenTable($pdo)) return;

    $token = (string)$_COOKIE['pb_remember'];
    if (!preg_match('/^[a-f0-9]{64}$/', $token)) {
        clearRememberCookie();
        return;
    }

    try {
        $hash = hash('sha256', $token);
        $stmt = $pdo->prepare('SELECT user_id FROM user_remember_tokens WHERE token_hash = ? AND expires_at > NOW() LIMIT 1');
        $stmt->execute([$hash]);
        $row = $stmt->fetch();
        if (!$row) {
            clearRememberCookie();
            return;
        }

        $userId = (int)$row['user_id'];
        $userStmt = $pdo->prepare('SELECT id, full_name, role FROM users WHERE id = ? LIMIT 1');
        $userStmt->execute([$userId]);
        $user = $userStmt->fetch();
        if (!$user) {
            clearRememberCookie();
            return;
        }

        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$user['id'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['role'] = $user['role'] ?? 'user';
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

        $update = $pdo->prepare('UPDATE user_remember_tokens SET last_used_at = NOW(), expires_at = DATE_ADD(NOW(), INTERVAL 1 YEAR) WHERE token_hash = ?');
        $update->execute([$hash]);

        // Refresh browser cookie lifetime without changing the token, so relaunching the installed app stays logged in.
        setRememberCookie($token, time() + 31536000);
    } catch (Throwable $e) {
        error_log('Remembered login restore failed: ' . $e->getMessage());
    }
}

function revokeRememberTokens(PDO $pdo, ?int $userId = null): void {
    if (!ensureRememberTokenTable($pdo)) return;
    try {
        if ($userId !== null && $userId > 0) {
            $stmt = $pdo->prepare('DELETE FROM user_remember_tokens WHERE user_id = ?');
            $stmt->execute([$userId]);
        } elseif (!empty($_COOKIE['pb_remember']) && preg_match('/^[a-f0-9]{64}$/', (string)$_COOKIE['pb_remember'])) {
            $stmt = $pdo->prepare('DELETE FROM user_remember_tokens WHERE token_hash = ?');
            $stmt->execute([hash('sha256', (string)$_COOKIE['pb_remember'])]);
        }
    } catch (Throwable $e) {
        error_log('Remember token revoke failed: ' . $e->getMessage());
    }
}
