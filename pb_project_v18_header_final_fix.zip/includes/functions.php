<?php

declare(strict_types=1);

require_once __DIR__ . '/remember_auth.inc.php';

function getPageTitle($page) {
    $titles = [
        'index' => 'نظرسنجی شیشه‌ای',
        'login' => 'ورود به سایت',
        'register' => 'ثبت‌نام در سایت',
        'dashboard' => 'داشبورد کاربری',
        'admin' => 'پنل مدیریت'
    ];
    return $titles[$page] ?? 'سایت من';
}

function getPageDescription($page) {
    $descriptions = [
        'index' => 'نظرسنجی با طراحی شیشه‌ای اپل',
        'login' => 'با شماره همراه و رمز عبور خود وارد شوید',
        'register' => 'ثبت‌نام در نظرسنجی',
    ];
    return $descriptions[$page] ?? '';
}

function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(?string $token): bool {
    return is_string($token) && isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function isLoggedIn(): bool {
    global $pdo;
    $validSession = isset($_SESSION['user_id']) && filter_var($_SESSION['user_id'], FILTER_VALIDATE_INT) !== false;
    if (!$validSession && isset($pdo)) {
        restoreRememberedLogin($pdo);
        $validSession = isset($_SESSION['user_id']) && filter_var($_SESSION['user_id'], FILTER_VALIDATE_INT) !== false;
    }
    if ($validSession && isset($pdo) && empty($_SESSION['remember_issued'])) {
        issueRememberToken($pdo, (int)$_SESSION['user_id']);
        $_SESSION['remember_issued'] = 1;
    }
    return $validSession;
}

function require_login(string $redirect = 'login.php'): void {
    if (!isLoggedIn()) {
        header('Location: ' . $redirect);
        exit;
    }
}

function require_admin(string $redirect = 'login.php'): void {
    if (!isLoggedIn()) {
        header('Location: ' . $redirect);
        exit;
    }

    global $pdo;
    $stmt = $pdo->prepare("SELECT id, role FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([(int) $_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (!$user || $user['role'] !== 'admin') {
        unset($_SESSION['role']);
        http_response_code(403);
        exit('دسترسی غیرمجاز.');
    }

    $_SESSION['role'] = 'admin';
}

function redirect(string $location): never {
    header('Location: ' . $location);
    exit;
}

function json_response(array $data, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function e(?string $value): string {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

/** تبدیل صحیح میلادی به شمسی، بدون وابستگی به کتابخانه خارجی. */
function gregorianToJalali(string $date): string {
    $timestamp = strtotime($date);
    if ($timestamp === false) {
        return $date;
    }

    $gy = (int) date('Y', $timestamp);
    $gm = (int) date('n', $timestamp);
    $gd = (int) date('j', $timestamp);

    $gDaysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    $jDaysInMonth = [0, 31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];

    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + intdiv($gy2 + 3, 4) - intdiv($gy2 + 99, 100) + intdiv($gy2 + 399, 400) + $gd;
    for ($i = 1; $i < $gm; $i++) {
        $days += $gDaysInMonth[$i];
    }

    $jy = -1595 + (33 * intdiv($days, 12053));
    $days %= 12053;
    $jy += 4 * intdiv($days, 1461);
    $days %= 1461;

    if ($days > 365) {
        $jy += intdiv($days - 1, 365);
        $days = ($days - 1) % 365;
    }

    if ($days < 186) {
        $jm = 1 + intdiv($days, 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + intdiv($days - 186, 30);
        $jd = 1 + (($days - 186) % 30);
    }

    return sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
}


function jalaliToGregorian(string $jalaliDate): ?string {
    $normalized = strtr(trim($jalaliDate), ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
    $parts = preg_split('#[/\\\-]+#', $normalized);
    if (count($parts) !== 3) return null;
    [$jy, $jm, $jd] = array_map('intval', $parts);
    if ($jy < 1200 || $jy > 1600 || $jm < 1 || $jm > 12 || $jd < 1 || $jd > 31) return null;

    $jy -= 979;
    $jm -= 1;
    $jd -= 1;
    $jDayNo = 365 * $jy + intdiv($jy, 33) * 8 + intdiv(($jy % 33) + 3, 4);
    for ($i = 0; $i < $jm; $i++) {
        $jDayNo += ($i < 6) ? 31 : 30;
    }
    $jDayNo += $jd;

    $gDayNo = $jDayNo + 79;
    $gy = 1600 + 400 * intdiv($gDayNo, 146097);
    $gDayNo %= 146097;
    $leap = true;
    if ($gDayNo >= 36525) {
        $gDayNo--;
        $gy += 100 * intdiv($gDayNo, 36524);
        $gDayNo %= 36524;
        if ($gDayNo >= 365) $gDayNo++;
        else $leap = false;
    }
    $gy += 4 * intdiv($gDayNo, 1461);
    $gDayNo %= 1461;
    if ($gDayNo >= 366) {
        $leap = false;
        $gDayNo--;
        $gy += intdiv($gDayNo, 365);
        $gDayNo %= 365;
    }

    $sal_a = [0,31, ($leap ? 29 : 28),31,30,31,30,31,31,30,31,30,31];
    $gm = 1;
    while ($gm <= 12 && $gDayNo >= $sal_a[$gm]) {
        $gDayNo -= $sal_a[$gm];
        $gm++;
    }
    $gd = $gDayNo + 1;
    return sprintf('%04d-%02d-%02d', $gy, $gm, $gd);
}

function jalaliDateToIsoOrNull(string $value): ?string {
    $value = trim($value);
    if ($value === '') return null;
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) return $value;
    return jalaliToGregorian($value);
}

function formatJalaliDate(string $date): string {
    $j = gregorianToJalali($date);
    $parts = explode('/', $j);
    $months = [1=>'فروردین',2=>'اردیبهشت',3=>'خرداد',4=>'تیر',5=>'مرداد',6=>'شهریور',7=>'مهر',8=>'آبان',9=>'آذر',10=>'دی',11=>'بهمن',12=>'اسفند'];
    return sprintf('%d %s %d', (int)$parts[2], $months[(int)$parts[1]] ?? '', (int)$parts[0]);
}

function formatJalaliDateTime(?string $dateTime): string {
    if (!$dateTime) return '—';
    $timestamp = strtotime($dateTime);
    if ($timestamp === false) return $dateTime;
    return formatJalaliDate(date('Y-m-d', $timestamp)) . ' - ' . date('H:i', $timestamp);
}

function optionLabel(int $num): string {
    return ['الف', 'ب', 'پ', 'ت'][$num - 1] ?? (string)$num;
}


/** HTML مجاز برای متن مطالعه؛ قالب‌بندی را نگه می‌دارد و کدهای اجرایی را حذف می‌کند. */
function sanitizeStudyHtml(string $html): string {
    $html = preg_replace('/<\s*(script|iframe|object|embed|form|input|button)[^>]*>.*?<\s*\/\s*\1\s*>/is', '', $html) ?? '';
    $html = preg_replace('/<\s*(script|iframe|object|embed|form|input|button)[^>]*\/?\s*>/i', '', $html) ?? '';
    $allowed = '<p><br><strong><b><em><i><u><s><sup><sub><h2><h3><h4><ul><ol><li><blockquote><a><span><div><img><hr><figure><figcaption><table><thead><tbody><tfoot><tr><th><td>';
    $html = strip_tags($html, $allowed);
    $html = preg_replace('/\s+on[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html) ?? '';
    // فقط ویژگی‌های ظاهری مجاز را نگه می‌داریم؛ قالب‌بندی متن شامل justify نیز محفوظ می‌ماند.
    $html = preg_replace_callback('/\s+style\s*=\s*(["\'])(.*?)\1/is', static function(array $m): string {
        $style = $m[2];
        $allowed = [];
        foreach (explode(';', $style) as $declaration) {
            if (strpos($declaration, ':') === false) continue;
            [$property, $value] = array_map('trim', explode(':', $declaration, 2));
            $property = strtolower($property);
            if (in_array($property, ['text-align', 'text-justify', 'font-weight', 'font-style', 'text-decoration', 'color', 'background-color', 'font-size', 'font-family'], true)) {
                // جلوگیری از تزریق CSS در عین حفظ قالب‌بندی‌های رایج و امن CKEditor 5.
                if ($value !== '' && !preg_match('/url\s*\(|expression\s*\(|javascript\s*:|behavior\s*:|[<>]/i', $value)) {
                    $allowed[] = $property . ': ' . $value;
                }
            }
        }
        return $allowed ? ' style="' . e(implode('; ', $allowed)) . '"' : '';
    }, $html) ?? $html;
    $html = preg_replace_callback('/\s+(href|src)\s*=\s*(["\'])(.*?)\2/i', static function(array $m): string {
        $value = trim($m[3]);
        if (preg_match('/^javascript:/i', $value) || preg_match('/^data:text\/html/i', $value)) {
            return ' ' . $m[1] . '="#"';
        }
        return ' ' . $m[1] . '=' . $m[2] . $value . $m[2];
    }, $html) ?? $html;
    return trim($html);
}

/* ================================================================
 * سامانه جلسات مطالعه (بدون قفل زمانی)
 * ================================================================ */
function studySessionTablesAvailable(PDO $pdo): bool {
    static $available = null;
    if ($available !== null) return $available;
    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name IN ('study_chapters','study_sessions','session_questions','user_session_progress','session_exam_attempts','session_exam_answers')");
        $available = ((int)$stmt->fetchColumn() === 6);
    } catch (Throwable $e) {
        $available = false;
    }
    return $available;
}

function getStudySession(PDO $pdo, int $sessionId): ?array {
    $stmt = $pdo->prepare('SELECT s.*, c.title AS chapter_title, c.sort_order AS chapter_sort_order FROM study_sessions s LEFT JOIN study_chapters c ON c.id = s.chapter_id WHERE s.id = ? AND s.is_active = 1 AND c.is_active = 1 LIMIT 1');
    $stmt->execute([$sessionId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function getActiveStudySessions(PDO $pdo): array {
    $stmt = $pdo->query('SELECT s.*, c.title AS chapter_title, c.sort_order AS chapter_sort_order FROM study_sessions s LEFT JOIN study_chapters c ON c.id = s.chapter_id WHERE s.is_active = 1 AND c.is_active = 1 ORDER BY c.sort_order ASC, s.sequence_no ASC, s.id ASC');
    return $stmt->fetchAll();
}

function getStudyChapters(PDO $pdo): array {
    $stmt = $pdo->query('SELECT * FROM study_chapters ORDER BY sort_order ASC, id ASC');
    return $stmt->fetchAll();
}

function getActiveStudyChapters(PDO $pdo): array {
    $stmt = $pdo->query('SELECT * FROM study_chapters WHERE is_active = 1 ORDER BY sort_order ASC, id ASC');
    return $stmt->fetchAll();
}

function getUserSessionProgressMap(PDO $pdo, int $userId): array {
    $stmt = $pdo->prepare('SELECT * FROM user_session_progress WHERE user_id = ?');
    $stmt->execute([$userId]);
    $map = [];
    foreach ($stmt->fetchAll() as $row) {
        $map[(int)$row['session_id']] = $row;
    }
    return $map;
}

function getUserSessionProgress(PDO $pdo, int $userId, int $sessionId): array {
    $stmt = $pdo->prepare('SELECT * FROM user_session_progress WHERE user_id = ? AND session_id = ? LIMIT 1');
    $stmt->execute([$userId, $sessionId]);
    $row = $stmt->fetch();
    return $row ?: [
        'id' => 0,
        'user_id' => $userId,
        'session_id' => $sessionId,
        'viewed_at' => null,
        'completed_at' => null,
        'is_completed' => 0,
        'created_at' => null,
        'updated_at' => null,
    ];
}

function ensureUserSessionProgress(PDO $pdo, int $userId, int $sessionId): array {
    $progress = getUserSessionProgress($pdo, $userId, $sessionId);
    if ((int)$progress['id'] > 0) return $progress;
    $stmt = $pdo->prepare('INSERT INTO user_session_progress (user_id, session_id, viewed_at, created_at, updated_at) VALUES (?, ?, NOW(), NOW(), NOW())');
    $stmt->execute([$userId, $sessionId]);
    return getUserSessionProgress($pdo, $userId, $sessionId);
}

function markSessionViewed(PDO $pdo, int $userId, int $sessionId): void {
    $stmt = $pdo->prepare('INSERT INTO user_session_progress (user_id, session_id, viewed_at, created_at, updated_at) VALUES (?, ?, NOW(), NOW(), NOW()) ON DUPLICATE KEY UPDATE viewed_at = COALESCE(viewed_at, NOW()), updated_at = NOW()');
    $stmt->execute([$userId, $sessionId]);
}

function isSessionPassed(PDO $pdo, int $userId, int $sessionId): bool {
    $stmt = $pdo->prepare('SELECT 1 FROM user_session_progress WHERE user_id = ? AND session_id = ? AND is_completed = 1 LIMIT 1');
    $stmt->execute([$userId, $sessionId]);
    return (bool)$stmt->fetchColumn();
}

function getPreviousStudySession(PDO $pdo, int $sessionId): ?array {
    $current = getStudySession($pdo, $sessionId);
    if (!$current) return null;
    // Find the previous session across all chapters, ordered by chapter sort_order then sequence_no
    $stmt = $pdo->prepare('SELECT s.*, c.title AS chapter_title, c.sort_order AS chapter_sort_order FROM study_sessions s LEFT JOIN study_chapters c ON c.id = s.chapter_id WHERE s.is_active = 1 AND c.is_active = 1 AND (c.sort_order < ? OR (c.sort_order = ? AND (s.sequence_no < ? OR (s.sequence_no = ? AND s.id < ?)))) ORDER BY c.sort_order DESC, s.sequence_no DESC, s.id DESC LIMIT 1');
    $stmt->execute([(int)$current['chapter_sort_order'], (int)$current['chapter_sort_order'], (int)$current['sequence_no'], (int)$current['sequence_no'], $sessionId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function getNextStudySession(PDO $pdo, int $sessionId): ?array {
    $current = getStudySession($pdo, $sessionId);
    if (!$current) return null;
    $stmt = $pdo->prepare('SELECT s.*, c.title AS chapter_title, c.sort_order AS chapter_sort_order FROM study_sessions s LEFT JOIN study_chapters c ON c.id = s.chapter_id WHERE s.is_active = 1 AND c.is_active = 1 AND (c.sort_order > ? OR (c.sort_order = ? AND (s.sequence_no > ? OR (s.sequence_no = ? AND s.id > ?)))) ORDER BY c.sort_order ASC, s.sequence_no ASC, s.id ASC LIMIT 1');
    $stmt->execute([(int)$current['chapter_sort_order'], (int)$current['chapter_sort_order'], (int)$current['sequence_no'], (int)$current['sequence_no'], $sessionId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function getUserSessionAccessGrant(PDO $pdo, int $userId): ?array {
    if ($userId <= 0 || !tableExists($pdo, 'user_session_access')) return null;
    try {
        $stmt = $pdo->prepare('SELECT id, user_id, max_session_id, granted_by, created_at, updated_at FROM user_session_access WHERE user_id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $row = $stmt->fetch();
        return $row ?: null;
    } catch (Throwable $e) {
        return null;
    }
}

function canAccessStudySession(PDO $pdo, int $userId, int $sessionId): bool {
    $current = getStudySession($pdo, $sessionId);
    if (!$current) return false;

    // دسترسی ویژه مدیر: از ابتدای مسیر تا جلسه تعیین‌شده، همه جلسات قابل ورودند.
    $sessions = getActiveStudySessions($pdo);
    if ($sessions) {
        $currentIndex = null;
        $grant = getUserSessionAccessGrant($pdo, $userId);
        $grantIndex = null;
        $grantSessionId = $grant ? (int)($grant['max_session_id'] ?? 0) : 0;

        foreach ($sessions as $index => $item) {
            $sid = (int)$item['id'];
            if ($sid === $sessionId) $currentIndex = $index;
            if ($grantSessionId > 0 && $sid === $grantSessionId) $grantIndex = $index;
            if ($currentIndex !== null && ($grantSessionId <= 0 || $grantIndex !== null)) {
                // فقط وقتی هر دو رتبه پیدا شدند، می‌توان تصمیم گرفت.
                if ($grantIndex !== null && $currentIndex <= $grantIndex) return true;
            }
        }

        // اولین جلسه در هر حال قابل دسترسی است.
        if ($currentIndex === 0) return true;
    }

    $previous = getPreviousStudySession($pdo, $sessionId);
    if (!$previous) return true;
    return isSessionPassed($pdo, $userId, (int)$previous['id']);
}

function getNextStudySessionForUser(PDO $pdo, int $userId, ?array $progressMap = null): ?array {
    $sessions = getActiveStudySessions($pdo);
    if (!$sessions) return null;
    $progressMap = $progressMap ?? getUserSessionProgressMap($pdo, $userId);
    $previousCompleted = true;
    foreach ($sessions as $session) {
        $sid = (int)$session['id'];
        $completed = (int)($progressMap[$sid]['is_completed'] ?? 0) === 1;
        if ($previousCompleted && !$completed) return $session;
        $previousCompleted = $previousCompleted && $completed;
    }
    foreach (array_reverse($sessions) as $session) {
        if ((int)($progressMap[(int)$session['id']]['is_completed'] ?? 0) === 1) return $session;
    }
    return $sessions[0];
}

function getSessionQuestions(PDO $pdo, int $sessionId, bool $activeOnly = true): array {
    $sql = 'SELECT * FROM session_questions WHERE session_id = ?';
    if ($activeOnly) $sql .= ' AND is_active = 1';
    $sql .= ' ORDER BY question_number ASC, id ASC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$sessionId]);
    return $stmt->fetchAll();
}

function markSessionCompleted(PDO $pdo, int $userId, int $sessionId): void {
    $stmt = $pdo->prepare('INSERT INTO user_session_progress (user_id, session_id, is_completed, completed_at, viewed_at, created_at, updated_at) VALUES (?, ?, 1, NOW(), NOW(), NOW(), NOW()) ON DUPLICATE KEY UPDATE is_completed = 1, completed_at = NOW(), updated_at = NOW()');
    $stmt->execute([$userId, $sessionId]);
}

/** آخرین تلاش قبول‌شده کاربر برای یک جلسه را برمی‌گرداند. */
function getPassedAttempt(PDO $pdo, int $userId, int $sessionId): ?array {
    $stmt = $pdo->prepare('SELECT * FROM session_exam_attempts WHERE user_id = ? AND session_id = ? AND passed = 1 ORDER BY attempted_at DESC, id DESC LIMIT 1');
    $stmt->execute([$userId, $sessionId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * Site settings storage. The table is created lazily so the new admin settings
 * screen can work even before the optional migration is run.
 */
function ensureSiteSettingsTable(PDO $pdo): bool {
    static $ready = null;
    if ($ready !== null) return $ready;

    try {
        $pdo->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS site_settings (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    setting_key VARCHAR(120) NOT NULL,
    setting_value TEXT NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_site_settings_key (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL
        );
        $ready = true;
    } catch (Throwable $e) {
        error_log('Site settings table initialization failed: ' . $e->getMessage());
        $ready = false;
    }

    return $ready;
}

function getSiteSetting(PDO $pdo, string $key, string $default = ''): string {
    if ($key === '' || !tableExists($pdo, 'site_settings')) return $default;

    try {
        $stmt = $pdo->prepare('SELECT setting_value FROM site_settings WHERE setting_key = ? LIMIT 1');
        $stmt->execute([$key]);
        $value = $stmt->fetchColumn();
        return $value === false ? $default : (string)$value;
    } catch (Throwable $e) {
        error_log('Site setting read failed: ' . $e->getMessage());
        return $default;
    }
}

function getSiteSettings(PDO $pdo, array $keysWithDefaults = []): array {
    $result = [];
    foreach ($keysWithDefaults as $key => $default) {
        $result[(string)$key] = (string)$default;
    }

    if (!$keysWithDefaults || !tableExists($pdo, 'site_settings')) return $result;

    try {
        $keys = array_keys($keysWithDefaults);
        $placeholders = implode(',', array_fill(0, count($keys), '?'));
        $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM site_settings WHERE setting_key IN ($placeholders)");
        $stmt->execute($keys);
        foreach ($stmt->fetchAll() as $row) {
            $result[(string)$row['setting_key']] = (string)($row['setting_value'] ?? '');
        }
    } catch (Throwable $e) {
        error_log('Site settings bulk read failed: ' . $e->getMessage());
    }

    return $result;
}

function setSiteSetting(PDO $pdo, string $key, string $value): bool {
    if ($key === '' || !ensureSiteSettingsTable($pdo)) return false;

    try {
        $stmt = $pdo->prepare(
            'INSERT INTO site_settings (setting_key, setting_value, updated_at) VALUES (?, ?, NOW()) '
            . 'ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()'
        );
        $stmt->execute([$key, $value]);
        return true;
    } catch (Throwable $e) {
        error_log('Site setting write failed: ' . $e->getMessage());
        return false;
    }
}

/**
 * Binary site media is stored directly in MySQL so admin-uploaded assets are not
 * dependent on a writable public filesystem. Currently used for the invite QR.
 */
function ensureSiteMediaTable(PDO $pdo): bool {
    static $ready = null;
    if ($ready !== null) return $ready;
    try {
        $pdo->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS site_media (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    media_key VARCHAR(120) NOT NULL,
    mime_type VARCHAR(80) NOT NULL,
    original_name VARCHAR(255) NULL,
    media_data MEDIUMBLOB NOT NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_site_media_key (media_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL
        );
        $ready = true;
    } catch (Throwable $e) {
        error_log('Site media table initialization failed: ' . $e->getMessage());
        $ready = false;
    }
    return $ready;
}

function setSiteMedia(PDO $pdo, string $key, string $mimeType, string $data, ?string $originalName = null): bool {
    if ($key === '' || $data === '' || !ensureSiteMediaTable($pdo)) return false;
    try {
        $stmt = $pdo->prepare(
            'INSERT INTO site_media (media_key, mime_type, original_name, media_data, updated_at) VALUES (?, ?, ?, ?, NOW()) '
            . 'ON DUPLICATE KEY UPDATE mime_type = VALUES(mime_type), original_name = VALUES(original_name), media_data = VALUES(media_data), updated_at = NOW()'
        );
        $stmt->bindValue(1, $key, PDO::PARAM_STR);
        $stmt->bindValue(2, $mimeType, PDO::PARAM_STR);
        $stmt->bindValue(3, $originalName, PDO::PARAM_STR);
        $stmt->bindValue(4, $data, PDO::PARAM_LOB);
        $stmt->execute();
        return true;
    } catch (Throwable $e) {
        error_log('Site media write failed: ' . $e->getMessage());
        return false;
    }
}

function getSiteMedia(PDO $pdo, string $key): ?array {
    if ($key === '' || !tableExists($pdo, 'site_media')) return null;
    try {
        $stmt = $pdo->prepare('SELECT media_key, mime_type, original_name, media_data, updated_at FROM site_media WHERE media_key = ? LIMIT 1');
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        return $row ?: null;
    } catch (Throwable $e) {
        error_log('Site media read failed: ' . $e->getMessage());
        return null;
    }
}

function getSiteMediaDataUri(PDO $pdo, string $key): ?string {
    $media = getSiteMedia($pdo, $key);
    if (!$media) return null;
    $mime = trim((string)($media['mime_type'] ?? ''));
    $data = $media['media_data'] ?? null;
    if ($mime === '' || !is_string($data) || $data === '') return null;
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

function getSiteMediaUrl(PDO $pdo, string $key, string $fallback = ''): string {
    return getSiteMedia($pdo, $key) ? ('site_media.php?key=' . rawurlencode($key)) : $fallback;
}

function tableExists(PDO $pdo, string $table): bool {
    static $cache = [];
    if (array_key_exists($table, $cache)) return $cache[$table];
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?");
        $stmt->execute([$table]);
        return $cache[$table] = ((int)$stmt->fetchColumn() === 1);
    } catch (Throwable $e) {
        return $cache[$table] = false;
    }
}

function deleteUserData(PDO $pdo, int $userId): void {
    if ($userId <= 0) throw new InvalidArgumentException('شناسه کاربر نامعتبر است.');
    $pdo->beginTransaction();
    try {
        if (tableExists($pdo, 'session_exam_attempts') && tableExists($pdo, 'session_exam_answers')) {
            $stmt = $pdo->prepare('DELETE FROM session_exam_answers WHERE attempt_id IN (SELECT id FROM session_exam_attempts WHERE user_id = ?)');
            $stmt->execute([$userId]);
        }
        foreach (['session_exam_attempts', 'user_session_progress', 'user_skills', 'user_remember_tokens', 'user_session_access'] as $table) {
            if (!tableExists($pdo, $table)) continue;
            $stmt = $pdo->prepare("DELETE FROM {$table} WHERE user_id = ?");
            $stmt->execute([$userId]);
        }
        $stmt = $pdo->prepare('DELETE FROM users WHERE id = ?');
        $stmt->execute([$userId]);
        if ($stmt->rowCount() !== 1) throw new RuntimeException('کاربر پیدا نشد.');
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}
