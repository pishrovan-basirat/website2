<?php
declare(strict_types=1);

// Session hardening: must be configured before session_start().
$https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
session_name('pb_session');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_secure', $https ? '1' : '0');
ini_set('session.cookie_samesite', 'Lax');
session_set_cookie_params([
    'lifetime' => 31536000,
    'path' => '/',
    'secure' => $https,
    'httponly' => true,
    'samesite' => 'Lax',
]);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

date_default_timezone_set('Asia/Tehran');

// Keep real credentials outside this file. Create includes/config.local.php.
$localConfig = __DIR__ . '/config.local.php';
if (!is_file($localConfig)) {
    http_response_code(500);
    exit('تنظیمات اتصال به دیتابیس کامل نیست.');
}
require $localConfig;

$requiredConfig = ['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASS'];
foreach ($requiredConfig as $key) {
    if (!defined($key)) {
        http_response_code(500);
        exit('تنظیمات اتصال به دیتابیس ناقص است.');
    }
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );

    // برای NOW()/CURRENT_TIMESTAMP در همین اتصال، timezone ایران را در صورت پشتیبانی تنظیم می‌کنیم.
    try {
        $pdo->exec("SET time_zone = '+03:30'");
    } catch (Throwable $e) {
        error_log('MySQL session timezone could not be set to Iran: ' . $e->getMessage());
    }
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    http_response_code(500);
    exit('خطا در اتصال به سامانه. لطفاً بعداً دوباره تلاش کنید.');
}

function getUser(PDO $pdo): ?array {
    if (!isLoggedIn()) {
        return null;
    }

    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([(int) $_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (!$user) {
        unset($_SESSION['user_id'], $_SESSION['role'], $_SESSION['full_name']);
        return null;
    }

    return $user;
}

function now(): string {
    return date('Y-m-d H:i:s');
}
