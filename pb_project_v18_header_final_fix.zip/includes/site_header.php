<?php
declare(strict_types=1);

$isHeaderLoggedIn = isLoggedIn();
$headerUser = $isHeaderLoggedIn ? getUser($pdo) : null;
$headerFullName = trim((string)($headerUser['full_name'] ?? 'کاربر'));
?>
<style>
/* ===== Shared logged-in header ===== */
.site-header--minimal{
  position:sticky!important;
  top:0!important;
  width:100%;
  margin:0 0 18px;
  z-index:7000;
  padding:10px 0 8px;
}
.site-header-ui .site-header-inner{
  position:relative;
  width:100%;
  min-height:76px;
  box-sizing:border-box;
  display:grid;
  grid-template-columns:60px minmax(0,1fr) 60px;
  align-items:center;
  gap:10px;
  direction:ltr;
  padding:9px 12px;
  border:1px solid rgba(255,255,255,.66);
  border-radius:24px;
  background:rgba(255,255,255,.55);
  backdrop-filter:blur(22px) saturate(150%);
  -webkit-backdrop-filter:blur(22px) saturate(150%);
  box-shadow:0 16px 38px rgba(0,0,0,.08),inset 0 1px 0 rgba(255,255,255,.82);
}
.site-header-ui .site-brand-name{
  grid-column:2;
  grid-row:1;
  justify-self:center;
  min-width:0;
  max-width:100%;
  color:#0d5a3d;
  text-decoration:none;
  font-size:clamp(22px,3vw,32px);
  line-height:1.2;
  font-weight:900!important;
  letter-spacing:-.02em;
  text-align:center;
  white-space:nowrap;
  overflow:hidden;
  text-overflow:ellipsis;
  transition:opacity .18s ease,transform .18s ease;
}
.site-header-ui .site-brand-name:hover{opacity:.88;transform:translateY(-1px)}

.site-header-ui .shared-glass-btn{
  position:relative;
  top:auto;
  left:auto;
  right:auto;
  width:56px;
  height:56px;
  flex:0 0 56px;
  border-radius:18px;
  border:1px solid rgba(0,200,100,.30);
  cursor:pointer;
  z-index:2;
  padding:0;
  display:flex;
  align-items:center;
  justify-content:center;
  background:linear-gradient(135deg,rgba(255,255,255,.85) 0%,rgba(0,255,136,.15) 50%,rgba(255,255,255,.70) 100%);
  backdrop-filter:blur(16px) saturate(170%);
  -webkit-backdrop-filter:blur(16px) saturate(170%);
  box-shadow:0 8px 30px rgba(0,200,100,.28),0 0 50px rgba(0,255,136,.15),inset 0 1px 1px rgba(255,255,255,.9),inset 0 -1px 1px rgba(0,255,136,.35);
  transition:transform .4s cubic-bezier(.34,1.56,.64,1),box-shadow .3s ease,border-color .3s ease;
  overflow:hidden;
  isolation:isolate;
  will-change:transform;
  -webkit-tap-highlight-color:transparent;
}
.site-header-ui .shared-glass-btn::before{
  content:'';
  position:absolute;
  inset:-60%;
  z-index:-1;
  background:radial-gradient(circle at 30% 40%,rgba(0,255,136,.75),transparent 40%),radial-gradient(circle at 70% 60%,rgba(0,255,170,.5),transparent 42%),radial-gradient(circle at 50% 20%,rgba(255,255,255,.5),transparent 35%);
  filter:blur(14px);
  opacity:.85;
  animation:sharedLiquidMove 9s ease-in-out infinite;
  animation-play-state:paused;
}
.site-header-ui .shared-glass-btn:hover::before,.site-header-ui .shared-glass-btn:focus-visible::before{animation-play-state:running}
.site-header-ui .shared-glass-btn::after{
  content:'';
  position:absolute;
  top:2px;
  left:15%;
  right:15%;
  height:42%;
  border-radius:18px 18px 50% 50% / 18px 18px 30% 30%;
  background:linear-gradient(to bottom,rgba(255,255,255,.85),transparent);
  pointer-events:none;
  filter:blur(1px);
}
.site-header-ui .shared-glass-btn:hover{transform:scale(1.08);border-color:rgba(0,200,100,.7);box-shadow:0 12px 40px rgba(0,200,100,.4),0 0 70px rgba(0,255,136,.3),inset 0 1px 2px rgba(255,255,255,.95),inset 0 -1px 2px rgba(0,255,136,.5)}
.site-header-ui .shared-glass-btn:active{transform:scale(.96)}
.site-header-ui .shared-user-btn{grid-column:1;grid-row:1}
.site-header-ui .shared-hamburger{grid-column:3;grid-row:1;flex-direction:column;gap:6px}

.site-header-ui .shared-hamburger .line{display:block;width:26px;height:2.5px;border-radius:3px;background:#1b7a2e;box-shadow:0 0 6px rgba(0,200,100,.8),0 0 12px rgba(0,255,136,.5);transition:transform .5s cubic-bezier(.68,-.55,.27,1.55),opacity .35s ease,width .4s ease;transform-origin:center;position:relative;z-index:2}
.site-header-ui .shared-hamburger.active .line:nth-child(1){transform:translateY(8.5px) rotate(45deg);width:28px}
.site-header-ui .shared-hamburger.active .line:nth-child(2){opacity:0;transform:scaleX(0)}
.site-header-ui .shared-hamburger.active .line:nth-child(3){transform:translateY(-8.5px) rotate(-45deg);width:28px}
.site-header-ui .shared-user-btn svg{width:26px;height:26px;stroke:#1b7a2e;stroke-width:2.2;fill:none;stroke-linecap:round;stroke-linejoin:round;filter:drop-shadow(0 0 4px rgba(0,200,100,.7));transition:transform .4s cubic-bezier(.34,1.56,.64,1);position:relative;z-index:2}
.site-header-ui .shared-user-btn:hover svg{transform:scale(1.1)}
.site-header-ui .shared-user-btn.active svg{transform:scale(.95)}
@keyframes sharedLiquidMove{0%,100%{transform:translate(0,0) rotate(0deg) scale(1)}33%{transform:translate(-8%,10%) rotate(120deg) scale(1.1)}66%{transform:translate(10%,-8%) rotate(240deg) scale(.9)}}

.site-header-ui .shared-glass-panel{position:absolute;top:0;width:340px;max-width:calc(100vw - 48px);padding:22px;border-radius:28px;z-index:2;background:linear-gradient(135deg,rgba(255,255,255,.59) 0%,rgba(255,255,255,.45) 45%,rgba(255,255,255,.59) 100%);backdrop-filter:blur(20px) saturate(170%);-webkit-backdrop-filter:blur(20px) saturate(170%);border:1px solid rgba(0,200,100,.25);box-shadow:0 20px 60px rgba(0,200,100,.22),0 0 100px rgba(0,255,136,.12),inset 0 1px 1px rgba(255,255,255,.95),inset 0 -1px 1px rgba(0,255,136,.3);overflow:hidden;isolation:isolate;opacity:0;visibility:hidden;transform:translateY(-20px) scale(.92);transition:opacity .4s ease,transform .5s cubic-bezier(.34,1.56,.64,1),visibility .4s}
.site-header-ui .shared-glass-panel::before{content:'';position:absolute;inset:-60%;z-index:-1;background:radial-gradient(circle at 20% 30%,rgba(0,255,136,.6),transparent 35%),radial-gradient(circle at 75% 65%,rgba(0,255,170,.5),transparent 38%),radial-gradient(circle at 50% 15%,rgba(255,255,255,.5),transparent 30%),radial-gradient(circle at 85% 25%,rgba(0,200,100,.45),transparent 35%);filter:blur(22px);opacity:.9;animation:sharedLiquidMove 11s ease-in-out infinite;animation-play-state:paused}
.site-header-ui .shared-glass-panel.open::before{animation-play-state:running}
.site-header-ui .shared-glass-panel::after{content:'';position:absolute;top:2px;left:8%;right:8%;height:35%;border-radius:28px 28px 50% 50% / 28px 28px 30% 30%;background:linear-gradient(to bottom,rgba(255,255,255,.7),rgba(255,255,255,.1) 60%,transparent);pointer-events:none;filter:blur(1.5px)}
.site-header-ui .shared-glass-panel.right{right:24px;transform-origin:top right}
.site-header-ui .shared-glass-panel.left{left:24px;transform-origin:top left}
.site-header-ui .shared-glass-panel.open{opacity:1;visibility:visible;transform:translateY(0) scale(1)}
.site-header-ui .shared-menu-list{list-style:none;display:flex;flex-direction:column;gap:6px;position:relative;z-index:2;margin:0;padding:0}
.site-header-ui .shared-menu-link{display:flex;align-items:center;gap:14px;padding:13px 16px;border-radius:16px;text-decoration:none;color:#1b5e20;font-size:15px;font-weight:600;position:relative;overflow:hidden;transition:background .3s ease,color .3s ease,transform .3s cubic-bezier(.34,1.56,.64,1),box-shadow .3s ease}
.site-header-ui .shared-menu-link:hover{background:linear-gradient(135deg,rgba(0,255,136,.35),rgba(0,255,170,.18));color:#0d3b1f;transform:translateX(-6px);box-shadow:inset 0 1px 1px rgba(255,255,255,.8),0 4px 20px rgba(0,200,100,.25)}
.site-header-ui .shared-menu-link .icon{font-size:20px;width:30px;height:30px;display:flex;align-items:center;justify-content:center;border-radius:10px;background:linear-gradient(135deg,rgba(0,255,136,.25),rgba(255,255,255,.5));border:1px solid rgba(0,200,100,.25);flex-shrink:0}
.site-header-ui .shared-menu-link:hover .icon{background:linear-gradient(135deg,rgba(0,255,136,.55),rgba(0,255,170,.3));transform:scale(1.12) rotate(-6deg);box-shadow:0 4px 18px rgba(0,200,100,.5),inset 0 1px 1px rgba(255,255,255,.85)}
.site-header-ui .shared-menu-link.active{background:linear-gradient(135deg,rgba(0,255,136,.45),rgba(0,255,170,.2));color:#0d3b1f;box-shadow:inset 0 1px 1px rgba(255,255,255,.85),inset 0 -1px 1px rgba(0,200,100,.4),0 4px 20px rgba(0,200,100,.3)}
.site-header-ui .shared-menu-link.active::after{content:'';position:absolute;right:4px;top:50%;transform:translateY(-50%);width:4px;height:20px;border-radius:4px;background:#00cc66;box-shadow:0 0 12px #00cc66,0 0 22px rgba(0,255,136,.7)}
.site-header-ui .shared-solid-btn{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:15px 20px;border-radius:18px;font-family:inherit;font-size:15px;font-weight:900;color:#fff;text-decoration:none;cursor:pointer;position:relative;overflow:hidden;isolation:isolate;border:1px solid rgba(255,255,255,.4);box-shadow:0 8px 25px rgba(0,200,100,.5),0 0 40px rgba(0,255,136,.3),inset 0 1px 2px rgba(255,255,255,.7),inset 0 -1px 2px rgba(0,80,40,.4);background:linear-gradient(135deg,#00cc66,#00994d);text-shadow:0 1px 4px rgba(0,80,40,.4);transition:transform .25s cubic-bezier(.34,1.56,.64,1),box-shadow .25s ease,background .2s ease}
.site-header-ui .shared-solid-btn::before{content:'';position:absolute;top:2px;left:12%;right:12%;height:45%;border-radius:18px;background:linear-gradient(to bottom,rgba(255,255,255,.55),transparent);pointer-events:none}
.site-header-ui .shared-solid-btn:hover{transform:translateY(-2px) scale(1.03);box-shadow:0 12px 35px rgba(0,200,100,.7),0 0 60px rgba(0,255,136,.4),inset 0 1px 2px rgba(255,255,255,.85),inset 0 -1px 2px rgba(0,80,40,.4)}
.site-header-ui .shared-solid-btn:active{transform:scale(.97)}
.site-header-ui .shared-logout-btn{margin-top:10px;background:linear-gradient(135deg,#ff5a52,#d9362e)!important;box-shadow:0 10px 28px rgba(217,54,46,.28),0 0 42px rgba(255,59,48,.12),inset 0 1px 2px rgba(255,255,255,.72),inset 0 -1px 2px rgba(130,20,15,.28)!important;text-shadow:0 1px 4px rgba(130,20,15,.25)}
.site-header-ui .shared-user-content{position:relative;z-index:2;display:flex;flex-direction:column;gap:10px}
.site-header-ui .shared-greeting{padding:6px 4px;text-align:center;color:#1b5e20;font-weight:800;line-height:1.9;font-size:14px}
.site-header-ui .shared-overlay{position:fixed;inset:0;background:rgba(255,255,255,.25);backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px);opacity:0;visibility:hidden;transition:opacity .4s ease,visibility .4s;z-index:0;pointer-events:none}
.site-header-ui .shared-overlay.open{opacity:1;visibility:visible}

@media(max-width:700px){
  .site-header--minimal{margin-bottom:12px;padding:8px 0 6px}
  .site-header-ui .site-header-inner{min-height:66px;grid-template-columns:52px minmax(0,1fr) 52px;gap:6px;padding:7px 8px;border-radius:20px}
  .site-header-ui .site-brand-name{font-size:20px}
  .site-header-ui .shared-glass-btn{width:50px;height:50px;flex-basis:50px;border-radius:17px}
  .site-header-popovers .shared-glass-panel{top:0;width:calc(100vw - 32px);padding:18px}
  .site-header-popovers .shared-glass-panel.right{right:16px}
  .site-header-popovers .shared-glass-panel.left{left:16px}
}
.site-header-popovers{position:absolute!important;top:var(--site-header-popover-top,0px)!important;inset-inline:0;bottom:auto;width:100%;height:0;margin:0!important;padding:0!important;z-index:100000;pointer-events:none;overflow:visible;background:none;border:0;box-shadow:none;backdrop-filter:none;-webkit-backdrop-filter:none}
.site-header ~ .site-header-popovers{pointer-events:none}
.site-header-popovers .shared-glass-panel{position:absolute;top:0;pointer-events:auto}
.site-header-popovers .shared-overlay{pointer-events:none}
.site-header-popovers .shared-overlay.open{pointer-events:auto}

/* Page-specific header scrolling policy: home is sticky; study header is static. */
body.home-page .site-header.site-header--minimal{position:-webkit-sticky!important;position:sticky!important;top:0!important;}
body.study-page .site-header.site-header--minimal{position:static!important;top:auto!important;}

/* Keep the header controls crisp while the page behind the open panel is blurred. */
.site-header-ui .site-header-inner,
.site-header-ui .shared-glass-btn{filter:none!important;isolation:isolate;}
.site-header--minimal{z-index:100002!important;isolation:isolate!important;overflow:visible!important;}
.site-header--minimal .site-header-inner{position:relative;z-index:3;}
.site-header--minimal .shared-glass-btn{z-index:4;}
</style>
<header class="site-header site-header--minimal site-header-ui" data-site-header>
  <div class="site-header-inner">
    <a href="index.php" class="site-brand-name" aria-label="پیشروان بصیــرت">پیشروان بصیــرت</a>
    <?php if ($isHeaderLoggedIn): ?>
      <button class="shared-glass-btn shared-user-btn" id="sharedUserBtn" type="button" aria-label="حساب کاربری" aria-expanded="false">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
      </button>
      <button class="shared-glass-btn shared-hamburger" id="sharedHamburgerBtn" type="button" aria-label="منو" aria-expanded="false">
        <span class="line"></span><span class="line"></span><span class="line"></span>
      </button>
    <?php endif; ?>
  </div>
</header>
  <?php if ($isHeaderLoggedIn): ?>
    <div class="site-header-popovers site-header-ui" id="siteHeaderPopovers">
      <div class="shared-overlay" id="sharedHeaderOverlay"></div>
      <nav class="shared-glass-panel right" id="sharedMenuPanel" aria-label="منوی اصلی">
        <ul class="shared-menu-list">
          <li><a class="shared-menu-link" href="home.php"><span class="icon">🏠</span>خانه</a></li>
          <li><a class="shared-menu-link" href="profile.php"><span class="icon">👤</span>بخش کاربری</a></li>
          <li><a class="shared-menu-link" href="sessions.php"><span class="icon">📚</span>مسیر مطالعه</a></li>
          <li><a class="shared-menu-link" href="charter.php"><span class="icon">📜</span>مرامنامه</a></li>
          <li><a class="shared-menu-link" href="invite.php"><span class="icon">🤝</span>دعوت از دوستان</a></li>
        </ul>
      </nav>
      <aside class="shared-glass-panel left" id="sharedUserPanel" aria-label="حساب کاربری">
        <div class="shared-user-content">
          <div class="shared-greeting">کاربر <?= e($headerFullName) ?> عزیز، خوش آمدید 🌷</div>
          <a class="shared-solid-btn shared-logout-btn" href="logout.php">خروج از حساب</a>
        </div>
      </aside>
    </div>
    <script>
    (function(){
      const header=document.querySelector('[data-site-header]');
      const layer=document.getElementById('siteHeaderPopovers');
      const hb=document.getElementById('sharedHamburgerBtn');
      const ub=document.getElementById('sharedUserBtn');
      const mp=document.getElementById('sharedMenuPanel');
      const up=document.getElementById('sharedUserPanel');
      const ov=document.getElementById('sharedHeaderOverlay');
      if(!header||!layer||!hb||!ub||!mp||!up||!ov) return;
      let openPanel=null;
      function syncLayerPosition(){
        const rect=header.getBoundingClientRect();
        const top=Math.max(0, rect.bottom + window.scrollY + 8);
        layer.style.setProperty('--site-header-popover-top', top+'px');
      }
      function closeAll(){
        hb.classList.remove('active'); ub.classList.remove('active');
        hb.setAttribute('aria-expanded','false'); ub.setAttribute('aria-expanded','false');
        mp.classList.remove('open'); up.classList.remove('open'); ov.classList.remove('open');
        openPanel=null;
      }
      function toggle(panel){
        if(openPanel===panel){closeAll();return;}
        closeAll();
        syncLayerPosition();
        if(panel==='menu'){hb.classList.add('active');hb.setAttribute('aria-expanded','true');mp.classList.add('open');}
        else {ub.classList.add('active');ub.setAttribute('aria-expanded','true');up.classList.add('open');}
        ov.classList.add('open'); openPanel=panel;
      }
      hb.addEventListener('click',()=>toggle('menu'));
      ub.addEventListener('click',()=>toggle('user'));
      ov.addEventListener('click',closeAll);
      document.addEventListener('keydown',e=>{if(e.key==='Escape')closeAll();});
      window.addEventListener('resize',syncLayerPosition,{passive:true});
      if(window.ResizeObserver){ new ResizeObserver(syncLayerPosition).observe(header); }
      syncLayerPosition();
    })();
    </script>
  <?php endif; ?>
