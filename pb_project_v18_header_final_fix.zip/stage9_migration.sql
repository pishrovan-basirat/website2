ALTER TABLE daily_notes ADD COLUMN title VARCHAR(255) NOT NULL DEFAULT 'نکته امروز' AFTER note_date;
UPDATE daily_notes SET title = 'نکته امروز' WHERE title IS NULL OR title = '';
