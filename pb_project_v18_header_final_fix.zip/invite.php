<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

$user = isLoggedIn() ? getUser($pdo) : null;
$inviteSettings = getSiteSettings($pdo, [
    'invite_qr_image' => 'assets/images/invite-qrcode-test.png',
    'invite_copy_url' => 'https://test.ir',
    'invite_share_url' => 'https://test.ir',
    'invite_sms_url' => 'sms:?&body=سلام، شما را به پیشروان بصیرت دعوت می‌کنم: https://test.ir',
]);
$inviteQrImage = getSiteMediaUrl($pdo, 'invite_qr', $inviteSettings['invite_qr_image']);
$inviteCopyUrl = $inviteSettings['invite_copy_url'];
$inviteShareUrl = $inviteSettings['invite_share_url'];
$inviteSmsUrl = $inviteSettings['invite_sms_url'];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>دعوت از دوستان | پیشروان بصیرت</title>
    <link rel="stylesheet" href="assets/css/style.css?v=20261001-invite3">
    <style>
        body.invite-page {
            display: block;
            min-height: 100vh;
            padding: 0;
            overflow-x: hidden;
        }
        body.invite-page .site-shell {
            width: min(1100px, 100%);
            margin: 0 auto;
            padding: 20px;
        }
        .invite-main {
            width: min(820px, 100%);
            margin: 28px auto 46px;
        }
        .invite-card {
            background: rgba(255,255,255,.72);
            border: 1px solid rgba(255,255,255,.72);
            border-radius: 30px;
            box-shadow: 0 24px 60px rgba(0,0,0,.08), inset 0 1px 0 rgba(255,255,255,.88);
            padding: 34px;
        }
        .invite-title {
            margin: 0 0 18px;
            text-align: center;
            font-size: clamp(30px, 4vw, 42px);
            font-weight: 900;
            color: #165f4b;
        }
        .invite-intro {
            margin: 0 auto;
            max-width: 700px;
            text-align: center;
            font-size: 18px;
            line-height: 2.25;
            color: #303236;
        }
        .invite-section {
            margin-top: 34px;
            padding-top: 28px;
            border-top: 1px solid rgba(22,95,75,.10);
        }
        .invite-section-title {
            margin: 0 0 10px;
            text-align: center;
            color: #165f4b;
            font-size: 22px;
            font-weight: 850;
        }
        .invite-section-text {
            margin: 0 auto 22px;
            max-width: 620px;
            text-align: center;
            color: #62666b;
            font-size: 15px;
            line-height: 2.1;
        }
        .qr-wrap {
            display: flex;
            justify-content: center;
            margin: 8px auto 18px;
        }
        .qr-image {
            display: block;
            width: min(420px, 86vw);
            height: auto;
            aspect-ratio: 3 / 4;
            object-fit: contain;
            border-radius: 24px;
            box-shadow: 0 18px 38px rgba(22,95,75,.10);
            border: 1px solid rgba(22,95,75,.08);
            -webkit-user-drag: none;
            user-select: none;
        }
        .invite-note {
            margin: 0 auto;
            max-width: 560px;
            text-align: center;
            color: #5c6268;
            font-size: 14px;
            line-height: 2;
        }
        .share-box {
            margin-top: 18px;
            padding: 24px;
            border-radius: 24px;
            background: linear-gradient(145deg, rgba(255,255,255,.88), rgba(238,248,244,.78));
            border: 1px solid rgba(22,95,75,.10);
            box-shadow: inset 0 1px 0 rgba(255,255,255,.92);
            text-align: center;
        }
        .share-title {
            margin: 0 0 10px;
            color: #165f4b;
            font-size: 18px;
            font-weight: 800;
        }
        .share-text {
            margin: 0 auto 18px;
            max-width: 620px;
            color: #60656b;
            font-size: 14px;
            line-height: 2;
        }
        .share-url-wrap {
            display: flex;
            direction: ltr;
            align-items: stretch;
            justify-content: center;
            gap: 8px;
            margin: 0 auto 18px;
            max-width: 100%;
        }
        .share-url {
            display: flex;
            direction: ltr;
            align-items: center;
            justify-content: center;
            min-height: 44px;
            min-width: 0;
            flex: 1 1 auto;
            padding: 0 16px;
            border-radius: 14px;
            background: rgba(255,255,255,.90);
            border: 1px solid rgba(22,95,75,.12);
            color: #165f4b;
            font-size: 14px;
            font-weight: 700;
            user-select: all;
            overflow-wrap: anywhere;
        }
        .share-copy-icon {
            flex: 0 0 44px;
            width: 44px;
            min-height: 44px;
            border: 1px solid rgba(22,95,75,.12);
            border-radius: 14px;
            background: #fff;
            color: #165f4b;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: transform .18s ease, box-shadow .18s ease, background-color .18s ease;
        }
        .share-copy-icon:hover { transform: translateY(-1px); box-shadow: 0 8px 18px rgba(22,95,75,.10); background: #f8fcfa; }
        .share-copy-icon:active { transform: translateY(0); }
        .share-copy-icon svg { width: 20px; height: 20px; display: block; }
        .share-actions {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 10px;
        }
        .share-btn {
            appearance: none;
            border: 1px solid transparent;
            font: inherit;
            font-size: 14px;
            font-weight: 800;
            min-height: 48px;
            padding: 0 18px;
            border-radius: 14px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            line-height: 1.35;
            text-align: center;
            text-decoration: none;
            transition: transform .18s ease, box-shadow .18s ease, background-color .18s ease;
            -webkit-user-select: none;
            user-select: none;
        }
        .share-btn:hover { transform: translateY(-2px); }
        .share-btn:active { transform: translateY(0); }
        .share-primary {
            color: #fff;
            background: linear-gradient(135deg, #1fa07e, #165f4b);
            box-shadow: 0 12px 24px rgba(22,95,75,.16);
        }
        .share-secondary {
            color: #165f4b;
            background: #fff;
            border-color: rgba(22,95,75,.14);
        }
        .share-secondary:hover { box-shadow: 0 10px 22px rgba(22,95,75,.08); }
        .share-status {
            min-height: 22px;
            margin-top: 12px;
            font-size: 12px;
            color: #61716b;
        }
        @media (max-width: 700px) {
            body.invite-page .site-shell { padding: 10px; }
            .invite-main { margin-top: 16px; }
            .invite-card { padding: 24px 18px; border-radius: 24px; }
            .invite-title { font-size: 28px; }
            .invite-intro { font-size: 16px; line-height: 2.15; }
            .invite-section-title { font-size: 19px; }
            .invite-section-text, .share-text { font-size: 13.5px; }
            .share-box { padding: 20px 15px; }
            .share-url-wrap { width: 100%; }
            .share-copy-icon { flex-basis: 44px; width: 44px; }
            .share-actions { flex-direction: column; }
            .share-btn { width: 100%; }
        }
    </style>
</head>
<body class="user-page invite-page">
    <div class="bg-mesh"><div class="blob blob-1"></div><div class="blob blob-2"></div><div class="blob blob-3"></div></div>
    <?php require __DIR__ . '/includes/page_loader.php'; ?>
    <div class="site-shell">
        <?php require __DIR__ . '/includes/site_header.php'; ?>
        <main class="invite-main">
            <article class="invite-card">
                <h1 class="invite-title">دعوت از دوستان</h1>
                <p class="invite-intro">دوستان و همراهان خود را به این مسیر امام زمانی دعوت کنید و در جهت احیای فریضه امر به معروف و نهی از منکر عامل باشید.</p>

                <section class="invite-section">
                    <h2 class="invite-section-title">دعوت از طریق رمزینه (QrCode)</h2>
                    <div class="qr-wrap">
                        <img class="qr-image" src="<?= e($inviteQrImage) ?>" alt="رمزینه دعوت به پیشروان بصیرت" draggable="false">
                    </div>
                    <p class="invite-note">دوستان خود را از طریق اسکن این رمزینه، به پیشروان بصیرت دعوت کنید.</p>
                </section>

                <section class="invite-section">
                    <div class="share-box">
                        <h2 class="share-title">ارسال نشانی تارنما(سایت)</h2>
                        <p class="share-text">همچنین میتوانید از روش های زیر، نشانی تارنمای(سایت) پیشروان بصیرت را برای آنان ارسال کنید.</p>
                        <div class="share-url-wrap">
                            <div class="share-url" aria-label="نشانی سایت"><?= e($inviteCopyUrl) ?></div>
                            <button type="button" class="share-copy-icon" data-copy-link aria-label="کپی نشانی سایت" title="کپی نشانی سایت">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                    <rect x="9" y="9" width="11" height="11" rx="2"></rect>
                                    <path d="M6 15H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v1"></path>
                                </svg>
                            </button>
                        </div>
                        <div class="share-actions">
                            <button type="button" class="share-btn share-primary" data-share-native>اشتراک‌گذاری</button>
                            <a class="share-btn share-secondary" href="<?= e($inviteSmsUrl) ?>">ارسال پیامک</a>
                        </div>
                        <div class="share-status" data-share-status aria-live="polite"></div>
                    </div>
                </section>
            </article>
        </main>
        <?php require __DIR__ . '/includes/site_footer.php'; ?>
    </div>
    <script src="assets/js/app.js?v=20261001-v13" defer></script>
    <script>
    (function () {
        const copyUrl = <?= json_encode($inviteCopyUrl, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
        const shareUrl = <?= json_encode($inviteShareUrl, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
        const title = 'پیشروان بصیرت';
        const text = 'دوستان و همراهان خود را به پیشروان بصیرت دعوت کنید.';
        const shareButton = document.querySelector('[data-share-native]');
        const copyButton = document.querySelector('[data-copy-link]');
        const status = document.querySelector('[data-share-status]');

        function setStatus(message) {
            if (status) status.textContent = message || '';
        }

        async function copyLink() {
            try {
                if (navigator.clipboard && window.isSecureContext) {
                    await navigator.clipboard.writeText(copyUrl);
                } else {
                    const area = document.createElement('textarea');
                    area.value = copyUrl;
                    area.setAttribute('readonly', '');
                    area.style.position = 'fixed';
                    area.style.opacity = '0';
                    document.body.appendChild(area);
                    area.select();
                    document.execCommand('copy');
                    area.remove();
                }
                setStatus('نشانی سایت کپی شد.');
            } catch (error) {
                setStatus('کپی نشانی انجام نشد؛ می‌توانید نشانی را انتخاب و کپی کنید.');
            }
        }

        if (shareButton) {
            shareButton.addEventListener('click', async function () {
                if (navigator.share) {
                    try {
                        await navigator.share({ title, text, url: shareUrl });
                        setStatus('');
                    } catch (error) {
                        if (error && error.name !== 'AbortError') setStatus('اشتراک‌گذاری در دسترس نبود.');
                    }
                } else {
                    await copyLink();
                }
            });
        }
        if (copyButton) copyButton.addEventListener('click', copyLink);
    })();
    </script>
</body>
</html>
