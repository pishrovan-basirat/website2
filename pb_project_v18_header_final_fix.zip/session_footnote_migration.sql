-- اضافه‌کردن پاورقی به جلسات مطالعه در دیتابیس موجود
-- این فایل را فقط یک‌بار روی دیتابیس فعلی اجرا کنید.
SET @has_footnote := (
    SELECT COUNT(*)
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'study_sessions'
      AND COLUMN_NAME = 'footnote'
);
SET @sql := IF(
    @has_footnote = 0,
    'ALTER TABLE study_sessions ADD COLUMN footnote TEXT NULL AFTER summary',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
