-- Persistent login token storage for the PWA/browser.
-- No foreign key is used intentionally, so this works with existing users.id definitions.
CREATE TABLE IF NOT EXISTS user_remember_tokens (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    token_hash CHAR(64) NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_used_at DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_user_remember_token_hash (token_hash),
    KEY idx_user_remember_user (user_id),
    KEY idx_user_remember_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
