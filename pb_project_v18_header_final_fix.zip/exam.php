<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

require_login('login.php');
$userId = (int)$_SESSION['user_id'];
$error = '';

if (!studySessionTablesAvailable($pdo)) {
    http_response_code(503);
    $session = null;
    $questions = [];
    $progress = null;
    $sessionNumber = 0;
} else {
    $sessionId = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? 0);
    if ($sessionId <= 0) {
        $next = getNextStudySessionForUser($pdo, $userId);
        $sessionId = $next ? (int)$next['id'] : 0;
    }
    $session = $sessionId > 0 ? getStudySession($pdo, $sessionId) : null;
    $activeSessions = getActiveStudySessions($pdo);
    $positionMap = [];
    foreach ($activeSessions as $index => $item) $positionMap[(int)$item['id']] = $index + 1;
    $sessionNumber = $session ? ($positionMap[(int)$session['id']] ?? 1) : 0;

    if (!$session) {
        $error = 'جلسه موردنظر پیدا نشد.';
        $progress = null;
        $questions = [];
    } elseif (!canAccessStudySession($pdo, $userId, $sessionId)) {
        header('Location: sessions.php?locked=1');
        exit;
    } else {
        $progress = ensureUserSessionProgress($pdo, $userId, $sessionId);
        $allQuestions = getSessionQuestions($pdo, $sessionId);
        $questions = array_slice($allQuestions, 0, 5);
        $exactFiveQuestions = count($questions) === 5;

        // اگر کاربر قبلاً در این جلسه قبول شده، فرم آزمون نمایش داده نمی‌شود.
        $passedAttempt = getPassedAttempt($pdo, $userId, $sessionId);
        if ($passedAttempt) {
            header('Location: exam_result.php?session_attempt=' . (int)$passedAttempt['id']);
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_exam'])) {
            if (!verify_csrf($_POST['csrf_token'] ?? null)) {
                $error = 'درخواست نامعتبر است. دوباره تلاش کنید.';
            } elseif (!$exactFiveQuestions) {
                $error = 'خودآزمایی این جلسه باید دقیقاً ۵ سؤال فعال داشته باشد.';
            } else {
                $submitted = $_POST['answers'] ?? [];
                $score = 0;
                $preparedAnswers = [];
                foreach ($questions as $q) {
                    $qid = (int)$q['id'];
                    $selected = isset($submitted[$qid]) ? (int)$submitted[$qid] : 0;
                    if ($selected < 1 || $selected > 4) {
                        $error = 'لطفاً به همه سؤال‌ها پاسخ دهید.';
                        break;
                    }
                    $correct = $selected === (int)$q['correct_answer'];
                    if ($correct) $score++;
                    $preparedAnswers[] = [$q, $selected, $correct];
                }

                if ($error === '') {
                    $passed = $score >= 3 ? 1 : 0;
                    $startedKey = 'session_exam_started_' . $sessionId;
                    $duration = !empty($_SESSION[$startedKey]) ? max(0, time() - (int)$_SESSION[$startedKey]) : 0;
                    unset($_SESSION[$startedKey]);

                    try {
                        $pdo->beginTransaction();
                        $stmt = $pdo->prepare('INSERT INTO session_exam_attempts (user_id, session_id, score, total_questions, passed, duration_seconds, attempted_at, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())');
                        $stmt->execute([$userId, $sessionId, $score, count($questions), $passed, $duration]);
                        $attemptId = (int)$pdo->lastInsertId();

                        $answerStmt = $pdo->prepare('INSERT INTO session_exam_answers (attempt_id, question_id, question_number, question_text, option_1, option_2, option_3, option_4, correct_answer, selected_answer, is_correct, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())');
                        foreach ($preparedAnswers as $idx => [$q, $selected, $correct]) {
                            $answerStmt->execute([
                                $attemptId,
                                (int)$q['id'],
                                $idx + 1,
                                (string)$q['question_text'],
                                (string)$q['option_1'],
                                (string)$q['option_2'],
                                (string)$q['option_3'],
                                (string)$q['option_4'],
                                (int)$q['correct_answer'],
                                $selected,
                                $correct ? 1 : 0,
                            ]);
                        }
                        if ($passed) markSessionCompleted($pdo, $userId, $sessionId);
                        $pdo->commit();
                        header('Location: exam_result.php?session_attempt=' . $attemptId);
                        exit;
                    } catch (Throwable $e) {
                        if ($pdo->inTransaction()) $pdo->rollBack();
                        error_log('Session exam submit failed: ' . $e->getMessage());
                        $error = 'ثبت خودآزمایی انجام نشد. دوباره تلاش کنید.';
                    }
                }
            }
        }

        if (!isset($_SESSION['session_exam_started_' . $sessionId])) {
            $_SESSION['session_exam_started_' . $sessionId] = time();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl" class="exam-document">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>خودآزمایی | پیشروان بصیرت</title>
<link rel="stylesheet" href="assets/css/style.css?v=20260921-session2">
<style>
html.exam-document,body.exam-page{overflow:visible!important;-webkit-tap-highlight-color:transparent!important;tap-highlight-color:transparent!important}
body.exam-page{display:block!important;min-height:100vh!important;margin:0!important;padding:0!important}
body.exam-page .site-shell{display:block!important;width:min(1100px,100%)!important;max-width:1100px!important;margin:0 auto!important;padding:20px!important;position:relative!important;overflow:visible!important;transform:none!important;filter:none!important;contain:none!important}
.exam-main{width:min(820px,100%);margin:0 auto 44px}
.exam-sticky-bar{position:-webkit-sticky!important;position:sticky!important;top:0!important;z-index:10000!important;width:min(820px,100%)!important;margin:0 auto 18px!important;padding:8px 12px!important;border-radius:16px!important;background:rgba(255,255,255,.88)!important;backdrop-filter:blur(18px)!important;-webkit-backdrop-filter:blur(18px)!important;border:1px solid rgba(255,255,255,.72)!important;box-shadow:0 10px 26px -18px rgba(0,0,0,.35)!important;display:flex!important;justify-content:center!important}
.back-link{display:inline-flex;align-items:center;gap:7px;color:#0f8f80;text-decoration:none;font-weight:800;font-size:13px}
.exam-card{background:rgba(255,255,255,.67);backdrop-filter:blur(34px) saturate(110%);-webkit-backdrop-filter:blur(34px) saturate(110%);border:1px solid rgba(255,255,255,.5);border-radius:30px;padding:30px;box-shadow:0 28px 65px -34px rgba(0,0,0,.3),inset 0 1px 0 rgba(255,255,255,.75)}
.exam-head{text-align:center;margin-bottom:24px}.exam-kicker{font-size:13px;font-weight:800;color:#118f80;margin-bottom:6px}.exam-title{font-size:29px;font-weight:850;color:var(--text-primary);margin:0 0 8px}.exam-subtitle{margin:0;color:var(--text-secondary);font-size:14px;line-height:1.9}.exam-subtitle strong{color:#0f8f80}
.question{background:rgba(255,255,255,.7);border:1px solid rgba(0,0,0,.06);border-radius:20px;padding:18px;margin-bottom:14px}.question-title{font-size:16px;font-weight:800;color:var(--text-primary);line-height:1.9;margin-bottom:12px}.question-title span{color:#0f8f80;margin-left:5px}.options{display:grid;grid-template-columns:1fr 1fr;gap:10px}.option{display:flex;align-items:flex-start;gap:9px;padding:12px;border-radius:16px;background:rgba(255,255,255,.8);border:1px solid rgba(15,23,42,.14);cursor:pointer;transition:.15s;-webkit-tap-highlight-color:transparent!important;tap-highlight-color:transparent!important}.option:hover{border-color:rgba(16,173,154,.28);transform:translateY(-1px)}.option input{margin-top:4px;accent-color:#10ad9a;-webkit-tap-highlight-color:transparent}.option-text{font-size:14px;line-height:1.9;color:var(--text-primary);-webkit-tap-highlight-color:transparent}
.submit-exam{width:100%;border:none;border-radius:999px;padding:15px 20px;background:linear-gradient(135deg,#10ad9a,#0d8d7f);color:#fff;font-family:inherit;font-size:17px;font-weight:850;cursor:pointer;box-shadow:0 16px 32px -20px rgba(16,173,154,.8);transition:.18s}.submit-exam:hover{transform:translateY(-2px)}.submit-exam:active{transform:scale(.98)}
.notice{padding:15px 16px;border-radius:16px;text-align:center;font-size:14px;background:rgba(255,149,0,.1);border:1px solid rgba(255,149,0,.15);color:#985f09;margin-bottom:18px}.error{background:rgba(255,59,48,.08);border-color:rgba(255,59,48,.13);color:#b42318}
@media(max-width:700px){body.exam-page .site-shell{padding:10px!important}.exam-card{padding:20px 14px;border-radius:24px}.exam-title{font-size:24px}.options{grid-template-columns:1fr}.question{padding:14px}.option{padding:11px}.exam-sticky-bar{margin-bottom:12px!important;border-radius:14px!important}}
</style>
</head>
<body class="user-page exam-page">
<div class="bg-mesh"><div class="blob blob-1"></div><div class="blob blob-2"></div><div class="blob blob-3"></div></div>
<?php require __DIR__ . '/includes/page_loader.php'; ?>
<div class="site-shell">
<?php require __DIR__ . '/includes/site_header.php'; ?>
<?php if ($session): ?>
<div class="sticky-bar exam-sticky-bar"><a href="study.php?session_id=<?= (int)$session['id'] ?>" class="back-link">📖 بازگشت به متن جلسه</a></div>
<main class="exam-main">
<section class="exam-card">
<header class="exam-head"><div class="exam-kicker"><?= e((string)($session['chapter_title'] ?: 'مسیر مطالعه')) ?> · جلسه <?= e((string)$sessionNumber) ?></div><h1 class="exam-title">📝 خودآزمایی جلسه</h1><p class="exam-subtitle">به ۵ سؤال زیر پاسخ بده. <strong>حدنصاب قبولی: حداقل ۳ پاسخ درست از ۵ سؤال</strong></p></header>
<?php if ($error): ?><div class="notice error"><?= e($error) ?></div><?php endif; ?>
<?php if (count($questions) < 5): ?><div class="notice">هنوز ۵ سؤال کامل برای این جلسه ثبت نشده است. لطفاً از مدیر سایت بخواهید سؤالات جلسه را کامل کند.</div>
<?php else: ?>
<form method="POST" action="exam.php?session_id=<?= (int)$session['id'] ?>" id="examForm">
<input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="session_id" value="<?= (int)$session['id'] ?>">
<?php foreach ($questions as $index=>$q): ?>
<div class="question"><div class="question-title"><span><?= e((string)($index+1)) ?>.</span><?= e((string)$q['question_text']) ?></div>
<div class="options">
<?php foreach ([1=>'option_1',2=>'option_2',3=>'option_3',4=>'option_4'] as $num=>$field): ?><label class="option"><input type="radio" name="answers[<?= (int)$q['id'] ?>]" value="<?= $num ?>" required><span class="option-text"><strong><?= e(optionLabel($num)) ?>)</strong> <?= e((string)$q[$field]) ?></span></label><?php endforeach; ?>
</div></div>
<?php endforeach; ?>
<button type="submit" name="submit_exam" class="submit-exam">ثبت پاسخ‌ها و مشاهده نتیجه</button>
</form>
<?php endif; ?>
</section>
</main>
<?php else: ?>
<main class="exam-main"><section class="exam-card"><div class="notice error"><?= e($error ?: 'جلسه‌ای برای خودآزمایی پیدا نشد.') ?></div><div style="text-align:center"><a class="back-link" href="sessions.php">📚 بازگشت به فهرست جلسات</a></div></section></main>
<?php endif; ?>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
</div>
<script src="assets/js/app.js?v=20260921-session2" defer></script>
</body>
</html>
