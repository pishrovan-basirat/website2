-- V13.1: جایگزینی «فناوری و IT» با «میدانی» بدون تغییر IDهای قبلی
CREATE TABLE IF NOT EXISTS skill_options (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_skill_options_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- اگر در نصب قبلی «میدانی» از قبل وجود داشت، نسخه تازه را حذف می‌کنیم تا
-- همان شناسه گزینه قدیمی حفظ شود و داده‌های کاربران تغییر نکنند.
DELETE s_new
FROM skill_options AS s_new
INNER JOIN skill_options AS s_old
    ON s_old.name = 'فناوری و IT'
   AND s_new.name = 'میدانی'
   AND s_new.id <> s_old.id;

-- جایگزینی گزینه قدیمی در نصب‌های قبلی، با حفظ شناسه آن
UPDATE skill_options
SET name = 'میدانی'
WHERE name = 'فناوری و IT';

INSERT INTO skill_options (name, sort_order) VALUES
('رسانه', 10),
('مالی', 20),
('اجرایی', 30),
('فرهنگی', 40),
('آموزشی', 50),
('میدانی', 60),
('طراحی و گرافیک', 70),
('تولید محتوا', 80),
('روابط عمومی', 90),
('پشتیبانی', 100),
('پژوهش و تحقیق', 110),
('حقوقی', 120),
('منابع انسانی', 130),
('سایر', 999)
ON DUPLICATE KEY UPDATE sort_order = VALUES(sort_order), is_active = 1;

CREATE TABLE IF NOT EXISTS user_skills (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    skill_option_id INT UNSIGNED NOT NULL,
    custom_text VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_user_skill (user_id, skill_option_id),
    KEY idx_user_skills_user (user_id),
    KEY idx_user_skills_skill (skill_option_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
