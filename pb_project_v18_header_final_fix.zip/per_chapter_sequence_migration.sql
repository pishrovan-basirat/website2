-- ============================================================
-- Migration: Per-Chapter Session Numbering
-- شماره جلسه داخل هر فصل مستقل است.
-- این نسخه برای دیتابیس‌های قدیمی نیز قابل اجرای مجدد است.
-- ============================================================

SET @old_idx_exists := (
    SELECT COUNT(*) FROM information_schema.statistics
    WHERE table_schema = DATABASE()
      AND table_name = 'study_sessions'
      AND index_name = 'uq_study_sessions_sequence'
);
SET @sql := IF(@old_idx_exists > 0, 'ALTER TABLE study_sessions DROP INDEX uq_study_sessions_sequence', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- برای جلوگیری از برخورد موقت با UNIQUE، ابتدا شماره‌ها را بالا می‌بریم.
UPDATE study_sessions SET sequence_no = sequence_no + 1000000;

SET @rn = 0;
SET @prev_chapter = NULL;
UPDATE study_sessions s
JOIN (
    SELECT
        id,
        chapter_id,
        @rn := IF(@prev_chapter = chapter_id, @rn + 1, 1) AS new_seq,
        @prev_chapter := chapter_id
    FROM study_sessions
    ORDER BY chapter_id ASC, sequence_no ASC, id ASC
) t ON s.id = t.id
SET s.sequence_no = t.new_seq;

SET @new_idx_exists := (
    SELECT COUNT(*) FROM information_schema.statistics
    WHERE table_schema = DATABASE()
      AND table_name = 'study_sessions'
      AND index_name = 'uq_study_sessions_chapter_sequence'
);
SET @sql := IF(@new_idx_exists = 0, 'ALTER TABLE study_sessions ADD UNIQUE KEY uq_study_sessions_chapter_sequence (chapter_id, sequence_no)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
