-- ================================================================
-- سامانه مسیر مطالعه / جلسات
-- مدل بدون قفل زمانی: هر کاربر از جلسه اول شروع می‌کند و پس از
-- قبولی خودآزمایی هر جلسه، جلسه بعدی برای او باز می‌شود. شماره جلسه داخل هر فصل مستقل است.
-- محتوای هر جلسه واحد و قابل ویرایش است؛ نسخه‌بندی محتوا وجود ندارد.
-- هیچ Foreign Key روی users.* تعریف نشده تا با ساختار فعلی هاست سازگار بماند.
-- ================================================================

CREATE TABLE IF NOT EXISTS study_chapters (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    description VARCHAR(500) NULL,
    sort_order INT UNSIGNED NOT NULL DEFAULT 1,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_study_chapters_order (sort_order, id),
    KEY idx_study_chapters_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS study_sessions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    chapter_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(255) NOT NULL,
    summary VARCHAR(500) NULL,
    footnote TEXT NULL,
    content LONGTEXT NOT NULL,
    audio_path VARCHAR(500) NULL,
    sequence_no INT UNSIGNED NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_study_sessions_chapter_sequence (chapter_id, sequence_no),
    KEY idx_study_sessions_chapter_order (chapter_id, sequence_no, id),
    KEY idx_study_sessions_active (is_active, sequence_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS session_questions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    session_id BIGINT UNSIGNED NOT NULL,
    question_number INT UNSIGNED NOT NULL,
    question_text TEXT NOT NULL,
    option_1 VARCHAR(1000) NOT NULL,
    option_2 VARCHAR(1000) NOT NULL,
    option_3 VARCHAR(1000) NOT NULL,
    option_4 VARCHAR(1000) NOT NULL,
    correct_answer TINYINT UNSIGNED NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_session_question_number (session_id, question_number),
    KEY idx_session_questions_session (session_id, is_active, question_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_session_progress (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    session_id BIGINT UNSIGNED NOT NULL,
    study_seconds INT UNSIGNED NOT NULL DEFAULT 0,
    viewed_at DATETIME NULL,
    completed_at DATETIME NULL,
    is_completed TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_user_session_progress (user_id, session_id),
    KEY idx_user_session_progress_user (user_id, session_id),
    KEY idx_user_session_progress_completed (user_id, is_completed)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS session_exam_attempts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    session_id BIGINT UNSIGNED NOT NULL,
    score INT UNSIGNED NOT NULL DEFAULT 0,
    total_questions INT UNSIGNED NOT NULL DEFAULT 0,
    passed TINYINT(1) NOT NULL DEFAULT 0,
    duration_seconds INT UNSIGNED NOT NULL DEFAULT 0,
    attempted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_session_exam_attempts_user (user_id, session_id, id),
    KEY idx_session_exam_attempts_session (session_id, attempted_at),
    KEY idx_session_exam_attempts_passed (user_id, session_id, passed)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS session_exam_answers (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    attempt_id BIGINT UNSIGNED NOT NULL,
    question_id BIGINT UNSIGNED NULL,
    question_number INT UNSIGNED NOT NULL,
    question_text TEXT NOT NULL,
    option_1 VARCHAR(1000) NOT NULL,
    option_2 VARCHAR(1000) NOT NULL,
    option_3 VARCHAR(1000) NOT NULL,
    option_4 VARCHAR(1000) NOT NULL,
    correct_answer TINYINT UNSIGNED NOT NULL,
    selected_answer TINYINT UNSIGNED NOT NULL,
    is_correct TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_session_exam_answers_attempt (attempt_id, question_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ایجاد فصل اولیه در صورت خالی بودن سامانه.
INSERT INTO study_chapters (title, description, sort_order, is_active)
SELECT 'مسیر اصلی', 'فصل نخست مسیر مطالعه پیشروان بصیرت', 1, 1
WHERE NOT EXISTS (SELECT 1 FROM study_chapters LIMIT 1);

-- مهاجرت محتوای فعلی به عنوان جلسه ۱، فقط در صورتی که هنوز هیچ جلسه‌ای وجود ندارد.
SELECT id INTO @first_chapter_id FROM study_chapters ORDER BY sort_order, id LIMIT 1;
INSERT INTO study_sessions (chapter_id, title, summary, footnote, content, audio_path, sequence_no, is_active)
SELECT
    @first_chapter_id,
    'جلسه ۱',
    'اولین جلسه مسیر مطالعه',
    NULL,
    sc.content,
    NULL,
    1,
    1
FROM study_content sc
WHERE NOT EXISTS (SELECT 1 FROM study_sessions LIMIT 1)
ORDER BY sc.id DESC
LIMIT 1;

-- مهاجرت ۵ سؤال فعلی به جلسه ۱ (در صورت وجود حداقل ۵ سؤال).
SELECT id INTO @first_session_id FROM study_sessions ORDER BY sequence_no, id LIMIT 1;
INSERT INTO session_questions (session_id, question_number, question_text, option_1, option_2, option_3, option_4, correct_answer, is_active)
SELECT @first_session_id, 1, q.question_text, q.option_1, q.option_2, q.option_3, q.option_4, q.correct_answer, 1
FROM exam_questions q
WHERE @first_session_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM session_questions sq WHERE sq.session_id = @first_session_id AND sq.question_number = 1)
ORDER BY q.created_at DESC, q.id DESC
LIMIT 1 OFFSET 4;

INSERT INTO session_questions (session_id, question_number, question_text, option_1, option_2, option_3, option_4, correct_answer, is_active)
SELECT @first_session_id, 2, q.question_text, q.option_1, q.option_2, q.option_3, q.option_4, q.correct_answer, 1
FROM exam_questions q
WHERE @first_session_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM session_questions sq WHERE sq.session_id = @first_session_id AND sq.question_number = 2)
ORDER BY q.created_at DESC, q.id DESC
LIMIT 1 OFFSET 3;

INSERT INTO session_questions (session_id, question_number, question_text, option_1, option_2, option_3, option_4, correct_answer, is_active)
SELECT @first_session_id, 3, q.question_text, q.option_1, q.option_2, q.option_3, q.option_4, q.correct_answer, 1
FROM exam_questions q
WHERE @first_session_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM session_questions sq WHERE sq.session_id = @first_session_id AND sq.question_number = 3)
ORDER BY q.created_at DESC, q.id DESC
LIMIT 1 OFFSET 2;

INSERT INTO session_questions (session_id, question_number, question_text, option_1, option_2, option_3, option_4, correct_answer, is_active)
SELECT @first_session_id, 4, q.question_text, q.option_1, q.option_2, q.option_3, q.option_4, q.correct_answer, 1
FROM exam_questions q
WHERE @first_session_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM session_questions sq WHERE sq.session_id = @first_session_id AND sq.question_number = 4)
ORDER BY q.created_at DESC, q.id DESC
LIMIT 1 OFFSET 1;

INSERT INTO session_questions (session_id, question_number, question_text, option_1, option_2, option_3, option_4, correct_answer, is_active)
SELECT @first_session_id, 5, q.question_text, q.option_1, q.option_2, q.option_3, q.option_4, q.correct_answer, 1
FROM exam_questions q
WHERE @first_session_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM session_questions sq WHERE sq.session_id = @first_session_id AND sq.question_number = 5)
ORDER BY q.created_at DESC, q.id DESC
LIMIT 1 OFFSET 0;
