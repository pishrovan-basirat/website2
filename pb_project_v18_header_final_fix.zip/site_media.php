<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

$key = trim((string)($_GET['key'] ?? ''));
$allowed = ['invite_qr'];
if (!in_array($key, $allowed, true)) {
    http_response_code(404);
    exit;
}

$media = getSiteMedia($pdo, $key);
if (!$media) {
    http_response_code(404);
    exit;
}

$mime = trim((string)($media['mime_type'] ?? 'application/octet-stream'));
$data = $media['media_data'] ?? null;
if (!is_string($data) || $data === '') {
    http_response_code(404);
    exit;
}

header('Content-Type: ' . $mime);
header('Content-Length: ' . strlen($data));
header('Cache-Control: private, max-age=300');
header('X-Content-Type-Options: nosniff');
echo $data;
