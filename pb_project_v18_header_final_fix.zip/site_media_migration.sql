-- ذخیره تصاویر قابل مدیریت سایت، مانند QR دعوت از دوستان، مستقیماً در پایگاه داده
CREATE TABLE IF NOT EXISTS site_media (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    media_key VARCHAR(120) NOT NULL,
    mime_type VARCHAR(80) NOT NULL,
    original_name VARCHAR(255) NULL,
    media_data MEDIUMBLOB NOT NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_site_media_key (media_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
