<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

require_login('login.php');
$user = getUser($pdo);
$userId = (int)$_SESSION['user_id'];

if (!studySessionTablesAvailable($pdo)) {
    http_response_code(503);
    $setupNeeded = true;
    $session = null;
    $progress = null;
    $nextSession = null;
} else {
    $setupNeeded = false;
    $requestedSessionId = (int)($_GET['session_id'] ?? 0);
    $nextSession = getNextStudySessionForUser($pdo, $userId);
    $session = $requestedSessionId > 0 ? getStudySession($pdo, $requestedSessionId) : $nextSession;

    if (!$session) {
        $setupNeeded = false;
        $progress = null;
    } elseif (!canAccessStudySession($pdo, $userId, (int)$session['id'])) {
        header('Location: sessions.php?locked=1');
        exit;
    } else {
        markSessionViewed($pdo, $userId, (int)$session['id']);
        $progress = ensureUserSessionProgress($pdo, $userId, (int)$session['id']);
    }
}

$activeSessions = $setupNeeded ? [] : getActiveStudySessions($pdo);
$positionMap = [];
foreach ($activeSessions as $index => $item) $positionMap[(int)$item['id']] = $index + 1;
$sessionNumber = $session ? ($positionMap[(int)$session['id']] ?? 1) : 0;
$previousSession = $session ? getPreviousStudySession($pdo, (int)$session['id']) : null;
$nextCandidate = $session ? getNextStudySession($pdo, (int)$session['id']) : null;
$studyText = $session['content'] ?? '';
$passedAttempt = $session ? getPassedAttempt($pdo, $userId, (int)$session['id']) : null;
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl" class="study-document">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $session ? 'جلسه ' . e((string)$sessionNumber) . ' | پیشروان بصیرت' : 'مطالعه | پیشروان بصیرت' ?></title>
<link rel="stylesheet" href="assets/css/style.css?v=20260928-session3">
<style>
html.study-document{overflow:visible!important}
body.study-page{display:block!important;min-height:100vh!important;margin:0!important;padding:0!important;overflow:visible!important}
body.study-page .site-shell{display:block!important;width:min(1100px,100%)!important;max-width:1100px!important;margin:0 auto!important;padding:20px!important;position:relative!important;overflow:visible!important;transform:none!important;filter:none!important;contain:none!important}
.study-main{width:min(820px,100%);margin:0 auto 44px}
.study-card{background:rgba(255,255,255,.66);backdrop-filter:blur(34px) saturate(110%);-webkit-backdrop-filter:blur(34px) saturate(110%);border:1px solid rgba(255,255,255,.5);border-radius:30px;padding:32px;box-shadow:0 28px 65px -34px rgba(0,0,0,.3),inset 0 1px 0 rgba(255,255,255,.75)}
.study-card-head{text-align:center;padding-top:2px;padding-bottom:20px;margin-bottom:22px;border-bottom:1px solid rgba(0,0,0,.09)}
.bismillah{font-size:10px;color:#9aa3ad;font-weight:600;margin:0 0 8px;text-align:center;line-height:1.4}
.study-meta{display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:8px;margin-bottom:12px}
.study-meta-badge{display:inline-flex;align-items:center;gap:5px;padding:7px 11px;border-radius:999px;font-size:11px;line-height:1.2;font-weight:850;white-space:nowrap;border:1px solid transparent}
.study-meta-badge.chapter{background:rgba(16,173,154,.09);color:#0d8577;border-color:rgba(16,173,154,.14)}
.study-meta-badge.session{background:rgba(245,158,11,.10);color:#a76600;border-color:rgba(245,158,11,.16)}
.study-kicker{display:none}
.study-title{margin:0;font-size:30px;line-height:1.5;color:var(--text-primary);font-weight:850}
.study-summary{margin:10px 0 0;color:var(--text-secondary);font-size:14px;line-height:1.9}
.study-text{color:var(--text-primary);font-size:17px;line-height:2.25;text-align:justify;overflow-wrap:anywhere}
.study-text h2,.study-text h3,.study-text h4{margin:1.25em 0 .6em;line-height:1.6}
.study-text p{margin:0 !important}
.study-footnote{margin-top:28px;padding-top:12px;border-top:1px solid rgba(0,0,0,.12);color:#8a929a;font-size:11px;line-height:1;white-space:pre-line;text-align:justify}
.study-text img{max-width:100%;height:auto;border-radius:16px}
.study-text sup,.study-text sub{font-size:.72em;line-height:0;position:relative;vertical-align:baseline}.study-text sup{top:-.45em}.study-text sub{bottom:-.2em}

.study-meta-row{display:flex;align-items:center;gap:10px;direction:rtl;margin-bottom:12px}
.study-meta-row .study-meta{flex:1;min-width:0;margin-bottom:0;direction:rtl}
.readability-wrap{position:relative;flex:0 0 auto}
.readability-btn{min-height:34px;padding:7px 11px;border:1px solid rgba(13,90,61,.14);border-radius:999px;background:rgba(255,255,255,.62);color:#2b5d4a;font-family:inherit;font-size:10px;font-weight:850;cursor:pointer;box-shadow:0 6px 18px -12px rgba(0,0,0,.22);transition:transform .18s ease,background .18s ease,border-color .18s ease}
.readability-btn:hover{transform:translateY(-1px);background:rgba(255,255,255,.82);border-color:rgba(13,90,61,.24)}
.readability-btn:active{transform:scale(.98)}
.readability-panel[hidden]{display:none!important}
.readability-panel{position:absolute;left:0;top:calc(100% + 7px);display:flex;align-items:center;gap:6px;min-width:220px;padding:8px;border-radius:16px;background:rgba(255,255,255,.94);border:1px solid rgba(0,0,0,.07);box-shadow:0 16px 35px -18px rgba(0,0,0,.25);z-index:30}
.readability-step,.readability-reset{border:0;font-family:inherit;cursor:pointer;border-radius:11px;font-weight:900}
.readability-step{width:36px;height:36px;background:rgba(16,173,154,.09);color:#0d8577;font-size:20px;line-height:1}
.readability-reset{min-height:36px;padding:0 9px;background:rgba(0,0,0,.045);color:#66707a;font-size:10px}
.readability-value{flex:1;text-align:center;font-size:10px;font-weight:800;color:#59636d;white-space:nowrap}
.audio-box{margin-top:24px;padding:16px;border-radius:20px;background:rgba(16,173,154,.06);border:1px solid rgba(16,173,154,.12)}
.audio-title{font-size:14px;font-weight:800;color:var(--text-primary);margin-bottom:10px}
.audio-box audio{width:100%}
.study-actions{display:flex;flex-wrap:wrap;gap:12px;justify-content:center;margin-top:28px}
.exam-btn,.prev-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:none;text-decoration:none;cursor:pointer;font-family:inherit;font-weight:800;border-radius:999px;padding:14px 24px;transition:transform .18s ease,box-shadow .18s ease,background .18s ease}
.exam-btn{background:linear-gradient(135deg,#10ad9a,#0d8d7f);color:#fff;box-shadow:0 16px 30px -17px rgba(16,173,154,.7);min-width:230px}
.exam-btn:hover{transform:translateY(-2px);box-shadow:0 20px 36px -17px rgba(16,173,154,.78)}
.prev-btn{background:rgba(255,255,255,.68);color:var(--text-primary);border:1px solid rgba(0,0,0,.06)}
.prev-btn:hover{transform:translateY(-2px)}
.completed-note{margin-top:18px;text-align:center;font-size:13px;color:#198c41;font-weight:700}
.lock-message{text-align:center;padding:24px;color:#777}
@media(max-width:700px){body.study-page .site-shell{padding:0 10px 10px!important}.study-card{padding:18px 14px 22px;border-radius:24px}.study-title{font-size:24px}.study-text{font-size:15px;line-height:2.15}.study-meta{justify-content:flex-start}.study-meta-badge{font-size:10px;padding:6px 9px}.study-actions{flex-direction:column}.exam-btn,.prev-btn{width:100%}}
</style>
</head>
<body class="user-page study-page">
<div class="bg-mesh"><div class="blob blob-1"></div><div class="blob blob-2"></div><div class="blob blob-3"></div></div>
<?php require __DIR__ . '/includes/page_loader.php'; ?>
<div class="site-shell">
<?php require __DIR__ . '/includes/site_header.php'; ?>
<?php if ($setupNeeded): ?>
<main class="study-main"><section class="study-card"><div class="lock-message"><h1 style="font-size:22px;color:var(--text-primary);margin:0 0 8px;">مسیر جلسات هنوز راه‌اندازی نشده است.</h1><p style="margin:0;">ابتدا <strong>sessions_migration.sql</strong> را در دیتابیس اجرا کنید.</p></div></section></main>
<?php elseif (!$session): ?>
<main class="study-main"><section class="study-card"><div class="lock-message"><h1 style="font-size:22px;color:var(--text-primary);margin:0 0 8px;">هنوز جلسه‌ای برای مطالعه وجود ندارد.</h1><p style="margin:0;">مدیر می‌تواند از پنل مدیریت، اولین جلسه را ایجاد و منتشر کند.</p></div></section></main>
<?php else: ?>
<main class="study-main">
<section class="study-card">
    <header class="study-card-head">
        <div class="bismillah">بسم الله الرحمن الرحیم</div>
        <div class="study-meta-row">
            <div class="study-meta" aria-label="اطلاعات جلسه">
                <span class="study-meta-badge chapter">فصل <?= e((string)($session['chapter_sort_order'] ?? 1)) ?>: <?= e((string)($session['chapter_title'] ?: 'مسیر مطالعه')) ?></span>
                <span class="study-meta-badge session">جلسه <?= e((string)$session['sequence_no']) ?></span>
            </div>
            <div class="readability-wrap">
                <button type="button" class="readability-btn" id="readabilityBtn" aria-expanded="false" aria-controls="readabilityPanel">⚙ تنظیم خوانایی</button>
                <div class="readability-panel" id="readabilityPanel" hidden>
                    <button type="button" class="readability-step" id="readabilityMinus" aria-label="کوچک‌تر کردن متن">−</button>
                    <div class="readability-value" id="readabilityValue">اندازه متن</div>
                    <button type="button" class="readability-step" id="readabilityPlus" aria-label="بزرگ‌تر کردن متن">+</button>
                    <button type="button" class="readability-reset" id="readabilityReset">بازنشانی</button>
                </div>
            </div>
        </div>
        <h1 class="study-title">📖 <?= e((string)$session['title']) ?></h1>
        <?php if (!empty($session['summary'])): ?><p class="study-summary"><?= e((string)$session['summary']) ?></p><?php endif; ?>
    </header>

    <article class="study-text"><?= $studyText ?></article>

    <?php if (!empty($session['footnote'])): ?>
    <div class="study-footnote"><?= nl2br(e((string)$session['footnote'])) ?></div>
    <?php endif; ?>

    <?php if (!empty($session['audio_path'])): ?>
    <div class="audio-box">
        <div class="audio-title">🎧 گوش دادن به صوت این جلسه</div>
        <audio controls preload="none" src="<?= e((string)$session['audio_path']) ?>"></audio>
    </div>
    <?php endif; ?>

    <div class="study-actions">
        <?php if ($passedAttempt): ?>
            <a class="exam-btn" href="exam_result.php?session_attempt=<?= (int)$passedAttempt['id'] ?>">✓ مشاهده نتیجه خودآزمایی</a>
        <?php else: ?>
            <a class="exam-btn" href="exam.php?session_id=<?= (int)$session['id'] ?>">✎ شروع خودآزمایی این جلسه</a>
        <?php endif; ?>
    </div>
    <?php if ($progress && (int)$progress['is_completed'] === 1): ?><div class="completed-note">✅ این جلسه قبلاً با موفقیت تکمیل شده و برای مرور همچنان در دسترس است.</div><?php endif; ?>
</section>
</main>
<?php endif; ?>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
</div>
<script>
(function(){
  const article=document.querySelector('.study-text');
  const btn=document.getElementById('readabilityBtn');
  const panel=document.getElementById('readabilityPanel');
  const minus=document.getElementById('readabilityMinus');
  const plus=document.getElementById('readabilityPlus');
  const reset=document.getElementById('readabilityReset');
  const value=document.getElementById('readabilityValue');
  if(!article||!btn||!panel||!minus||!plus||!reset||!value) return;

  const baseSize=parseFloat(getComputedStyle(article).fontSize) || 17;
  const baseLine=parseFloat(getComputedStyle(article).lineHeight) || (baseSize * 2.15);
  const key='pbasirat_readability_v2';
  const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
  let step=0;
  try { step=clamp(parseInt(localStorage.getItem(key)||'0',10)||0,-10,10); } catch(_) {}

  function apply(){
    const size=clamp(baseSize+step,baseSize-10,baseSize+10);
    article.style.fontSize=size+'px';
    const ratio=baseSize>0 ? baseLine/baseSize : 2.15;
    article.style.lineHeight=(size*ratio)+'px';
    value.textContent=step===0?'اندازه پایه':(step>0?'بزرگ‌تر +'+step:'کوچک‌تر '+Math.abs(step));
    try { localStorage.setItem(key,String(step)); } catch(_) {}
  }
  function setOpen(open){panel.hidden=!open;btn.setAttribute('aria-expanded',open?'true':'false');}
  btn.addEventListener('click',function(e){e.stopPropagation();setOpen(panel.hidden);});
  panel.addEventListener('click',e=>e.stopPropagation());
  document.addEventListener('click',()=>setOpen(false));
  minus.addEventListener('click',()=>{step=clamp(step-1,-10,10);apply();});
  plus.addEventListener('click',()=>{step=clamp(step+1,-10,10);apply();});
  reset.addEventListener('click',()=>{step=0;apply();});
  apply();
})();
</script>
<script src="assets/js/app.js?v=20261001-v15" defer></script>
</body>
</html>
