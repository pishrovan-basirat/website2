<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

require_login('login.php');
$user = getUser($pdo);
$userId = (int)$_SESSION['user_id'];

// نتیجه خودآزمایی سیستم جدید جلسات.
$sessionAttemptId = (int)($_GET['session_attempt'] ?? 0);
if ($sessionAttemptId > 0) {
    if (!studySessionTablesAvailable($pdo)) {
        http_response_code(503);
        exit('سامانه جلسات هنوز در دیتابیس راه‌اندازی نشده است.');
    }
    $stmt = $pdo->prepare('SELECT a.*, s.title AS session_title, c.title AS chapter_title FROM session_exam_attempts a LEFT JOIN study_sessions s ON s.id = a.session_id LEFT JOIN study_chapters c ON c.id = s.chapter_id WHERE a.id = ? AND a.user_id = ? LIMIT 1');
    $stmt->execute([$sessionAttemptId, $userId]);
    $sessionAttempt = $stmt->fetch();
    if (!$sessionAttempt) {
        http_response_code(404);
        exit('نتیجه موردنظر پیدا نشد.');
    }
    $answerStmt = $pdo->prepare('SELECT * FROM session_exam_answers WHERE attempt_id = ? ORDER BY question_number ASC, id ASC');
    $answerStmt->execute([$sessionAttemptId]);
    $sessionAnswers = $answerStmt->fetchAll();
    $passed = (int)$sessionAttempt['passed'];
    $score = (int)$sessionAttempt['score'];
    $total = (int)$sessionAttempt['total_questions'];
    $previousSession = getPreviousStudySession($pdo, (int)$sessionAttempt['session_id']);
    $nextSession = $passed ? getNextStudySession($pdo, (int)$sessionAttempt['session_id']) : null;
    $isLastSession = $passed && !$nextSession;
    $isFirstSuccessfulSessionToday = false;
    if ($passed) {
        $dailyStmt = $pdo->prepare('SELECT COUNT(*) FROM session_exam_attempts WHERE user_id = ? AND passed = 1 AND DATE(attempted_at) = DATE(?) AND (attempted_at < ? OR (attempted_at = ? AND id < ?))');
        $dailyStmt->execute([$userId, $sessionAttempt['attempted_at'], $sessionAttempt['attempted_at'], $sessionAttempt['attempted_at'], $sessionAttemptId]);
        $isFirstSuccessfulSessionToday = ((int)$dailyStmt->fetchColumn() === 0);
    }
    $successCopy = $isLastSession
        ? '✅ شما با موفقیت آخرین جلسه را گذراندید'
        : ($isFirstSuccessfulSessionToday
            ? 'خودسازی امروز برای سربازی امام زمان(عج) با موفقیت انجام شد ✅'
            : '✅ شما با موفقیت این جلسه را گذراندید');
    ?>
    <!DOCTYPE html>
    <html lang="fa" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>نتیجه خودآزمایی | پیشروان بصیرت</title>
        <link rel="stylesheet" href="assets/css/style.css?v=20260921-session2">
        <style>
        body.session-result-page{display:block!important;min-height:100vh!important;margin:0!important;padding:0!important;overflow-x:hidden}.session-result-page .site-shell{width:min(1100px,100%);margin:0 auto;padding:20px}.session-result-main{width:min(820px,100%);margin:20px auto 44px}.result-card{background:rgba(255,255,255,.67);backdrop-filter:blur(34px);-webkit-backdrop-filter:blur(34px);border:1px solid rgba(255,255,255,.5);border-radius:30px;padding:30px;box-shadow:0 28px 65px -34px rgba(0,0,0,.3),inset 0 1px 0 rgba(255,255,255,.75)}.result-center{text-align:center}.result-icon{width:96px;height:96px;margin:0 auto 16px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:42px;background:#22bc52;border:1px solid rgba(34,188,82,.20);color:#fff;box-shadow:0 16px 34px -19px rgba(34,188,82,.60);animation:resultIconIn .52s cubic-bezier(.2,.9,.25,1) both}.result-icon.fail{background:rgba(255,59,48,.08);border-color:rgba(255,59,48,.14);color:#b42318;box-shadow:none;animation:none}.result-icon svg{color:#fff}.result-title{margin:0 0 8px;font-size:30px;font-weight:900;color:<?= $passed ? '#198c41' : '#b42318' ?>}.result-subtitle{margin:0;color:var(--text-secondary);font-size:15px;line-height:2}.success-heading{margin:0 0 10px;font-size:40px;font-weight:950;line-height:1.35;color:#22bc52;letter-spacing:-.02em;opacity:0;animation:resultTitleIn .52s .16s cubic-bezier(.2,.9,.25,1) forwards}.success-copy{margin:0 auto;color:#111827;font-size:21px;font-weight:800;line-height:1.9;max-width:650px;opacity:0;animation:resultCopyIn .48s .34s ease-out forwards}.success-copy .success-check{display:inline-block;margin-right:4px}.success-celebration{display:inline-block;margin:0 0 0 8px;font-size:34px;line-height:1;vertical-align:-4px}.score-row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin:22px 0}.score-pill{padding:10px 16px;border-radius:16px;background:rgba(255,255,255,.7);border:1px solid rgba(0,0,0,.06);font-weight:800}.result-actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:26px}.result-action{display:inline-flex;align-items:center;justify-content:center;gap:9px;min-height:54px;text-decoration:none;padding:12px 18px;border-radius:999px;font-family:inherit;font-weight:850;background:rgba(255,255,255,.78);color:var(--text-primary);border:1px solid rgba(0,0,0,.06);transition:transform .18s ease,box-shadow .18s ease,background .18s ease}.result-action:hover{transform:translateY(-2px);box-shadow:0 12px 24px -18px rgba(0,0,0,.35)}.result-action.primary{background:linear-gradient(135deg,#10ad9a,#0d8d7f);color:#fff;border-color:transparent;box-shadow:0 14px 28px -18px rgba(16,173,154,.8)}.result-action-icon{width:22px;height:22px;flex:0 0 22px;display:block}.answer-list{margin-top:28px}.answer-list h2{font-size:18px;margin:0 0 14px;color:var(--text-primary)}.answer-card{padding:15px;border:1px solid rgba(0,0,0,.06);border-radius:18px;background:rgba(255,255,255,.72);margin-bottom:10px}.answer-q{font-size:14px;font-weight:800;color:var(--text-primary);line-height:1.9}.answer-meta{display:flex;flex-wrap:wrap;gap:8px;margin-top:9px;font-size:12px}.badge{padding:5px 9px;border-radius:999px;font-weight:800}.badge.ok{background:rgba(52,199,89,.12);color:#198c41}.badge.bad{background:rgba(255,59,48,.1);color:#b42318}.badge.neutral{background:rgba(0,122,255,.08);color:#007aff}@keyframes resultIconIn{0%{opacity:0;transform:scale(.72) rotate(-7deg)}60%{opacity:1;transform:scale(1.04) rotate(1deg)}100%{opacity:1;transform:scale(1) rotate(0)}}@keyframes resultTitleIn{0%{opacity:0;transform:translateY(12px)}100%{opacity:1;transform:translateY(0)}}@keyframes resultCopyIn{0%{opacity:0;transform:translateY(10px)}100%{opacity:1;transform:translateY(0)}}@media (prefers-reduced-motion:reduce){.result-icon,.success-heading,.success-copy{animation:none;opacity:1}}
        @media(max-width:700px){.session-result-page .site-shell{padding:10px}.result-card{padding:24px 14px;border-radius:24px}.result-title{font-size:24px}.success-heading{font-size:32px}.success-copy{font-size:17px}.result-actions{grid-template-columns:1fr}.result-action{width:100%}}
        </style>
    </head>
    <body class="user-page session-result-page">
    <div class="bg-mesh"><div class="blob blob-1"></div><div class="blob blob-2"></div><div class="blob blob-3"></div></div>
    <?php require __DIR__ . '/includes/page_loader.php'; ?>
    <div class="site-shell">
    <?php require __DIR__ . '/includes/site_header.php'; ?>
    <main class="session-result-main">
    <section class="result-card">
        <div class="result-center">
            <div class="result-icon <?= $passed ? '' : 'fail' ?>">
                <?php if ($passed): ?>
                    <svg viewBox="0 0 48 48" width="54" height="54" aria-hidden="true"><path d="M13 25.5 21 33l15-18" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                <?php else: ?>!<?php endif; ?>
            </div>
            <?php if ($passed): ?>
                <h1 class="success-heading"><span class="success-celebration" aria-hidden="true">🎉</span>خداقوت!</h1>
                <p class="success-copy"><?= e($successCopy) ?></p>
            <?php else: ?>
                <h1 class="result-title">نیاز به یک مرور دوباره داری</h1>
                <p class="result-subtitle"><?= e((string)($sessionAttempt['chapter_title'] ?: 'مسیر مطالعه')) ?> · <?= e((string)($sessionAttempt['session_title'] ?: 'جلسه')) ?><br>نتیجه خودآزمایی: <?= e((string)$score) ?> از <?= e((string)$total) ?></p>
            <?php endif; ?>
            <?php if (!$passed): ?><div class="score-row"><div class="score-pill">درست: <?= e((string)$score) ?></div><div class="score-pill">غلط: <?= e((string)max(0,$total-$score)) ?></div></div><?php endif; ?>
        </div>
        <div class="result-actions">
            <?php if ($passed && $nextSession): ?>
            <a class="result-action primary" href="study.php?session_id=<?= (int)$nextSession['id'] ?>">
                <svg class="result-action-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h12M13 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                <span>جلسه بعدی</span>
            </a>
            <a class="result-action" href="study.php?session_id=<?= (int)$sessionAttempt['session_id'] ?>">
                <svg class="result-action-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 4h9a3 3 0 0 1 3 3v13H9a3 3 0 0 0-3 3V4Z" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 20h12" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>
                <span>مرور جلسه</span>
            </a>
            <?php elseif ($passed): ?>
            <a class="result-action primary" href="study.php?session_id=<?= (int)$sessionAttempt['session_id'] ?>">
                <svg class="result-action-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 4h9a3 3 0 0 1 3 3v13H9a3 3 0 0 0-3 3V4Z" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 20h12" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>
                <span>مرور جلسه</span>
            </a>
            <?php else: ?>
            <a class="result-action primary" href="exam.php?session_id=<?= (int)$sessionAttempt['session_id'] ?>">
                <svg class="result-action-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12a8 8 0 1 0 2.3-5.65" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M4 5v6h6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                <span>تلاش دوباره</span>
            </a>
            <?php endif; ?>
            <?php if ($previousSession): ?>
            <a class="result-action" href="study.php?session_id=<?= (int)$previousSession['id'] ?>">
                <svg class="result-action-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M19 12H7M11 6l-6 6 6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                <span>جلسه قبلی</span>
            </a>
            <?php endif; ?>
            <a class="result-action" href="home.php">
                <svg class="result-action-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 11.5 12 5l8 6.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.5 10.5V19h11v-8.5M10 19v-5h4v5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                <span>خانه</span>
            </a>
        </div>
        <div class="answer-list"><h2>📋 پاسخ‌های شما</h2>
        <?php foreach ($sessionAnswers as $ans): $opts=[1=>$ans['option_1'],2=>$ans['option_2'],3=>$ans['option_3'],4=>$ans['option_4']]; $selected=(int)$ans['selected_answer']; $correct=(int)$ans['correct_answer']; ?>
            <div class="answer-card"><div class="answer-q"><?= e((string)$ans['question_number']) ?>. <?= e((string)$ans['question_text']) ?></div><div class="answer-meta"><span class="badge <?= (int)$ans['is_correct']===1?'ok':'bad' ?>"><?= (int)$ans['is_correct']===1 ? '✅ درست' : '❌ غلط' ?></span><span class="badge neutral">پاسخ شما: <?= e(optionLabel($selected)) ?>) <?= e((string)($opts[$selected] ?? 'بدون پاسخ')) ?></span><?php if ((int)$ans['is_correct']!==1): ?><span class="badge neutral">پاسخ صحیح: <?= e(optionLabel($correct)) ?>) <?= e((string)($opts[$correct] ?? '')) ?></span><?php endif; ?></div></div>
        <?php endforeach; ?>
        </div>
    </section>
    </main>
    <?php require __DIR__ . '/includes/site_footer.php'; ?>
    </div>
    <script src="assets/js/app.js?v=20260921-session2" defer></script>
    </body></html>
    <?php
    exit;
}

// سیستم قدیمی آزمون حذف شده است. فقط نتیجه جلسه جدید پشتیبانی می‌شود.
$sessionAttemptId = (int)($_GET['session_attempt'] ?? 0);
if ($sessionAttemptId <= 0) {
    header('Location: sessions.php');
    exit;
}

// اگر session_attempt معتبر است ولی به سیستم قدیمی نتیجه ارجاع شده باشد،
// به فهرست جلسات هدایت می‌شود.
header('Location: sessions.php');
exit;