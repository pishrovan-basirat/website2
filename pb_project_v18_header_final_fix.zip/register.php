<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

if (isLoggedIn()) {
    redirect('home.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $selectedSkills = isset($_POST['skills']) && is_array($_POST['skills']) ? array_values(array_unique(array_map('intval', $_POST['skills']))) : [];
    $otherSkillText = trim($_POST['other_skill'] ?? '');
    $location = trim($_POST['location'] ?? '');

    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        $error = '❌ درخواست نامعتبر است. صفحه را تازه کنید و دوباره تلاش کنید.';
    } elseif ($full_name === '' || $phone === '') {
        $error = '❌ لطفاً نام و شماره همراه را وارد کنید.';
    } elseif (!preg_match('/^09[0-9]{9}$/', $phone)) {
        $error = '❌ شماره همراه معتبر نیست. (مثال: 09123456789)';
    } elseif (!$selectedSkills) {
        $error = '❌ لطفاً حداقل یک توانمندی را انتخاب کنید.';
    } elseif ($location === '') {
        $error = '❌ لطفاً محدوده محل سکونت را وارد کنید.';
    } else {
        try {
            $stmt = $pdo->prepare('SELECT id FROM users WHERE phone = ? LIMIT 1');
            $stmt->execute([$phone]);
            if ($stmt->fetch()) {
                $error = '❌ این شماره همراه قبلاً ثبت شده است.';
            } else {
                $placeholders = implode(',', array_fill(0, count($selectedSkills), '?'));
                $skillStmt = $pdo->prepare("SELECT id, name FROM skill_options WHERE id IN ($placeholders) AND is_active = 1 ORDER BY sort_order, id");
                $skillStmt->execute($selectedSkills);
                $skillRows = $skillStmt->fetchAll();
                if (count($skillRows) !== count($selectedSkills)) {
                    throw new RuntimeException('Invalid skill selection.');
                }
                $skillNames = array_map(static fn($row) => $row['name'], $skillRows);
                $hasOther = in_array('سایر', $skillNames, true);
                $skillLabel = implode('، ', $skillNames);
                if ($hasOther && $otherSkillText !== '') {
                    $skillLabel .= ' — ' . $otherSkillText;
                }

                $stmt = $pdo->prepare('INSERT INTO users (full_name, phone, password_hash, skill, location, created_at) VALUES (?, ?, NULL, ?, ?, ?)');
                $stmt->execute([$full_name, $phone, $skillLabel, $location, now()]);
                $newUserId = (int)$pdo->lastInsertId();

                $linkStmt = $pdo->prepare('INSERT INTO user_skills (user_id, skill_option_id, custom_text) VALUES (?, ?, ?)');
                foreach ($skillRows as $row) {
                    $customText = ((string)$row['name'] === 'سایر' && $otherSkillText !== '') ? $otherSkillText : null;
                    $linkStmt->execute([$newUserId, (int)$row['id'], $customText]);
                }

                session_regenerate_id(true);
                $_SESSION['user_id'] = $newUserId;
                $_SESSION['full_name'] = $full_name;
                $_SESSION['role'] = 'user';
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                issueRememberToken($pdo, $newUserId);
                redirect('home.php');
            }
        } catch (PDOException $e) {
            error_log('Registration failed: ' . $e->getMessage());
            $error = '❌ ثبت‌نام انجام نشد. لطفاً دوباره تلاش کنید.';
        }
    }
}
?>


<!DOCTYPE html>
<html lang="fa" data-theme="light" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ثبت‌نام</title>
    <link rel="stylesheet" href="assets/css/style.css?v=20261001-auth13">
    <style>
        :root {
            --bg-color: #e5e5ea;
            --blob-1: #ff2a5f;
            --blob-2: #007aff;
            --blob-3: #ff9500;
            --blob-opacity: 0.7;
            --glass-bg: rgba(255, 255, 255, 0.63);
            --glass-border: rgba(255, 255, 255, 0.4);
            --glass-shadow: rgba(0, 0, 0, 0.1);
            --glass-highlight: rgba(255, 255, 255, 0.8);
            --glass-caustic: rgba(255, 255, 255, 0.4);
            --reflection-start: rgba(255, 255, 255, 0.6);
            --reflection-end: rgba(255, 255, 255, 0.0);
            --glare-color: rgba(255, 255, 255, 0.5);
            --pill-bg: rgba(255, 255, 255, 0.7);
            --pill-shadow: 0 4px 12px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.05), inset 0 1px 1px rgba(255,255,255,0.8);
            --icon-color: rgba(0, 0, 0, 0.5);
            --icon-active: rgba(0, 0, 0, 0.95);
            --card-bg: rgba(255, 255, 255, 0.2);
            --text-primary: #1c1c1e;
            --text-secondary: #3a3a3c;
        }

        [data-theme="dark"] {
            --bg-color: #000000;
            --blob-1: #bf5af2;
            --blob-2: #0a84ff;
            --blob-3: #ff375f;
            --blob-opacity: 0.5;
            --glass-bg: rgba(30, 30, 35, 0.45);
            --glass-border: rgba(255, 255, 255, 0.15);
            --glass-shadow: rgba(0, 0, 0, 0.8);
            --glass-highlight: rgba(255, 255, 255, 0.25);
            --glass-caustic: rgba(255, 255, 255, 0.05);
            --reflection-start: rgba(255, 255, 255, 0.15);
            --reflection-end: rgba(255, 255, 255, 0.0);
            --glare-color: rgba(255, 255, 255, 0.15);
            --pill-bg: rgba(60, 60, 65, 0.8);
            --pill-shadow: 0 4px 12px rgba(0,0,0,0.4), 0 1px 2px rgba(0,0,0,0.2), inset 0 1px 1px rgba(255,255,255,0.2);
            --icon-color: rgba(255, 255, 255, 0.5);
            --icon-active: #ffffff;
            --card-bg: rgba(30, 30, 35, 0.4);
            --text-primary: #f5f5f7;
            --text-secondary: #86868b;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background: transparent;
            -webkit-font-smoothing: antialiased;
            padding: 20px;
        }

        .bg-mesh {
            position: fixed;
            inset: 0;
            z-index: -1;
            background: var(--bg-color);
            transition: background 0.8s ease;
            overflow: hidden;
        }

        .blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(90px);
            opacity: var(--blob-opacity);
            animation: float 20s infinite alternate cubic-bezier(0.45, 0.05, 0.55, 0.95);
            will-change: transform;
            transition: background 0.8s ease, opacity 0.8s ease;
        }
        .blob-1 { width: 50vw; height: 50vw; top: -10%; left: -10%; background: #00bcd4; animation-delay: 0s; }
        .blob-2 { width: 45vw; height: 45vw; bottom: -10%; right: -10%; background: #00d4aa; animation-delay: -5s; }
        .blob-3 { width: 35vw; height: 35vw; top: 30%; left: 40%; background: #34c759; animation-delay: -10s; }

        @keyframes float {
            0% { transform: translate(0, 0) scale(1) rotate(0deg); }
            33% { transform: translate(5%, 10%) scale(1.05) rotate(5deg); }
            66% { transform: translate(-5%, 5%) scale(0.95) rotate(-5deg); }
            100% { transform: translate(0, -10%) scale(1.1) rotate(0deg); }
        }

        @keyframes fadeUp {
            0% { opacity: 0; transform: translateY(30px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        .auth-container {
            width: 100%;
            max-width: 480px;
            margin: 0 auto;
            position: relative;
            z-index: 10;
        }

        .auth-brand {
            display: block;
            width: fit-content;
            margin: 0 auto 18px;
            text-decoration: none;
            color: #0d5a3d;
            font-size: clamp(22px, 4vw, 28px);
            line-height: 1.2;
            font-weight: 900 !important;
            text-align: center;
            letter-spacing: -.02em;
            position: relative;
            z-index: 12;
            -webkit-tap-highlight-color: transparent;
            transition: transform .18s ease, opacity .18s ease;
        }
        .auth-brand:hover { transform: translateY(-1px); opacity: .88; }
        .auth-brand:active { transform: translateY(0); }

        .auth-card {
            position: relative;
            padding: 40px;
            border-radius: 32px;
            background: var(--glass-bg);
            backdrop-filter: blur(50px) saturate(100%);
            -webkit-backdrop-filter: blur(50px) saturate(100%);
            box-shadow: 0 40px 80px -20px var(--glass-shadow), 0 10px 30px -10px var(--glass-shadow), inset 0 2px 3px -1px var(--glass-highlight), inset 0 -2px 4px -1px var(--glass-caustic), inset 0 0 0 1px var(--glass-border);
            transition: all 0.5s ease;
        }

        .auth-card::before {
            content: '';
            position: absolute;
            top: 2px;
            left: 2px;
            right: 2px;
            height: 40%;
            border-radius: 32px 32px 24px 24px / 32px 32px 12px 12px;
            background: linear-gradient(180deg, var(--reflection-start) 0%, var(--reflection-end) 100%);
            pointer-events: none;
        }

        .auth-title {
            font-size: 2.63rem !important;
            font-weight: 900 !important;
            color: var(--text-primary);
            margin-bottom: 8px;
            position: relative;
            z-index: 2;
            text-align: center;
            opacity: 0;
            animation: fadeUp 0.8s cubic-bezier(0.34, 1.56, 0.64, 1) 0.1s forwards;
        }

        .auth-subtitle {
            font-size: 15px;
            color: var(--text-secondary);
            margin-bottom: 30px;
            position: relative;
            z-index: 2;
            text-align: center;
            opacity: 0;
            animation: fadeUp 0.8s cubic-bezier(0.34, 1.56, 0.64, 1) 0.2s forwards;
        }

        .form-group {
            margin-bottom: 18px;
            position: relative;
            z-index: 2;
            opacity: 0;
            animation: fadeUp 0.8s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
        }

        .form-group:nth-child(1) { animation-delay: 0.3s; }
        .form-group:nth-child(2) { animation-delay: 0.4s; }
        .form-group:nth-child(3) { animation-delay: 0.5s; }
        .form-group:nth-child(4) { animation-delay: 0.6s; }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 6px;
        }

        .form-group label .required {
            color: #ff3b30;
            font-weight: 700;
            margin-left: 2px;
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 12px 16px;
            border-radius: 14px;
            border: 1px solid var(--glass-border);
            background: var(--card-bg);
            color: var(--text-primary);
            font-size: 16px;
            font-family: inherit;
            transition: all 0.3s ease;
            outline: none;
        }

        .form-group input:focus,
        .form-group textarea:focus {
            border-color: #007aff;
            box-shadow: 0 0 0 3px rgba(0, 122, 255, 0.2);
        }

        .form-group input::placeholder,
        .form-group textarea::placeholder {
            color: var(--text-secondary);
            opacity: 0.6;
        }

        .form-group .error-text {
            display: none;
            color: #ff3b30;
            font-size: 13px;
            font-weight: 500;
            margin-top: 6px;
            padding-right: 4px;
        }

        .form-group.error input,
        .form-group.error textarea {
            border-color: #ff3b30 !important;
            box-shadow: 0 0 0 3px rgba(255, 59, 48, 0.15) !important;
        }

        .form-group.error .error-text {
            display: block;
        }

        .form-group .hint {
            color: var(--text-secondary);
            opacity: 0.6;
            font-size: 12px;
            margin-top: 4px;
        }

        .message {
            padding: 12px 16px;
            border-radius: 14px;
            margin-bottom: 20px;
            font-weight: 500;
            position: relative;
            z-index: 2;
            text-align: center;
            font-size: 14px;
            opacity: 0;
            animation: fadeUp 0.8s cubic-bezier(0.34, 1.56, 0.64, 1) 0.15s forwards;
        }
        .message.success {
            background: rgba(52, 199, 89, 0.2);
            color: #34c759;
            border: 1px solid rgba(52, 199, 89, 0.3);
        }
        .message.error {
            background: rgba(255, 59, 48, 0.2);
            color: #ff3b30;
            border: 1px solid rgba(255, 59, 48, 0.3);
        }

        .auth-link {
            text-align: center;
            margin-top: 20px;
            position: relative;
            z-index: 2;
            color: var(--text-secondary);
            font-size: 1.12rem;
            opacity: 0;
            animation: fadeUp 0.8s cubic-bezier(0.34, 1.56, 0.64, 1) 0.8s forwards;
        }
        .auth-link a {
            color: #007aff;
            text-decoration: none;
            font-weight: 600;
        }
        .auth-link a:hover {
            text-decoration: underline;
        }

        /* ============================================ */
        /* دکمه هولوگرام روشن با فونت ExtraBlack */
        /* ============================================ */
        .cta-button-holo-light {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
            width: 100%;
            padding: 22px 30px;
            font-size: 1.4rem;
            font-weight: 900;
            font-family: 'Dana', -apple-system, BlinkMacSystemFont, sans-serif;
            color: #006400;
            background: rgba(255, 255, 255, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 2px solid rgba(255, 255, 255, 0.8);
            border-radius: 50px;
            cursor: pointer;
            position: relative;
            transition: all 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);
            text-shadow: 0 1px 10px rgba(0, 100, 0, 0.1);
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.12);
            z-index: 2;
            user-select: none;
            -webkit-tap-highlight-color: transparent;
            overflow: hidden;
            margin-top: 10px;
            opacity: 0;
            animation: fadeUp 0.8s cubic-bezier(0.34, 1.56, 0.64, 1) 0.7s forwards;
        }

        .cta-button-holo-light .rainbow-light {
            position: absolute;
            top: -2px;
            left: -2px;
            right: -2px;
            bottom: -2px;
            border-radius: 52px;
            background: conic-gradient(from 0deg, 
                #a8e063, #56d4b0, #f9d423, #a8e063, #56d4b0, #f9d423, #a8e063);
            background-size: 300% 300%;
            z-index: -1;
            animation: rainbowSpinLight 4s linear infinite;
            opacity: 0.63;
            transition: opacity 0.6s ease;
        }

        .cta-button-holo-light .rainbow-inner-light {
            position: absolute;
            top: 3px;
            left: 3px;
            right: 3px;
            bottom: 3px;
            border-radius: 47px;
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            z-index: -1;
            transition: all 0.6s ease;
        }

        .cta-button-holo-light .holo-line-light {
            position: absolute;
            width: 200%;
            height: 60px;
            background: linear-gradient(90deg, 
                transparent, 
                rgba(255, 255, 255, 0.2), 
                rgba(86, 212, 176, 0.15),
                rgba(249, 212, 35, 0.15),
                rgba(168, 224, 99, 0.15),
                rgba(255, 255, 255, 0.2),
                transparent
            );
            transform: rotate(25deg);
            opacity: 0;
            transition: all 0.8s ease;
            pointer-events: none;
            z-index: 0;
            top: -30px;
            left: -50%;
            animation: holoMoveLight 3s linear infinite;
        }

        .cta-button-holo-light .holo-line-light:nth-child(4) {
            top: 20px;
            animation-delay: 0.5s;
        }

        .cta-button-holo-light .holo-line-light:nth-child(5) {
            top: 60px;
            animation-delay: 1s;
        }

        .cta-button-holo-light .icon-light {
            font-size: 1.8rem;
            transition: all 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);
            flex-shrink: 0;
            margin-left: 0;
        }

        .cta-button-holo-light:hover {
            transform: translateY(-3px) scale(1.03);
            box-shadow: 0 20px 50px -10px rgba(86, 212, 176, 0.3), 
                        0 0 60px rgba(249, 212, 35, 0.1);
            border-color: rgba(86, 212, 176, 0.3);
            color: #004d00;
        }

        .cta-button-holo-light:hover .rainbow-light {
            opacity: 0.7;
        }

        .cta-button-holo-light:active {
            transform: scale(0.95) !important;
            transition: all 0.15s ease !important;
        }

        .cta-button-holo-light:hover .icon-light {
            transform: rotate(-15deg) scale(1.1);
        }

        .cta-button-holo-light.expanded {
            padding: 22px 45px;
            transform: scale(1.03);
            box-shadow: 0 0 60px rgba(86, 212, 176, 0.15), 0 0 80px rgba(249, 212, 35, 0.08);
            color: #004d00;
        }

        .cta-button-holo-light.expanded .rainbow-light {
            opacity: 0.8;
            animation-duration: 2s;
        }

        .cta-button-holo-light.expanded .holo-line-light {
            opacity: 1;
        }

        .cta-button-holo-light.expanded .icon-light {
            animation: holoIconLight 1s ease;
        }

        /* ===== انیمیشن‌ها ===== */
        @keyframes rainbowSpinLight {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        @keyframes holoMoveLight {
            0% { transform: rotate(25deg) translateX(-100px); opacity: 0; }
            30% { opacity: 0.6; }
            70% { opacity: 0.6; }
            100% { transform: rotate(25deg) translateX(100px); opacity: 0; }
        }

        @keyframes holoIconLight {
            0% { transform: scale(1); }
            25% { transform: scale(1.3) rotate(-15deg); }
            50% { transform: scale(1.1) rotate(10deg); }
            75% { transform: scale(1.2) rotate(-5deg); }
            100% { transform: scale(1) rotate(0deg); }
        }

        .form-hint { color: var(--text-secondary); opacity: .75; font-size: 12px; margin-top: 5px; }
        .optional { color: var(--text-secondary); font-size: 12px; font-weight: 500; }
        /* ===== انتخاب چندگانه توانمندی ===== */
        /* این فرم‌گروه هنگام باز بودن منو باید از خواهرهای بعدی بالاتر قرار بگیرد. */
        .form-group.skills-group-open {
            z-index: 200 !important;
        }

        .skills-select {
            position: relative;
            z-index: 210;
        }

        .skills-select-toggle {
            width: 100%;
            min-height: 48px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 12px 16px;
            border-radius: 14px;
            border: 1px solid var(--glass-border);
            background: var(--card-bg);
            color: var(--text-primary);
            font: inherit;
            cursor: pointer;
            text-align: right;
            -webkit-tap-highlight-color: transparent;
        }

        .skills-select-toggle:focus-visible {
            outline: 2px solid rgba(0, 122, 255, 0.35);
            outline-offset: 2px;
        }

        .skills-placeholder {
            opacity: .72;
            min-width: 0;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .skills-select.open .skills-select-toggle {
            border-color: #007aff;
            box-shadow: 0 0 0 3px rgba(0,122,255,.12);
        }

        .skills-select-menu {
            display: none;
            position: absolute;
            inset-inline: 0;
            top: calc(100% + 8px);
            max-height: min(280px, 45vh);
            overflow-y: auto;
            overflow-x: hidden;
            -webkit-overflow-scrolling: touch;
            overscroll-behavior: contain;
            touch-action: pan-y;
            padding: 8px;
            border: 1px solid rgba(255,255,255,.55);
            border-radius: 16px;
            background: rgba(255,255,255,.96);
            backdrop-filter: blur(22px);
            -webkit-backdrop-filter: blur(22px);
            box-shadow: 0 22px 48px rgba(0,0,0,.18), 0 6px 18px rgba(0,0,0,.08);
            z-index: 1000;
        }

        .skills-confirm-btn {
            position: sticky;
            bottom: 0;
            width: 100%;
            margin-top: 8px;
            padding: 11px 14px;
            border: 1px solid rgba(52, 199, 89, 0.35);
            border-radius: 12px;
            background: #e0ffcc;
            color: #176b2d;
            font: inherit;
            font-weight: 800;
            cursor: pointer;
            box-shadow: 0 -8px 18px rgba(255,255,255,.85);
            z-index: 3;
        }

        .skills-select.open .skills-select-menu {
            display: block;
        }

        .skills-select.open-up .skills-select-menu {
            top: auto;
            bottom: calc(100% + 8px);
        }

        .skill-option {
            position: relative;
            z-index: 1;
            display: flex;
            align-items: center;
            gap: 10px;
            min-height: 46px;
            padding: 10px 12px;
            border-radius: 12px;
            cursor: pointer;
            color: #1c1c1e;
            user-select: none;
            -webkit-user-select: none;
        }

        .skill-option:hover,
        .skill-option:focus-within {
            background: rgba(0,122,255,.08);
        }

        .skill-option input {
            position: absolute !important;
            width: 1px !important;
            height: 1px !important;
            opacity: 0 !important;
            pointer-events: none !important;
        }

        .skill-check {
            width: 22px;
            height: 22px;
            flex: 0 0 22px;
            border-radius: 7px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border: 1px solid rgba(0,0,0,.18);
            background: #fff;
            color: transparent;
            transition: .18s ease;
        }

        .skill-option input:checked + .skill-check {
            background: #34c759;
            border-color: #34c759;
            color: #fff;
        }

        .selected-skill-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 7px;
            margin-top: 9px;
        }

        .selected-skill-tag {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 10px;
            border-radius: 999px;
            background: rgba(52,199,89,.12);
            border: 1px solid rgba(52,199,89,.25);
            color: #176b2d;
            font-size: 12px;
        }

        .selected-skill-tag button {
            border: 0;
            background: transparent;
            color: inherit;
            cursor: pointer;
            padding: 0;
            font-size: 15px;
            line-height: 1;
            -webkit-tap-highlight-color: transparent;
        }

        .skills-select.error .skills-select-toggle {
            border-color: #ff3b30;
            box-shadow: 0 0 0 3px rgba(255,59,48,.12);
        }

        .skills-select.error + .form-hint + .error-text {
            display: block;
        }

        @media (max-width: 500px) {
            .auth-card {
                padding: 24px;
            }
            .auth-title {
                font-size: 2.63rem;
            }
            .cta-button-holo-light {
                padding: 16px 20px;
                font-size: 1.4rem;
                gap: 2px;
            }
            .cta-button-holo-light .icon-light {
                font-size: 1.4rem;
            }
            .cta-button-holo-light.expanded {
                padding: 16px 30px;
            }
            .cta-button-holo-light .holo-line-light {
                display: none;
            }
        }
    </style>
</head>
<body class="auth-page-body">
<?php require __DIR__ . '/includes/page_loader.php'; ?>

    <div class="auth-page-layout">
        <div class="bg-mesh">
        <div class="blob blob-1"></div>
        <div class="blob blob-2"></div>
        <div class="blob blob-3"></div>
        </div>

        <main class="auth-page-main">
            <div class="auth-container">
        <a class="auth-brand" href="index.php" aria-label="پیشروان بصیرت">پیشروان بصیــرت</a>
        <div class="auth-card">
            <h1 class="auth-title">📝ثبت‌نام</h1>

            <?php if ($error): ?>
                <div class="message error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST" action="" id="registerForm" novalidate>
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
                <div class="form-group" id="nameGroup">
                    <label>نام و نام خانوادگی <span class="required">*</span></label>
                    <input type="text" name="full_name" id="fullName" placeholder="مثلاً: علی محمدی" autocomplete="name" required>
                    <div class="error-text">⚠️ لطفاً نام و نام خانوادگی خود را وارد کنید</div>
                </div>

                <div class="form-group" id="phoneGroup">
                    <label>شماره همراه <span class="required">*</span></label>
                    <input type="tel" name="phone" id="phone" placeholder="09123456789" autocomplete="tel" required>
                    <div class="error-text">⚠️ لطفاً شماره همراه معتبر وارد کنید (۰۹۱۲۳۴۵۶۷۸۹)</div>
                    <div class="hint">شماره را بدون فاصله و با ۰۹ وارد کنید</div>
                </div>

                <div class="form-group" id="skillsGroup">
                    <label>توانمندی / مهارت <span class="required">*</span></label>
                    <div class="skills-select" id="skillsSelect">
                        <button type="button" class="skills-select-toggle" aria-haspopup="listbox" aria-expanded="false">
                            <span class="skills-placeholder">توانمندی‌های خود را انتخاب کنید</span>
                            <span class="skills-chevron">⌄</span>
                        </button>
                        <div class="skills-select-menu" role="listbox" aria-multiselectable="true">
                            <?php
                            $skillOptions = $pdo->query("SELECT id, name FROM skill_options WHERE is_active = 1 ORDER BY sort_order, id")->fetchAll();
                            foreach ($skillOptions as $option):
                            ?>
                                <label class="skill-option">
                                    <input type="checkbox" name="skills[]" value="<?= (int)$option['id'] ?>" data-skill-name="<?= e($option['name']) ?>">
                                    <span class="skill-check">✓</span>
                                    <span><?= e($option['name']) ?></span>
                                </label>
                            <?php endforeach; ?>
                            <button type="button" class="skills-confirm-btn" id="skillsConfirmBtn">✓ تایید انتخاب</button>
                        </div>
                        <div class="selected-skill-tags" id="selectedSkillTags"></div>
                    </div>
                    <div class="form-hint">می‌توانید چند مورد را انتخاب کنید.</div>
                    <div class="error-text" id="skillsError">⚠️ حداقل یک توانمندی را انتخاب کنید</div>
                </div>

                <div class="form-group" id="otherSkillGroup" hidden>
                    <label for="otherSkill">توضیح توانمندی «سایر» <span class="optional"> - اختیاری</span></label>
                    <input type="text" name="other_skill" id="otherSkill" placeholder="مثلاً: عکاسی، تدوین، ...">
                    <div class="hint">نوشتن این مورد اختیاری است.</div>
                </div>

                <div class="form-group" id="locationGroup">
                    <label>محدوده محل سکونت <span class="required">*</span></label>
                    <input type="text" name="location" id="location" placeholder="مثلاً: حصارک، رجایی‌شهر، عظیمیه" required>
                    <div class="error-text">⚠️ لطفاً محدوده محل سکونت را وارد کنید</div>
                </div>

                <button type="submit" class="cta-button-holo-light" id="submitBtn">
                    <span class="rainbow-light"></span>
                    <span class="rainbow-inner-light"></span>
                    <span class="holo-line-light"></span>
                    <span class="holo-line-light"></span>
                    <span class="holo-line-light"></span>
                    <span class="icon-light">✨</span>
                    ثبت‌نام و ورود
                </button>
            </form>

            <div class="auth-link">
                قبلاً ثبت‌نام کرده‌اید؟ <a href="login.php">وارد شوید</a>
            </div>
        </div>
            </div>
        </main>

    <script>
        const registerForm = document.getElementById('registerForm');
        const skillsSelect = document.getElementById('skillsSelect');
        const skillsToggle = skillsSelect.querySelector('.skills-select-toggle');
        const skillsMenu = skillsSelect.querySelector('.skills-select-menu');
        const skillsPlaceholder = skillsSelect.querySelector('.skills-placeholder');
        const selectedSkillTags = document.getElementById('selectedSkillTags');
        const otherSkillGroup = document.getElementById('otherSkillGroup');
        const skillsError = document.getElementById('skillsError');
        const skillsConfirmBtn = document.getElementById('skillsConfirmBtn');
        const skillsGroup = document.getElementById('skillsGroup');
        const locationGroup = document.getElementById('locationGroup');
        const locationInput = document.getElementById('location');

        function refreshSkillSelection() {
            const checked = [...skillsMenu.querySelectorAll('input[type="checkbox"]:checked')];
            selectedSkillTags.innerHTML = '';
            if (!checked.length) {
                skillsPlaceholder.textContent = 'توانمندی‌های خود را انتخاب کنید';
            } else {
                skillsPlaceholder.textContent = checked.map(i => i.dataset.skillName).join('، ');
                checked.forEach(input => {
                    const tag = document.createElement('span');
                    tag.className = 'selected-skill-tag';
                    tag.innerHTML = `<span>${input.dataset.skillName}</span><button type="button" aria-label="حذف ${input.dataset.skillName}">×</button>`;
                    tag.querySelector('button').addEventListener('click', () => {
                        input.checked = false;
                        refreshSkillSelection();
                    });
                    selectedSkillTags.appendChild(tag);
                });
            }
            const hasOther = checked.some(i => i.dataset.skillName === 'سایر');
            otherSkillGroup.hidden = !hasOther;
            if (checked.length) {
                skillsSelect.classList.remove('error');
                skillsError.style.display = 'none';
            }
            if (skillsGroup) skillsGroup.classList.toggle('skills-group-open', skillsSelect.classList.contains('open'));
        }

        function positionSkillsMenu() {
            if (!skillsSelect.classList.contains('open')) return;
            skillsSelect.classList.remove('open-up');

            const rect = skillsSelect.getBoundingClientRect();
            const viewportHeight = window.innerHeight;
            const estimatedMenuHeight = Math.min(280, Math.floor(viewportHeight * 0.45));
            const spaceBelow = viewportHeight - rect.bottom - 16;
            const spaceAbove = rect.top - 16;

            if (spaceBelow < Math.min(estimatedMenuHeight, 220) && spaceAbove > spaceBelow) {
                skillsSelect.classList.add('open-up');
            }
        }

        skillsToggle.addEventListener('click', () => {
            const open = !skillsSelect.classList.contains('open');
            skillsSelect.classList.toggle('open', open);
            skillsToggle.setAttribute('aria-expanded', String(open));
            if (skillsGroup) skillsGroup.classList.toggle('skills-group-open', open);

            if (open) {
                requestAnimationFrame(positionSkillsMenu);
            }
        });

        skillsConfirmBtn.addEventListener('click', (event) => {
            event.preventDefault();
            event.stopPropagation();
            const checked = skillsMenu.querySelectorAll('input[type="checkbox"]:checked');
            if (checked.length) {
                skillsSelect.classList.remove('error');
                skillsError.style.display = 'none';
            }
            skillsSelect.classList.remove('open', 'open-up');
            skillsToggle.setAttribute('aria-expanded', 'false');
            if (skillsGroup) skillsGroup.classList.remove('skills-group-open');
        });

        window.addEventListener('resize', positionSkillsMenu);
        window.addEventListener('scroll', positionSkillsMenu, { passive: true });
        skillsMenu.addEventListener('change', refreshSkillSelection);
        skillsMenu.addEventListener('wheel', (event) => {
            event.stopPropagation();
        }, { passive: true });

        skillsMenu.addEventListener('touchmove', (event) => {
            event.stopPropagation();
        }, { passive: true });

        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape' && skillsSelect.classList.contains('open')) {
                skillsSelect.classList.remove('open', 'open-up');
                skillsToggle.setAttribute('aria-expanded', 'false');
                if (skillsGroup) skillsGroup.classList.remove('skills-group-open');
            }
        });

        document.addEventListener('click', (event) => {
            if (!skillsSelect.contains(event.target)) {
                skillsSelect.classList.remove('open', 'open-up');
                skillsToggle.setAttribute('aria-expanded', 'false');
                if (skillsGroup) skillsGroup.classList.remove('skills-group-open');
            }
        });

        registerForm.addEventListener('submit', function(e) {
            let isValid = true;
            const fullName = document.getElementById('fullName');
            const nameGroup = document.getElementById('nameGroup');
            nameGroup.classList.toggle('error', fullName.value.trim() === '');
            if (!fullName.value.trim()) isValid = false;

            const phone = document.getElementById('phone');
            const phoneGroup = document.getElementById('phoneGroup');
            const phonePattern = /^09[0-9]{9}$/;
            phoneGroup.classList.toggle('error', !phonePattern.test(phone.value.trim()));
            if (!phonePattern.test(phone.value.trim())) isValid = false;

            const checked = skillsMenu.querySelectorAll('input[type="checkbox"]:checked');
            if (!checked.length) {
                skillsSelect.classList.add('error');
                skillsError.style.display = 'block';
                isValid = false;
            }

            locationGroup.classList.toggle('error', locationInput.value.trim() === '');
            if (!locationInput.value.trim()) isValid = false;

            if (!isValid) {
                e.preventDefault();
                const firstError = document.querySelector('.form-group.error, .skills-select.error');
                if (firstError) firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        });

        document.querySelectorAll('#registerForm input').forEach(function(input) {
            input.addEventListener('input', function() {
                const group = this.closest('.form-group');
                if (group) group.classList.remove('error');
            });
        });

        // حالت اولیه باید کاملاً عادی باشد؛ خطای توانمندی فقط هنگام Submit نمایش داده می‌شود.
        skillsSelect.classList.remove('error');
        skillsError.style.display = 'none';
        refreshSkillSelection();

        document.getElementById('submitBtn').addEventListener('click', function(e) {
            const hasError = document.querySelector('.form-group.error');
            if (!hasError) {
                this.classList.add('expanded');
            }
        });
    </script>

<script src="assets/js/app.js?v=20261001-v13" defer></script>

<?php require __DIR__ . '/includes/site_footer.php'; ?>
    </div>
</body>
</html>