<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

require_login('login.php');
$user = getUser($pdo);
$userId = (int)$_SESSION['user_id'];

if (!studySessionTablesAvailable($pdo)) {
    http_response_code(503);
    $setupNeeded = true;
} else {
    $setupNeeded = false;
    $chapters = getActiveStudyChapters($pdo);
    $sessions = getActiveStudySessions($pdo);
    $progressMap = getUserSessionProgressMap($pdo, $userId);
    $accessMap = [];
    $previousCompleted = true;
    $accessGrant = getUserSessionAccessGrant($pdo, $userId);
    $grantSessionId = $accessGrant ? (int)($accessGrant['max_session_id'] ?? 0) : 0;
    $grantIndex = null;
    foreach ($sessions as $idx => $item) {
        if ($grantSessionId > 0 && (int)$item['id'] === $grantSessionId) { $grantIndex = $idx; break; }
    }
    foreach ($sessions as $index => $session) {
        $sid = (int)$session['id'];
        $progressMap[$sid] = $progressMap[$sid] ?? getUserSessionProgress($pdo, $userId, $sid);
        $grantAccess = ($grantIndex !== null && $index <= $grantIndex);
        $accessMap[$sid] = $grantAccess || $previousCompleted;
        $previousCompleted = $previousCompleted && ((int)$progressMap[$sid]['is_completed'] === 1);
    }
}

function toFaDigits(string $value): string {
    return strtr($value, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']);
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>مسیر مطالعه | پیشروان بصیرت</title>
<link rel="stylesheet" href="assets/css/style.css?v=20260921-sessions1">
<style>
body.sessions-page{min-height:100vh;padding:0;display:block!important;overflow-x:hidden!important;}
.sessions-main{width:min(1040px,calc(100% - 24px));margin:24px auto 48px;}
.sessions-hero,.chapter-block,.empty-session{background:rgba(255,255,255,.66);backdrop-filter:blur(34px) saturate(115%);-webkit-backdrop-filter:blur(34px) saturate(115%);border:1px solid rgba(255,255,255,.5);box-shadow:0 22px 55px -28px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.7);border-radius:28px;}
.sessions-hero{padding:28px 30px;margin-bottom:20px;}
.sessions-hero h1{margin:0 0 8px;font-size:30px;color:var(--text-primary);font-weight:800;}
.sessions-hero p{margin:0;color:var(--text-secondary);line-height:2;font-size:15px;}
.progress-chip{display:inline-flex;align-items:center;gap:7px;margin-top:14px;background:rgba(16,173,154,.1);color:#108e7f;padding:7px 12px;border-radius:999px;font-size:13px;font-weight:700;border:1px solid rgba(16,173,154,.15);}
.chapter-block{overflow:hidden;margin-bottom:18px;}
.chapter-head{padding:0;background:rgba(255,255,255,.46);border-bottom:1px solid rgba(0,0,0,.06);}
.chapter-toggle{width:100%;padding:18px 20px;display:flex;align-items:center;justify-content:space-between;gap:12px;background:transparent;border:0;color:inherit;font:inherit;text-align:right;cursor:pointer;}
.chapter-toggle:focus-visible{outline:2px solid #10ad9a;outline-offset:-2px;border-radius:18px;}
.chapter-head h2{margin:0;font-size:19px;color:var(--text-primary);font-weight:800;}
.chapter-head span{font-size:12px;color:var(--text-secondary);}
.chapter-head-right{display:flex;align-items:center;gap:12px;flex:0 0 auto;}
.chapter-chevron{font-size:15px;color:#8b95a1;transition:transform .24s ease;}
.chapter-block.open .chapter-chevron{transform:rotate(180deg);}
.chapter-panel{max-height:0;overflow:hidden;opacity:0;transition:max-height .42s cubic-bezier(.22,1,.36,1),opacity .24s ease;}
.chapter-block.open .chapter-panel{opacity:1;}
.chapter-panel .session-list{padding:14px;}
.session-list{display:flex;flex-direction:column;gap:10px;padding:14px;}
.session-card{display:flex;align-items:center;gap:14px;padding:16px 18px;border:1px solid rgba(0,0,0,.06);border-radius:20px;background:rgba(255,255,255,.72);text-decoration:none;color:inherit;transition:transform .2s ease,box-shadow .2s ease,border-color .2s ease;user-select:none;-webkit-user-select:none;}
.session-card:hover{transform:translateY(-2px);box-shadow:0 12px 28px -20px rgba(0,0,0,.3);border-color:rgba(16,173,154,.22);}
.session-card.locked{opacity:.65;cursor:not-allowed;}
.session-card .session-icon{width:54px;height:54px;flex:0 0 54px;border-radius:17px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#e6fbf7,#dff0ff);font-size:24px;position:relative;box-shadow:0 8px 18px -12px rgba(16,173,154,.45);}
.session-card .seq{position:absolute;bottom:-7px;left:-6px;width:26px;height:26px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:900;color:#108e7f;border:1px solid rgba(16,173,154,.16);}
.session-body{min-width:0;flex:1;}
.session-title{font-size:16px;font-weight:800;color:var(--text-primary);margin-bottom:5px;line-height:1.7;}
.session-summary{font-size:13px;color:var(--text-secondary);line-height:1.8;overflow:hidden;}
.session-status{flex:0 0 auto;font-size:12px;font-weight:800;padding:6px 10px;border-radius:999px;background:rgba(0,122,255,.08);color:#007aff;white-space:nowrap;}
.session-status.done{background:rgba(52,199,89,.12);color:#198c41;}
.session-status.locked{background:rgba(130,130,130,.1);color:#777;}
.empty-session{padding:28px;text-align:center;color:var(--text-secondary);line-height:2;}
.setup-note{padding:28px;}
@media(max-width:680px){.sessions-main{width:min(100% - 16px,1040px);margin-top:12px}.sessions-hero{padding:22px 18px;border-radius:22px}.sessions-hero h1{font-size:24px}.chapter-toggle{padding:15px 16px}.chapter-head h2{font-size:17px}.session-card{padding:14px}.session-card .session-icon{width:48px;height:48px;flex-basis:48px;font-size:22px}.session-title{font-size:15px}.session-summary{font-size:12px}.session-status{font-size:11px;padding:5px 8px}}
</style>
</head>
<body class="user-page sessions-page">
<div class="bg-mesh"><div class="blob blob-1"></div><div class="blob blob-2"></div><div class="blob blob-3"></div></div>
<?php require __DIR__ . '/includes/page_loader.php'; ?>
<div class="site-shell">
<?php require __DIR__ . '/includes/site_header.php'; ?>
<main class="sessions-main">
<?php if ($setupNeeded): ?>
<section class="empty-session setup-note">
    <h1 style="margin:0 0 10px;font-size:22px;color:var(--text-primary);">سامانه جلسات هنوز راه‌اندازی نشده است.</h1>
    <p style="margin:0;">ابتدا فایل <strong>sessions_migration.sql</strong> را در دیتابیس اجرا کنید.</p>
</section>
<?php else: ?>
<section class="sessions-hero">
    <h1>📚 مسیر مطالعه من</h1>
    <p>از جلسه اول شروع کن، هر جلسه را مطالعه و خودآزمایی‌اش را با موفقیت پشت سر بگذار تا جلسه بعدی باز شود. جلسات تکمیل‌شده همیشه برای مرور در دسترس هستند.</p>
    <?php
        $completedCount = 0;
        foreach ($progressMap as $pr) if ((int)$pr['is_completed'] === 1) $completedCount++;
    ?>
    <div class="progress-chip">✓ <?= toFaDigits((string)$completedCount) ?> جلسه از <?= toFaDigits((string)count($sessions)) ?> جلسه تکمیل شده</div>
</section>
<?php if (!$sessions): ?>
<div class="empty-session">هنوز هیچ جلسه فعالی منتشر نشده است.</div>
<?php else: ?>
<?php
$byChapter = [];
foreach ($sessions as $session) {
    $chapterId = (int)$session['chapter_id'];
    $byChapter[$chapterId]['title'] = (string)($session['chapter_title'] ?: 'فصل بدون عنوان');
    $byChapter[$chapterId]['items'][] = $session;
}
$chapterCounter = 0;
foreach ($byChapter as $chapter):
    $chapterCounter++;
    $isChapterOpen = ($chapterCounter === 1);
    $panelId = 'chapter-panel-' . $chapterCounter;
?>
<section class="chapter-block<?= $isChapterOpen ? ' open' : '' ?>" data-path-chapter>
    <div class="chapter-head">
        <button type="button" class="chapter-toggle" data-chapter-toggle aria-expanded="<?= $isChapterOpen ? 'true' : 'false' ?>" aria-controls="<?= e($panelId) ?>">
            <div><h2><?= e($chapter['title']) ?></h2></div>
            <span class="chapter-head-right"><span><?= toFaDigits((string)count($chapter['items'])) ?> جلسه</span><span class="chapter-chevron" aria-hidden="true">⌄</span></span>
        </button>
    </div>
    <div class="chapter-panel" id="<?= e($panelId) ?>">
      <div class="session-list">
      <?php foreach ($chapter['items'] as $session):
          $sid = (int)$session['id'];
          $progress = $progressMap[$sid];
          $completed = (int)$progress['is_completed'] === 1;
          $open = $accessMap[$sid] ?? false;
          $label = $completed ? 'تکمیل شده' : ($open ? 'در دسترس' : 'قفل');
          $statusClass = $completed ? 'done' : ($open ? '' : 'locked');
      ?>
          <?php if ($open): ?><a class="session-card" href="study.php?session_id=<?= $sid ?>"><?php else: ?><div class="session-card locked" aria-disabled="true"><?php endif; ?>
              <div class="session-icon"><?= $completed ? '✅' : '📖' ?><span class="seq"><?= e(toFaDigits((string)$session['sequence_no'])) ?></span></div>
              <div class="session-body"><div class="session-title"><?= e((string)$session['title']) ?></div><div class="session-summary"><?= e((string)($session['summary'] ?: 'مطالعه این جلسه و سپس خودآزمایی آن')) ?></div></div>
              <span class="session-status <?= $statusClass ?>"><?= e($label) ?></span>
          <?php if ($open): ?></a><?php else: ?></div><?php endif; ?>
      <?php endforeach; ?>
      </div>
    </div>
</section>
<?php endforeach; ?>
<?php endif; ?>
<?php endif; ?>
</main>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
</div>
<script>
(function(){
    'use strict';
    var chapters = Array.prototype.slice.call(document.querySelectorAll('[data-path-chapter]'));
    function setOpen(chapter, open, animate){
        var panel = chapter.querySelector('.chapter-panel');
        var button = chapter.querySelector('[data-chapter-toggle]');
        if(!panel) return;
        if(!animate) panel.style.transition='none';
        chapter.classList.toggle('open', open);
        if(button) button.setAttribute('aria-expanded', open ? 'true' : 'false');
        panel.style.maxHeight = open ? panel.scrollHeight + 'px' : '0px';
        if(!animate) window.requestAnimationFrame(function(){ panel.style.transition=''; });
    }
    chapters.forEach(function(chapter){
        var button = chapter.querySelector('[data-chapter-toggle]');
        setOpen(chapter, chapter.classList.contains('open'), false);
        if(!button) return;
        button.addEventListener('click', function(){
            var shouldOpen = !chapter.classList.contains('open');
            if(shouldOpen){
                chapters.forEach(function(other){ if(other !== chapter && other.classList.contains('open')) setOpen(other, false, true); });
            }
            setOpen(chapter, shouldOpen, true);
        });
    });
    window.addEventListener('resize', function(){
        chapters.forEach(function(chapter){
            if(!chapter.classList.contains('open')) return;
            var panel = chapter.querySelector('.chapter-panel');
            if(panel) panel.style.maxHeight = panel.scrollHeight + 'px';
        });
    });
})();
</script>
<script src="assets/js/app.js?v=20260921-sessions1" defer></script>
</body>
</html>
