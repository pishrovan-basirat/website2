const CACHE_NAME = 'pbasirat-app-v6-20261001-pwa-install';
const APP_SHELL = [
  '/manifest.webmanifest',
  '/assets/css/style.css?v=20261001-pwa-v1',
  '/assets/js/app.js?v=20261001-pwa-v1',
  '/assets/fonts/Dana-Regular.woff2',
  '/assets/fonts/Dana-Medium.woff2',
  '/assets/fonts/Dana-DemiBold.woff2',
  '/assets/fonts/Dana-Bold.woff2',
  '/assets/images/pblogo.jpg',
  '/assets/images/book-icon.svg',
  '/assets/images/pen-icon.svg',
  '/assets/images/eitaa-icon.png',
  '/assets/images/pwa-icon-192.png',
  '/assets/images/pwa-icon-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener('message', event => {
  if (event.data && event.data.type === 'CLEAR_HOME_CACHE') {
    event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.delete('/home.php')));
  }
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then(async response => {
          if (response.ok && new URL(request.url).pathname === '/home.php') {
            const copy = response.clone();
            const cache = await caches.open(CACHE_NAME);
            await cache.put('/home.php', copy);
          }
          return response;
        })
        .catch(async () => {
          const cachedHome = await caches.match('/home.php');
          return cachedHome || new Response(
            '<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>پیشروان بصیرت</title><body style="font-family:sans-serif;text-align:center;padding:40px">برای استفاده آفلاین، یک بار صفحه خانه را هنگام اتصال به اینترنت باز کنید.</body></html>',
            { status: 503, headers: { 'Content-Type': 'text/html; charset=utf-8' } }
          );
        })
    );
    return;
  }

  event.respondWith(
    caches.match(request).then(cached => {
      if (cached) return cached;
      return fetch(request).then(response => {
        if (response.ok) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(request, copy)).catch(() => {});
        }
        return response;
      });
    })
  );
});
