-- ================================================================
-- پاک‌سازی سیستم قدیمی آزمون
-- این فایل را فقط زمانی اجرا کنید که مطمئن هستید تمام محتوا و
-- سؤالات به study_sessions و session_questions منتقل شده‌اند.
--
-- توجه: MySQL از RENAME TABLE IF EXISTS پشتیبانی نمی‌کند.
-- فقط خطوطی را اجرا کنید که جدول مربوطه وجود دارد.
-- اگر جدولی وجود نداشته باشد، آن خط را رد کنید.
-- ================================================================

-- آرشیو جدول‌های قدیمی سیستم آزمون روزانه
-- (در صورت وجود، خط زیر را اجرا کنید)
RENAME TABLE exam_questions TO legacy_exam_questions;
RENAME TABLE exam_versions TO legacy_exam_versions;
RENAME TABLE exam_version_questions TO legacy_exam_version_questions;
RENAME TABLE user_exam_attempts TO legacy_user_exam_attempts;
RENAME TABLE user_exam_answers TO legacy_user_exam_answers;

-- آرشیو جدول محتوای قدیمی مطالعه (محتوا اکنون در study_sessions.content قرار دارد)
RENAME TABLE study_content TO legacy_study_content;

-- آرشیو جدول قدیمی زمان‌سنج روزانه (اکنون از user_session_progress.study_seconds استفاده می‌شود)
RENAME TABLE user_daily_study TO legacy_user_daily_study;

-- ================================================================
-- نکته: اگر پس از مدتی مطمئن شدید دیگر به این جداول نیاز ندارید،
-- می‌توانید آن‌ها را حذف کنید:
--
-- DROP TABLE IF EXISTS legacy_exam_questions;
-- DROP TABLE IF EXISTS legacy_exam_versions;
-- DROP TABLE IF EXISTS legacy_exam_version_questions;
-- DROP TABLE IF EXISTS legacy_user_exam_attempts;
-- DROP TABLE IF EXISTS legacy_user_exam_answers;
-- DROP TABLE IF EXISTS legacy_study_content;
-- DROP TABLE IF EXISTS legacy_user_daily_study;
-- ================================================================
