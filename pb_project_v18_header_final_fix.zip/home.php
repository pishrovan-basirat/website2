<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

require_login('login.php');
$user = getUser($pdo);
$userId = (int)$_SESSION['user_id'];
$today = date('Y-m-d');
$eitaaJoinUrl = getSiteSetting($pdo, 'home_eitaa_join_url', 'https://eitaa.com/');

$sessionSystem = studySessionTablesAvailable($pdo);
$chapters = [];
$allSessions = [];
$completedSessions = 0;
$totalSessions = 0;
$overallPercent = 0;
$currentSession = null;
$currentSessionProgress = null;

if ($sessionSystem) {
    $chapters = getActiveStudyChapters($pdo);
    $allSessions = getActiveStudySessions($pdo);
    $progressMap = getUserSessionProgressMap($pdo, $userId);
    $activeSessionIds = [];
    foreach ($allSessions as $session) $activeSessionIds[(int)$session['id']] = true;
    $archivedCompletedCount = 0;
    foreach ($progressMap as $sid => $pr) {
        if (!isset($activeSessionIds[(int)$sid]) && (int)($pr['is_completed'] ?? 0) === 1) $archivedCompletedCount++;
    }
    $archivedProgressCount = $archivedCompletedCount;
    $totalSessions = count($allSessions) + $archivedProgressCount;

    $previousCompleted = true;
    $accessMap = [];
    $accessGrant = getUserSessionAccessGrant($pdo, $userId);
    $grantSessionId = $accessGrant ? (int)($accessGrant['max_session_id'] ?? 0) : 0;
    $grantIndex = null;
    foreach ($allSessions as $idx => $item) {
        if ($grantSessionId > 0 && (int)$item['id'] === $grantSessionId) { $grantIndex = $idx; break; }
    }
    foreach ($allSessions as $index => $session) {
        $sid = (int)$session['id'];
        $progressMap[$sid] = $progressMap[$sid] ?? getUserSessionProgress($pdo, $userId, $sid);
        $grantAccess = ($grantIndex !== null && $index <= $grantIndex);
        $accessMap[$sid] = $grantAccess || $previousCompleted;
        $previousCompleted = $previousCompleted && ((int)$progressMap[$sid]['is_completed'] === 1);
        if ((int)($progressMap[$sid]['is_completed'] ?? 0) === 1) $completedSessions++;
    }

    $completedSessions += $archivedCompletedCount;
    $overallPercent = $totalSessions > 0 ? (int)round(($completedSessions / $totalSessions) * 100) : 0;
    $currentSession = getNextStudySessionForUser($pdo, $userId, $progressMap);

    foreach ($chapters as &$chapter) {
        $chapterSessions = [];
        $chapterCompleted = 0;
        foreach ($allSessions as $session) {
            if ((int)$session['chapter_id'] === (int)$chapter['id']) {
                $sid = (int)$session['id'];
                $session['progress'] = $progressMap[$sid] ?? null;
                $session['is_completed'] = (int)($progressMap[$sid]['is_completed'] ?? 0) === 1;
                $session['is_accessible'] = $accessMap[$sid] ?? false;
                if ($session['is_completed']) $chapterCompleted++;
                $chapterSessions[] = $session;
            }
        }
        $chapter['sessions'] = $chapterSessions;
        $chapter['completed_count'] = $chapterCompleted;
        $chapter['total_count'] = count($chapterSessions);
        $chapter['percent'] = $chapter['total_count'] > 0 ? (int)round(($chapterCompleted / $chapter['total_count']) * 100) : 0;
    }
    unset($chapter);
}

$noteStmt = $pdo->prepare('SELECT * FROM daily_notes WHERE note_date = ? LIMIT 1');
$noteStmt->execute([$today]);
$todayNote = $noteStmt->fetch() ?: null;

$jalali = gregorianToJalali($today);
$parts = explode('/', $jalali);
$monthNames = [1=>'فروردین',2=>'اردیبهشت',3=>'خرداد',4=>'تیر',5=>'مرداد',6=>'شهریور',7=>'مهر',8=>'آبان',9=>'آذر',10=>'دی',11=>'بهمن',12=>'اسفند'];
$todayLong = sprintf('%d %s %d', (int)$parts[2], $monthNames[(int)$parts[1]] ?? '', (int)$parts[0]);

function toFaDigits(string $value): string {
    return strtr($value, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']);
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>خانه | پیشروان بصیرت</title>
<link rel="manifest" href="/manifest.webmanifest">
<link rel="apple-touch-icon" href="/assets/images/pwa-icon-192.png">
<meta name="theme-color" content="#10ad9a">
<link rel="stylesheet" href="assets/css/style.css?v=20261001-pwa-v1">
<style>
/* ===== Dev Banner ===== */
.dev-banner{width:100%;background:rgba(255,165,0,.22);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);text-align:center;padding:6px 12px;font-size:11px;font-weight:700;color:#1a1a1a;letter-spacing:.2px}

/* ===== Base ===== */
/* Header sticky reliability: avoid creating an unrelated horizontal scroll container on this page. */
html { overflow-x: clip !important; }
body.home-page{display:block!important;min-height:100vh;margin:0;padding:0;overflow-x:clip!important;font-family:'Dana',-apple-system,BlinkMacSystemFont,sans-serif}
body.home-page .site-header.site-header--minimal{position:-webkit-sticky!important;position:sticky!important;top:0!important;z-index:100002!important;}
body.home-page .site-shell{position:relative!important;overflow:visible!important;transform:none!important;filter:none!important;contain:none!important;}
.home-main{width:min(860px,calc(100% - 24px));margin:18px auto 56px}

/* ===== Hero ===== */
.hero{position:relative;overflow:hidden;border-radius:24px;padding:26px 24px;color:#fff;background:linear-gradient(135deg,#0fb8a6 0%,#0a9d8e 35%,#0d7b6f 70%,#096862 100%);box-shadow:0 20px 50px -24px rgba(15,184,166,.55)}
.hero::before{content:'';position:absolute;top:-30%;left:-8%;width:220px;height:220px;border-radius:50%;background:rgba(255,255,255,.08)}
.hero::after{content:'';position:absolute;bottom:-25%;right:-5%;width:160px;height:160px;border-radius:50%;background:rgba(255,255,255,.06)}
.hero-top{position:relative;z-index:2;display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:16px}
.hero-logo{display:flex;align-items:center;gap:10px}
.hero-logo img{width:44px;height:44px;border-radius:12px;box-shadow:0 6px 16px rgba(0,0,0,.18)}
.hero-brand{font-size:15px;font-weight:800;opacity:.92}
.hero-date{position:relative;z-index:2;font-size:13px;opacity:.85;margin:0 0 4px}
.hero-title{position:relative;z-index:2;margin:0 0 6px;font-size:20px;font-weight:850;line-height:1.6}
.hero-subtitle{position:relative;z-index:2;margin:0 0 16px;font-size:13px;line-height:1.8;opacity:.88}

/* Overall progress — redesigned */
.hero-progress{position:relative;z-index:2;overflow:hidden;background:linear-gradient(145deg,rgba(255,255,255,.17),rgba(255,255,255,.07));border:1px solid rgba(255,255,255,.18);border-radius:22px;padding:18px 19px;box-shadow:inset 0 1px 0 rgba(255,255,255,.12),0 12px 30px -22px rgba(0,0,0,.45)}
.progress-top{display:flex;align-items:flex-end;justify-content:space-between;gap:14px}
.progress-caption{min-width:0}
.progress-caption .label{font-size:11px;opacity:.72;margin:0 0 4px}
.progress-caption .title{font-size:15px;font-weight:850;line-height:1.6;margin:0}
.progress-percent{font-size:34px;font-weight:950;line-height:1;background:linear-gradient(180deg,#fff,#d7fff9);-webkit-background-clip:text;background-clip:text;color:transparent;letter-spacing:-1px;flex:0 0 auto}
.progress-track{height:10px;border-radius:999px;background:rgba(0,0,0,.18);margin-top:15px;overflow:hidden;box-shadow:inset 0 1px 3px rgba(0,0,0,.14)}
.progress-fill{height:100%;width:<?= max(0,min(100,$overallPercent)) ?>%;border-radius:inherit;background:linear-gradient(90deg,#fff,rgba(255,255,255,.72));box-shadow:0 0 18px rgba(255,255,255,.35);transition:width .8s cubic-bezier(.22,1,.36,1)}
.progress-bottom{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:10px;font-size:11px;color:rgba(255,255,255,.8)}
.progress-stat{display:inline-flex;align-items:center;gap:6px;white-space:nowrap}
.progress-stat strong{font-size:13px;color:#fff}

/* Continue CTA — big and eye-catching */
.hero-cta{position:relative;z-index:2;display:flex;align-items:center;justify-content:space-between;gap:14px;margin-top:16px;background:linear-gradient(135deg,#f59e0b,#f97316);border:none;border-radius:18px;padding:18px 22px;text-decoration:none;color:#fff;transition:transform .2s,box-shadow .2s;box-shadow:0 9px 24px -10px rgba(249,115,22,.24),0 3px 9px rgba(0,0,0,.04)}
.hero-cta:hover{transform:translateY(-2px);box-shadow:0 12px 28px -8px rgba(249,115,22,.32),0 4px 10px rgba(0,0,0,.05)}
.hero-cta-text{font-size:32px;font-weight:900;line-height:1.3}
.hero-cta-text small{display:block;font-weight:700;opacity:.9;font-size:13px;margin-top:5px}
.hero-cta-arrow{flex:0 0 50px;width:50px;height:50px;border-radius:15px;background:rgba(255,255,255,.2);border:1px solid rgba(255,255,255,.3);display:flex;align-items:center;justify-content:center;box-shadow:0 7px 16px rgba(0,0,0,.08),inset 0 1px 0 rgba(255,255,255,.28);transition:transform .2s ease,background .2s ease}
.hero-cta:hover .hero-cta-arrow{transform:translateX(-3px);background:rgba(255,255,255,.27)}
.hero-cta-arrow svg{width:30px;height:30px;display:block}

/* ===== Course Container ===== */
.course-card{background:#fff;border:1px solid #e5e7eb;border-radius:20px;overflow:hidden;margin-top:18px;box-shadow:0 10px 30px -16px rgba(0,0,0,.1)}

/* Module header */
.module{border-bottom:1px solid #f0f0f0}
.module:last-child{border-bottom:none}
.module-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:16px 18px;cursor:pointer;background:none;border:none;width:100%;text-align:right;font-family:inherit;transition:background .2s}
.module-head:hover{background:#f9fafb}
.module-head-left{display:flex;align-items:center;gap:12px;min-width:0}
.module-icon{width:40px;height:40px;flex:0 0 40px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:18px;background:linear-gradient(135deg,#e6fbf7,#f0f7ff)}
.module-title{font-size:15px;font-weight:800;color:#1f2937;line-height:1.5}
.module-meta{font-size:11px;color:#9ca3af;margin-top:2px}
.module-head-right{display:flex;align-items:center;gap:10px;flex:0 0 auto}
.module-percent{position:relative;width:42px;height:42px;flex:0 0 42px}
.module-percent svg{transform:rotate(-90deg)}
.mp-bg{fill:none;stroke:#e5e7eb;stroke-width:4}
.mp-fg{fill:none;stroke:#10b981;stroke-width:4;stroke-linecap:round;transition:stroke-dashoffset .6s ease}
.mp-fg.partial{stroke:#f59e0b}
.mp-fg.zero{stroke:#d1d5db}
.mp-text{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:10px;font-weight:900;color:#374151}
.module-chevron{font-size:14px;color:#9ca3af;transition:transform .25s;flex:0 0 auto}
.module.open .module-chevron{transform:rotate(180deg)}

/* Lesson cards inside module */
.module-body{display:block;max-height:0;overflow-y:hidden;overflow-x:hidden;overscroll-behavior:contain;opacity:0;padding:0;background-color:#f7f7f7;transition:max-height .48s cubic-bezier(.22,1,.36,1),opacity .28s ease}
.module.open .module-body{opacity:1;padding:0;max-height:234px;overflow-y:auto;background-color:#f7f7f7;-webkit-overflow-scrolling:touch}
.module.open .module-body::-webkit-scrollbar{width:7px}
.module.open .module-body::-webkit-scrollbar-track{background:rgba(0,0,0,.035);border-radius:999px}
.module.open .module-body::-webkit-scrollbar-thumb{background:rgba(16,173,154,.28);border-radius:999px}
.module.open .module-body{scrollbar-width:thin;scrollbar-color:rgba(16,173,154,.32) rgba(0,0,0,.035)}

.lesson-card{display:flex;align-items:center;gap:14px;padding:14px 16px;margin:6px 0;border-radius:16px;background:#f0fdf4;border:1px solid #dcfce7;text-decoration:none;color:inherit;transition:transform .2s,box-shadow .2s;position:relative}
.lesson-card:hover{transform:translateY(-1px);box-shadow:0 8px 20px -12px rgba(16,173,154,.3)}
.lesson-card.locked{background:#f9fafb;border-color:#e5e7eb;opacity:.6;cursor:default}
.lesson-card.locked:hover{transform:none;box-shadow:none}
.lesson-card.current{background:#eff6ff;border-color:#bfdbfe}
.lesson-card.current:hover{box-shadow:0 8px 20px -12px rgba(59,130,246,.3)}

.lesson-status{width:38px;height:38px;flex:0 0 38px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:16px;position:relative}
.lesson-status.completed{background:#10b981;color:#fff}
.lesson-status.available{background:#dbeafe;color:#3b82f6}
.lesson-status.locked{background:#f3f4f6;color:#9ca3af}
.lesson-status .seq{position:absolute;bottom:-6px;left:-5px;width:22px;height:22px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:900;border:1px solid #e5e7eb}
.lesson-status.completed .seq{color:#10b981}
.lesson-status.available .seq{color:#3b82f6}
.lesson-status.locked .seq{color:#9ca3af}

.lesson-body{flex:1;min-width:0}
.lesson-title{font-size:14px;font-weight:800;color:#1f2937;margin-bottom:3px;line-height:1.5;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.lesson-meta{display:flex;align-items:center;gap:10px;font-size:11px;color:#6b7280}
.lesson-meta .time{display:inline-flex;align-items:center;gap:3px}
.lesson-badge{flex:0 0 auto;font-size:10px;font-weight:800;padding:4px 9px;border-radius:99px;white-space:nowrap}
.lesson-badge.done{background:#d1fae5;color:#059669}
.lesson-badge.current{background:#dbeafe;color:#2563eb}
.lesson-badge.locked{background:#f3f4f6;color:#9ca3af}

/* ===== Glass cards (PWA, Eitaa, Note) ===== */
.glass-card{background:rgba(255,255,255,.7);backdrop-filter:blur(28px);-webkit-backdrop-filter:blur(28px);border:1px solid rgba(255,255,255,.6);border-radius:20px;padding:20px;margin-top:14px;box-shadow:0 12px 35px -20px rgba(0,0,0,.12)}

/* PWA install */
.pwa-row,.eitaa-row{display:flex;align-items:center;justify-content:space-between;gap:14px}
.pwa-copy,.eitaa-copy{display:flex;align-items:center;gap:12px;flex:1;min-width:0}
.pwa-icon,.eitaa-icon-box{width:44px;height:44px;flex:0 0 44px;border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:22px}
.pwa-icon{background:rgba(16,173,154,.1)}
.pwa-icon img{width:24px;height:24px}
.eitaa-icon-box{background:rgba(42,142,63,.1)}
.eitaa-icon-box img{width:28px;height:28px}
.pwa-copy h2,.eitaa-copy h2{font-size:15px;font-weight:800;margin:0 0 3px;color:#1f2937}
.pwa-copy p,.eitaa-copy p{font-size:12px;color:#6b7280;margin:0;line-height:1.6}
.pwa-btn,.eitaa-btn,.eitaa-joined-btn{flex:0 0 auto;padding:10px 16px;border-radius:99px;font-family:inherit;font-weight:800;font-size:12px;border:none;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:5px;transition:transform .2s}
.pwa-btn{background:linear-gradient(135deg,#10ad9a,#0d8d7f);color:#fff}
.eitaa-btn{background:linear-gradient(135deg,#2a8e3f,#237a35);color:#fff}
.eitaa-joined-btn{background:rgba(52,199,89,.1);color:#198c41;border:1px solid rgba(52,199,89,.25)}
.pwa-btn:hover,.eitaa-btn:hover{transform:translateY(-1px)}

/* Daily note */
.note-card .note-heading{display:flex;align-items:center;gap:8px;margin-bottom:12px}
.note-card .note-heading h2{font-size:16px;font-weight:800;margin:0;color:#1f2937}
.note-content{font-size:14px;line-height:2;color:#374151}
.note-content img{max-width:100%;border-radius:12px;margin-top:10px}
.note-empty{text-align:center;color:#9ca3af;padding:10px;font-size:13px}

/* PWA modal */
.pwa-modal{position:fixed;inset:0;z-index:9999;display:none;align-items:center;justify-content:center}
.pwa-modal:not([hidden]){display:flex}
.pwa-modal-bg{position:absolute;inset:0;background:rgba(0,0,0,.5)}
.pwa-modal-box{position:relative;background:#fff;border-radius:20px;padding:26px;max-width:400px;width:calc(100% - 32px)}
.pwa-modal-box h2{font-size:17px;font-weight:800;margin:0 0 10px;color:#1f2937}
.pwa-modal-box p{font-size:14px;line-height:1.8;color:#6b7280;margin:0 0 18px}
.pwa-modal-close{position:absolute;top:10px;left:10px;width:30px;height:30px;border-radius:50%;border:none;background:#f3f4f6;font-size:18px;cursor:pointer;color:#6b7280}
.pwa-modal-ok{width:100%;padding:12px;border-radius:99px;border:none;background:linear-gradient(135deg,#10ad9a,#0d8d7f);color:#fff;font-family:inherit;font-weight:800;font-size:14px;cursor:pointer}

/* Empty state */
.empty-state{text-align:center;padding:30px 20px;color:#9ca3af}
.empty-state .icon{font-size:36px;margin-bottom:10px}
.empty-state .text{font-size:14px;line-height:1.8}

@media(max-width:640px){
    .home-main{width:calc(100% - 16px);margin-top:12px}
    .hero{padding:20px 16px;border-radius:18px}
    .hero-title{font-size:18px}
    .hero-progress{padding:15px 14px}
    .progress-percent{font-size:30px}
    .progress-track{height:9px}
    .progress-bottom{font-size:10px}
    .progress-stat strong{font-size:12px}
    .hero-cta{padding:15px 18px;border-radius:16px}
    .hero-cta-text{font-size:26px}
    .hero-cta-arrow{width:38px;height:38px;flex-basis:38px;font-size:18px}
    .glass-card{padding:16px;border-radius:16px}
    .pwa-row,.eitaa-row{flex-direction:column;align-items:stretch;gap:10px}
    .pwa-btn,.eitaa-btn,.eitaa-joined-btn{text-align:center;justify-content:center}
    .lesson-card{padding:12px;gap:10px}
    .lesson-title{font-size:13px}
    .module-head{padding:13px 14px}
    .module-body{padding:0}
    .module.open .module-body{max-height:234px}
}
/* ===== Requested home-page visual refinements ===== */
.home-page .hero-cta {
    box-shadow: 0 9px 24px -10px rgba(249,115,22,.24), 0 3px 9px rgba(0,0,0,.04);
}
.home-page .hero-cta:hover {
    box-shadow: 0 12px 28px -8px rgba(249,115,22,.32), 0 4px 10px rgba(0,0,0,.05);
}

/* ===== Requested PWA + Eitaa refinements ===== */
.home-page #pwaInstallCard .pwa-btn {
    font-size:1.4rem !important;
    line-height:1 !important;
}
.home-page #eitaaJoinCard {
    position:relative !important;
    display:block !important;
    width:100% !important;
    box-sizing:border-box !important;
    padding:26px 24px 24px !important;
    margin-top:14px !important;
    border-radius:28px !important;
    background:linear-gradient(118deg, rgba(142,231,238,.72) 0%, rgba(187,238,242,.48) 42%, rgba(255,255,255,.84) 100%) !important;
    border:1.5px solid rgba(255,255,255,.82) !important;
    box-shadow:0 18px 46px -24px rgba(48,167,178,.34), inset 0 1px 0 rgba(255,255,255,.82) !important;
    overflow:hidden !important;
}
.home-page #eitaaJoinCard .eitaa-row {
    display:flex !important;
    flex-direction:column !important;
    align-items:stretch !important;
    gap:22px !important;
}
.home-page #eitaaJoinCard .eitaa-copy {
    position:relative !important;
    display:block !important;
    min-height:74px !important;
    text-align:center !important;
    padding:0 74px 0 8px !important;
}
.home-page #eitaaJoinCard .eitaa-icon-box {
    position:absolute !important;
    top:0 !important;
    right:0 !important;
    width:66px !important;
    height:66px !important;
    min-width:66px !important;
    min-height:66px !important;
    border-radius:20px !important;
    display:flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:linear-gradient(145deg, rgba(255,255,255,.64), rgba(255,255,255,.28)) !important;
    border:1px solid rgba(255,255,255,.75) !important;
    box-shadow:0 10px 24px rgba(33,104,107,.12) !important;
}
.home-page #eitaaJoinCard .eitaa-icon-box img {
    width:50px !important;
    height:50px !important;
}
.home-page #eitaaJoinCard .eitaa-copy-text {
    min-width:0 !important;
}
.home-page #eitaaJoinCard h2 {
    margin:0 0 11px !important;
    color:#a65307 !important;
    font-size:24px !important;
    font-weight:900 !important;
    line-height:1.5 !important;
}
.home-page #eitaaJoinCard p {
    margin:0 auto !important;
    max-width:760px !important;
    color:#303b42 !important;
    font-size:17px !important;
    line-height:1.95 !important;
    font-weight:500 !important;
}
.home-page #eitaaJoinCard .eitaa-actions {
    width:100% !important;
    display:grid !important;
    grid-template-columns:minmax(0,1fr) minmax(0,1fr) !important;
    gap:14px !important;
    align-items:stretch !important;
    flex:none !important;
}
.home-page #eitaaJoinCard .eitaa-btn,
.home-page #eitaaJoinCard .eitaa-joined-btn {
    width:100% !important;
    min-width:0 !important;
    min-height:64px !important;
    height:64px !important;
    padding:12px 18px !important;
    justify-content:center !important;
    font-size:17px !important;
    font-weight:900 !important;
    border-radius:999px !important;
    box-sizing:border-box !important;
    line-height:1.2 !important;
}
.home-page #eitaaJoinCard .eitaa-btn {
    background:linear-gradient(135deg,#ff8a08,#f47b00) !important;
    border:1px solid rgba(255,143,17,.42) !important;
    color:#fff !important;
    box-shadow:0 12px 26px rgba(244,123,0,.24) !important;
}
.home-page #eitaaJoinCard .eitaa-btn:hover {
    box-shadow:0 15px 29px rgba(244,123,0,.30) !important;
}
.home-page #eitaaJoinCard .eitaa-joined-btn {
    background:rgba(255,255,255,.66) !important;
    border:1.5px solid rgba(22,149,111,.34) !important;
    color:#15966f !important;
    box-shadow:0 10px 24px rgba(30,121,100,.08) !important;
}
.home-page #eitaaJoinCard .eitaa-joined-btn span {
    font-size:1.1em !important;
    color:#15966f !important;
}
/* Overall progress fill: same visual treatment as profile, without changing other home progress elements. */
.home-page .progress-fill{position:relative;overflow:hidden;background:linear-gradient(90deg,#10ad9a 0%,#47c8b6 50%,#73d8ca 100%) !important;box-shadow:0 0 18px rgba(16,173,154,.28);width:var(--progress-target);animation:homeProgressGrow 1.45s cubic-bezier(.22,1,.36,1) both}
.home-page .progress-fill::after{content:'';position:absolute;inset:0;width:45%;background:linear-gradient(90deg,transparent,rgba(255,255,255,.55),transparent);transform:translateX(-130%);animation:homeProgressShimmer 2.7s ease-in-out infinite}
@keyframes homeProgressGrow{from{width:0}to{width:var(--progress-target)}}
@keyframes homeProgressShimmer{0%{transform:translateX(280%);opacity:0}18%{opacity:.8}70%{opacity:.8}100%{transform:translateX(-130%);opacity:0}}
.home-page .progress-percent{animation:homeProgressPercentBreath 2.8s ease-in-out infinite;}
@keyframes homeProgressPercentBreath{0%,100%{text-shadow:0 0 1px rgba(255,255,255,.25),0 0 7px rgba(255,255,255,.10);}50%{text-shadow:0 0 3px rgba(255,255,255,.80),0 0 18px rgba(255,255,255,.28);}}
@media (prefers-reduced-motion:reduce){.home-page .progress-fill,.home-page .progress-fill::after,.home-page .progress-percent{animation:none!important}}

@media(max-width:640px){
    .home-page #pwaInstallCard .pwa-btn { font-size:1.4rem !important; }
    .home-page #eitaaJoinCard { padding:18px 16px !important; }
    .home-page #eitaaJoinCard .eitaa-row { flex-direction:column !important; align-items:stretch !important; gap:16px !important; }
    .home-page #eitaaJoinCard .eitaa-copy { position:static !important; display:flex !important; flex-direction:row !important; align-items:center !important; gap:12px !important; min-height:56px !important; padding:0 !important; text-align:right !important; }
    .home-page #eitaaJoinCard .eitaa-icon-box { position:static !important; transform:none !important; flex:0 0 56px !important; width:56px !important; height:56px !important; min-width:56px !important; min-height:56px !important; }
    .home-page #eitaaJoinCard .eitaa-icon-box img { width:44px !important; height:44px !important; }
    .home-page #eitaaJoinCard .eitaa-copy-text { min-width:0 !important; flex:1 1 auto !important; }
    .home-page #eitaaJoinCard h2 { font-size:20px !important; margin:0 0 5px !important; text-align:right !important; }
    .home-page #eitaaJoinCard p { font-size:13px !important; line-height:1.85 !important; text-align:right !important; }
    .home-page #eitaaJoinCard .eitaa-actions { gap:9px !important; }
    .home-page #eitaaJoinCard .eitaa-btn,
    .home-page #eitaaJoinCard .eitaa-joined-btn { min-height:58px !important; height:58px !important; font-size:16px !important; padding-inline:8px !important; }
}
</style>
</head>
<body class="user-page home-page">
<div class="bg-mesh"><div class="blob blob-1"></div><div class="blob blob-2"></div><div class="blob blob-3"></div></div>
<div class="dev-banner">در حال توسعه — نسخه آزمایشی</div>
<?php require __DIR__ . '/includes/page_loader.php'; ?>
<div class="site-shell">
<?php require __DIR__ . '/includes/site_header.php'; ?>
<main class="home-main">

<!-- ===== Hero ===== -->
<section class="hero">
    <h1 class="hero-title">همقدم با هم، در جهت احیای واجبِ فراموش‌شده</h1>
    <p class="hero-subtitle"><?= $currentSession ? 'ادامه مسیر: ' . e((string)$currentSession['title']) : 'مسیر مطالعه را شروع کن' ?></p>

    <?php if ($sessionSystem && $totalSessions > 0): ?>
    <div class="hero-progress">
        <div class="progress-top">
            <div class="progress-caption">
                <p class="label">پیشرفت کلی مسیر</p>
                <p class="title"><?php if ($overallPercent >= 100): ?>خداقوت! شما تمامی جلسات رو با موفقیت گذروندید... :)<?php elseif ($completedSessions > 0): ?>آفرین، مسیرت در حال پیشرفته<?php else: ?>مسیرت را شروع کن و قدم‌به‌قدم جلو برو<?php endif; ?></p>
            </div>
            <div class="progress-percent"><?= toFaDigits((string)$overallPercent) ?>٪</div>
        </div>
        <div class="progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?= (int)$overallPercent ?>">
            <div class="progress-fill" style="--progress-target:<?= max(0,min(100,$overallPercent)) ?>%"></div>
        </div>
        <div class="progress-bottom">
            <span class="progress-stat">تکمیل‌شده <strong><?= toFaDigits((string)$completedSessions) ?></strong></span>
            <span class="progress-stat">کل جلسات <strong><?= toFaDigits((string)$totalSessions) ?></strong></span>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($currentSession): ?>
    <a class="hero-cta" href="study.php?session_id=<?= (int)$currentSession['id'] ?>">
        <div class="hero-cta-text">
            <?= $completedSessions > 0 ? 'ادامه مطالعه' : 'شروع مطالعه' ?>
            <small><?= e((string)$currentSession['title']) ?></small>
        </div>
        <span class="hero-cta-arrow" aria-hidden="true">
            <svg viewBox="0 0 32 32" focusable="false">
                <path d="M26 16H7M14 9l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </span>
    </a>
    <?php else: ?>
    <a class="hero-cta" href="sessions.php">
        <div class="hero-cta-text">مشاهده مسیر مطالعه<small>فهرست جلسات</small></div>
        <span class="hero-cta-arrow" aria-hidden="true">
            <svg viewBox="0 0 32 32" focusable="false">
                <path d="M26 16H7M14 9l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </span>
    </a>
    <?php endif; ?>
</section>

<!-- ===== PWA Install ===== -->
<section class="glass-card pwa-card" id="pwaInstallCard" hidden aria-live="polite">
    <div class="pwa-row">
        <div class="pwa-copy">
            <div class="pwa-icon" aria-hidden="true">📱</div>
            <div>
                <h2>نصب برنامه</h2>
                <p id="pwaInstallHint">برای دسترسی سریع‌تر به انجام مطالعه روزانه، دکمه زیر را بزنید</p>
            </div>
        </div>
        <button type="button" class="pwa-btn" id="pwaInstallBtn">نصب</button>
    </div>
</section>

<!-- ===== Eitaa ===== -->
<section class="glass-card eitaa-card" id="eitaaJoinCard" data-user-id="<?= (int)$userId ?>">
    <div class="eitaa-row">
        <div class="eitaa-copy">
            <div class="eitaa-icon-box" aria-hidden="true">
                <img src="assets/images/eitaa-icon.png" alt="">
            </div>
            <div class="eitaa-copy-text">
                <h2>عضویت در پیشروان بصیرت</h2>
                <p>برای مشاهده اطلاع‌رسانی‌ها و برنامه‌های گروه در پیام‌رسان ایتا، دکمه عضویت را بزنید 👇</p>
            </div>
        </div>
        <div class="eitaa-actions">
            <a class="eitaa-btn" href="<?= e($eitaaJoinUrl) ?>" target="_blank" rel="noopener">عضویت</a>
            <button type="button" class="eitaa-joined-btn" id="eitaaJoinedBtn"><span>✓</span> عضو شدم</button>
        </div>
    </div>
</section>

<!-- ===== PWA iOS Modal ===== -->
<div class="pwa-modal" id="pwaIosModal" hidden>
    <div class="pwa-modal-bg" data-pwa-close></div>
    <div class="pwa-modal-box">
        <button type="button" class="pwa-modal-close" aria-label="بستن" data-pwa-close>×</button>
        <h2>افزودن به صفحه اصلی</h2>
        <p>در iPhone / iPad، از منوی اشتراک‌گذاری، گزینه Add to Home Screen را انتخاب کنید.</p>
        <button type="button" class="pwa-modal-ok" data-pwa-close>متوجه شدم</button>
    </div>
</div>

<!-- ===== Course / Chapters ===== -->
<?php if ($sessionSystem && $chapters): ?>
<section class="course-card">
    <?php
    $firstUnfinished = null;
    foreach ($chapters as $ch) {
        if ($ch['completed_count'] < $ch['total_count']) { $firstUnfinished = $ch; break; }
    }
    ?>
    <?php $visibleChapterNumber = 0; ?>
    <?php foreach ($chapters as $ch): ?>
        <?php if (empty($ch['sessions'])) continue; ?>
        <?php $visibleChapterNumber++; ?>
        <?php
        $isOpen = ($firstUnfinished && (int)$ch['id'] === (int)$firstUnfinished['id'])
               || ($ch['completed_count'] < $ch['total_count'] && !$firstUnfinished);
        $percentClass = $ch['percent'] === 100 ? '' : ($ch['percent'] > 0 ? 'partial' : 'zero');
        $dasharray = 2 * M_PI * 18;
        $dashoffset = $dasharray * (1 - $ch['percent'] / 100);
        ?>
    <div class="module <?= $isOpen ? 'open' : '' ?>" data-module>
        <button type="button" class="module-head" data-module-toggle>
            <div class="module-head-left">
                <span class="module-icon">📚</span>
                <div>
                    <div class="module-title">فصل <?= (int)$visibleChapterNumber ?>: <?= e((string)$ch['title']) ?></div>
                    <div class="module-meta"><?= toFaDigits((string)$ch['completed_count']) ?> از <?= toFaDigits((string)$ch['total_count']) ?> جلسه</div>
                </div>
            </div>
            <div class="module-head-right">
                <div class="module-percent">
                    <svg width="42" height="42" viewBox="0 0 42 42">
                        <circle class="mp-bg" cx="21" cy="21" r="18"/>
                        <circle class="mp-fg <?= $percentClass ?>" cx="21" cy="21" r="18" stroke-dasharray="<?= $dasharray ?>" stroke-dashoffset="<?= $dashoffset ?>"/>
                    </svg>
                    <span class="mp-text"><?= toFaDigits((string)$ch['percent']) ?>٪</span>
                </div>
                <span class="module-chevron">⌄</span>
            </div>
        </button>
        <div class="module-body">
            <?php foreach ($ch['sessions'] as $s):
                $sid = (int)$s['id'];
                $completed = $s['is_completed'];
                $accessible = $s['is_accessible'];
                $isCurrent = $currentSession && (int)$currentSession['id'] === $sid;
                $cardClass = $completed ? '' : ($isCurrent ? 'current' : ($accessible ? '' : 'locked'));
                $statusClass = $completed ? 'completed' : ($accessible ? 'available' : 'locked');
                $badgeClass = $completed ? 'done' : ($isCurrent ? 'current' : ($accessible ? '' : 'locked'));
                $badgeText = $completed ? 'تکمیل شده' : ($isCurrent ? 'در حال مطالعه' : ($accessible ? 'در دسترس' : 'قفل'));
                $statusIcon = $completed ? '✓' : ($accessible ? '📖' : '🔒');
            ?>
            <a class="lesson-card <?= $cardClass ?>" href="<?= $accessible ? 'study.php?session_id=' . $sid : '#' ?>" <?= $accessible ? '' : 'aria-disabled="true"' ?>>
                <div class="lesson-status <?= $statusClass ?>">
                    <?= $statusIcon ?>
                    <span class="seq"><?= toFaDigits((string)$s['sequence_no']) ?></span>
                </div>
                <div class="lesson-body">
                    <div class="lesson-title"><?= e((string)$s['title']) ?></div>
                    <div class="lesson-meta">
                        <?php if ($completed): ?>
                        <span class="time">✓ قبول شده</span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if ($badgeText): ?>
                <span class="lesson-badge <?= $badgeClass ?>"><?= e($badgeText) ?></span>
                <?php endif; ?>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endforeach; ?>
</section>
<?php elseif ($sessionSystem): ?>
<section class="glass-card">
    <div class="empty-state">
        <div class="icon">📖</div>
        <div class="text">هنوز جلسه‌ای منتشر نشده است.<br><a href="sessions.php" style="color:#10ad9a;font-weight:700;text-decoration:none">مشاهده مسیر</a></div>
    </div>
</section>
<?php endif; ?>

<!-- ===== Daily Note ===== -->
<section class="glass-card note-card">
    <div class="note-heading"><span>💡</span><h2><?= e($todayNote['title'] ?? 'نکته امروز') ?></h2></div>
    <?php if ($todayNote): ?>
        <div class="note-content rich-display"><?= $todayNote['content'] ?></div>
        <?php if (!empty($todayNote['image_path'])): ?>
            <img src="<?= e($todayNote['image_path']) ?>" alt="تصویر نکته امروز" style="display:block;max-width:100%;border-radius:12px;margin-top:10px">
        <?php endif; ?>
    <?php else: ?>
        <div class="note-empty">هنوز نکته‌ای برای امروز ثبت نشده است.</div>
    <?php endif; ?>
</section>

</main>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
</div>
<script>
// Module accordion — one open chapter at a time + scrollable lesson list
(function(){
    var modules = Array.prototype.slice.call(document.querySelectorAll('[data-module]'));
    var MAX_HEIGHT = 234;

    function setOpen(module, open, animate){
        var body = module.querySelector('.module-body');
        var btn = module.querySelector('[data-module-toggle]');
        if(!body) return;
        if(!animate){ body.style.transition='none'; }

        module.classList.toggle('open', open);
        if(btn) btn.setAttribute('aria-expanded', open ? 'true' : 'false');

        if(open){
            body.style.maxHeight = Math.min(body.scrollHeight, MAX_HEIGHT) + 'px';
            body.style.overflowY = body.scrollHeight > MAX_HEIGHT ? 'auto' : 'hidden';
        } else {
            body.style.maxHeight = '0px';
            body.style.overflowY = 'hidden';
            if(body.scrollTop) body.scrollTop = 0;
        }
        if(!animate){ window.requestAnimationFrame(function(){ body.style.transition=''; }); }
    }

    function closeOthers(except){
        modules.forEach(function(other){
            if(other !== except && other.classList.contains('open')) setOpen(other, false, true);
        });
    }

    modules.forEach(function(module){
        var btn = module.querySelector('[data-module-toggle]');
        if(!btn) return;
        btn.setAttribute('aria-expanded', module.classList.contains('open') ? 'true' : 'false');
        setOpen(module, module.classList.contains('open'), false);
        btn.addEventListener('click', function(){
            var shouldOpen = !module.classList.contains('open');
            if(shouldOpen) closeOthers(module);
            setOpen(module, shouldOpen, true);
        });
    });

    window.addEventListener('resize', function(){
        modules.forEach(function(module){
            if(!module.classList.contains('open')) return;
            var body = module.querySelector('.module-body');
            if(body) body.style.maxHeight = Math.min(body.scrollHeight, MAX_HEIGHT) + 'px';
        });
    });
})();
</script>
<script src="assets/js/app.js?v=20261001-pwa-v2" defer></script>
</body>
</html>
