-- ================================================================
-- مدیر می‌تواند برای هر کاربر دسترسی مستقیم تا یک جلسه مشخص بدهد.
-- این مجوز فقط «دسترسی» را تغییر می‌دهد و به‌هیچ‌وجه به معنی تکمیل جلسه نیست.
-- ================================================================

CREATE TABLE IF NOT EXISTS user_session_access (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    max_session_id BIGINT UNSIGNED NOT NULL,
    granted_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_user_session_access_user (user_id),
    KEY idx_user_session_access_session (max_session_id),
    KEY idx_user_session_access_granted_by (granted_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
