<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

require_admin('../login.php');
$user = getUser($pdo);
$message = '';
$error = '';

if (!ensureSiteSettingsTable($pdo)) {
    $error = '❌ جدول تنظیمات سایت قابل ایجاد یا دسترسی نیست. فایل site_settings_migration.sql را روی دیتابیس اجرا کنید و مجدداً وارد شوید.';
}

$defaults = [
    'invite_qr_image' => 'assets/images/invite-qrcode-test.png',
    'invite_copy_url' => 'https://test.ir',
    'invite_share_url' => 'https://test.ir',
    'invite_sms_url' => 'sms:?&body=سلام، شما را به پیشروان بصیرت دعوت می‌کنم: https://test.ir',
    'home_eitaa_join_url' => 'https://eitaa.com/',
    'charter_title' => 'مرامنامه',
    'charter_lead' => 'هدف از این گروه یارگیری جهت خدمت به حضرت صاحب الزمان(عج) توسط احیای دو واجب فراموش شده امر به معروف و نهی از منکر در میان مردم مبعوث شده(مذهبی ها) است.',
    'charter_section_title' => 'چگونگی کار',
    'charter_section_text' => 'آگاهی در مورد این فریضتین از نگاه قرآن و روایات و نظر امامان انقلاب اسلامی و تعریف میدان های مختلف عملیاتی و نیز مطالعه روزانه میباشد.',
    'charter_slogan' => '✊ می‌خواهیم در کنارهم، اهلِ دعوت به امر به معروف و نهی از منکر بشویم.',
];

if (!ensureSiteMediaTable($pdo)) {
    $error = $error ?: '❌ پایگاه ذخیره تصویر رمزینه در دیتابیس قابل ایجاد یا دسترسی نیست.';
}

$settings = getSiteSettings($pdo, $defaults);
$qrPreviewSrc = '../' . ltrim($settings['invite_qr_image'], '/');
if (getSiteMedia($pdo, 'invite_qr')) {
    $qrPreviewSrc = '../site_media.php?key=invite_qr';
}

function isHttpUrl(string $value): bool {
    return filter_var($value, FILTER_VALIDATE_URL) !== false && preg_match('/^https?:\/\//i', $value) === 1;
}

function saveSettingOrThrow(PDO $pdo, string $key, string $value): void {
    if (!setSiteSetting($pdo, $key, $value)) {
        throw new RuntimeException('ذخیره یکی از تنظیمات انجام نشد.');
    }
}

$selectedNoteDateIso = jalaliDateToIsoOrNull((string)($_POST['note_date'] ?? $_GET['note_date'] ?? '')) ?? date('Y-m-d');
$noteStmt = $pdo->prepare('SELECT * FROM daily_notes WHERE note_date = ? LIMIT 1');
$noteStmt->execute([$selectedNoteDateIso]);
$selectedNote = $noteStmt->fetch() ?: null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        $error = '❌ درخواست نامعتبر است. صفحه را تازه کنید و دوباره تلاش کنید.';
    } elseif (isset($_POST['save_note'])) {
        $noteDateInput = trim((string)($_POST['note_date'] ?? ''));
        $noteDate = jalaliDateToIsoOrNull($noteDateInput) ?? date('Y-m-d');
        $noteTitle = trim((string)($_POST['note_title'] ?? 'نکته امروز'));
        $noteTextRaw = (string)($_POST['note_content'] ?? '');
        $noteText = sanitizeStudyHtml($noteTextRaw);
        $selectedNoteDateIso = $noteDate;
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $noteDate) || $noteTitle === '' || $noteText === '') {
            $error = '❌ تاریخ یا متن نکته امروز نامعتبر است.';
        } else {
            try {
                $imagePath = null;
                if (isset($_FILES['note_image']) && $_FILES['note_image']['error'] !== UPLOAD_ERR_NO_FILE) {
                    if ($_FILES['note_image']['error'] !== UPLOAD_ERR_OK) {
                        throw new RuntimeException('خطا در آپلود تصویر نکته.');
                    }
                    if ((int)$_FILES['note_image']['size'] > 3 * 1024 * 1024) {
                        throw new RuntimeException('حجم تصویر نکته باید حداکثر ۳ مگابایت باشد.');
                    }
                    $tmp = (string)$_FILES['note_image']['tmp_name'];
                    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);
                    $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
                    if (!isset($allowed[$mime])) {
                        throw new RuntimeException('فرمت تصویر نکته باید JPG، PNG یا WEBP باشد.');
                    }
                    $dir = __DIR__ . '/../assets/uploads/notes';
                    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
                        throw new RuntimeException('پوشه ذخیره تصویر نکته قابل ایجاد نیست.');
                    }
                    $filename = bin2hex(random_bytes(12)) . '.' . $allowed[$mime];
                    $target = $dir . '/' . $filename;
                    if (!move_uploaded_file($tmp, $target)) {
                        throw new RuntimeException('ذخیره تصویر نکته انجام نشد.');
                    }
                    $imagePath = 'assets/uploads/notes/' . $filename;
                }

                $existingStmt = $pdo->prepare('SELECT id, image_path FROM daily_notes WHERE note_date = ? LIMIT 1');
                $existingStmt->execute([$noteDate]);
                $existing = $existingStmt->fetch();
                if ($existing) {
                    if ($imagePath === null) $imagePath = $existing['image_path'];
                    $stmt = $pdo->prepare('UPDATE daily_notes SET title = ?, content = ?, image_path = ?, updated_at = NOW() WHERE id = ?');
                    $stmt->execute([$noteTitle, $noteText, $imagePath, (int)$existing['id']]);
                } else {
                    $stmt = $pdo->prepare('INSERT INTO daily_notes (note_date, title, content, image_path, updated_at) VALUES (?, ?, ?, ?, NOW())');
                    $stmt->execute([$noteDate, $noteTitle, $noteText, $imagePath]);
                }
                $message = '✅ نکته آن روز با موفقیت ذخیره شد.';
            } catch (Throwable $e) {
                error_log('Daily note save in database.php failed: ' . $e->getMessage());
                $error = '❌ ذخیره نکته انجام نشد: ' . $e->getMessage();
            }
        }
    } elseif (isset($_POST['save_settings'])) {
        $copyUrl = trim((string)($_POST['invite_copy_url'] ?? ''));
        $shareUrl = trim((string)($_POST['invite_share_url'] ?? ''));
        $smsUrl = trim((string)($_POST['invite_sms_url'] ?? ''));
        $eitaaUrl = trim((string)($_POST['home_eitaa_join_url'] ?? ''));
        $charterTitle = trim((string)($_POST['charter_title'] ?? ''));
        $charterLead = trim((string)($_POST['charter_lead'] ?? ''));
        $charterSectionTitle = trim((string)($_POST['charter_section_title'] ?? ''));
        $charterSectionText = trim((string)($_POST['charter_section_text'] ?? ''));
        $charterSlogan = trim((string)($_POST['charter_slogan'] ?? ''));

        if (!isHttpUrl($copyUrl)) {
            $error = '❌ نشانی قابل کپی باید یک URL معتبر با http:// یا https:// باشد.';
        } elseif (!isHttpUrl($shareUrl)) {
            $error = '❌ نشانی اشتراک‌گذاری باید یک URL معتبر با http:// یا https:// باشد.';
        } elseif (!preg_match('/^(https?:\/\/|sms:)/i', $smsUrl)) {
            $error = '❌ نشانی ارسال پیامک باید با http://، https:// یا sms: شروع شود.';
        } elseif (!isHttpUrl($eitaaUrl)) {
            $error = '❌ نشانی عضویت ایتا باید یک URL معتبر با http:// یا https:// باشد.';
        } elseif ($charterTitle === '' || $charterLead === '' || $charterSectionTitle === '' || $charterSectionText === '' || $charterSlogan === '') {
            $error = '❌ همه متن‌های مرامنامه باید تکمیل شوند.';
        } else {
            try {
                $newQrMedia = null;
                if (isset($_FILES['invite_qr_image']) && $_FILES['invite_qr_image']['error'] !== UPLOAD_ERR_NO_FILE) {
                    if ($_FILES['invite_qr_image']['error'] !== UPLOAD_ERR_OK) {
                        throw new RuntimeException('خطا در آپلود تصویر رمزینه.');
                    }
                    if ((int)$_FILES['invite_qr_image']['size'] > 3 * 1024 * 1024) {
                        throw new RuntimeException('حجم تصویر رمزینه باید حداکثر ۳ مگابایت باشد.');
                    }
                    $tmp = (string)$_FILES['invite_qr_image']['tmp_name'];
                    $imageInfo = @getimagesize($tmp);
                    if ($imageInfo === false || empty($imageInfo['mime'])) {
                        throw new RuntimeException('فایل انتخاب‌شده یک تصویر معتبر نیست.');
                    }
                    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);
                    $allowed = ['image/jpeg', 'image/png', 'image/webp'];
                    if (!in_array($mime, $allowed, true)) {
                        throw new RuntimeException('فرمت تصویر باید JPG، PNG یا WEBP باشد.');
                    }
                    $binary = @file_get_contents($tmp);
                    if ($binary === false || $binary === '') {
                        throw new RuntimeException('خواندن تصویر رمزینه انجام نشد.');
                    }
                    $newQrMedia = [
                        'mime' => $mime,
                        'name' => basename((string)($_FILES['invite_qr_image']['name'] ?? 'invite-qr')),
                        'data' => $binary,
                    ];
                }

                $pdo->beginTransaction();
                saveSettingOrThrow($pdo, 'invite_copy_url', $copyUrl);
                saveSettingOrThrow($pdo, 'invite_share_url', $shareUrl);
                saveSettingOrThrow($pdo, 'invite_sms_url', $smsUrl);
                saveSettingOrThrow($pdo, 'home_eitaa_join_url', $eitaaUrl);
                saveSettingOrThrow($pdo, 'charter_title', $charterTitle);
                saveSettingOrThrow($pdo, 'charter_lead', $charterLead);
                saveSettingOrThrow($pdo, 'charter_section_title', $charterSectionTitle);
                saveSettingOrThrow($pdo, 'charter_section_text', $charterSectionText);
                saveSettingOrThrow($pdo, 'charter_slogan', $charterSlogan);
                if ($newQrMedia !== null && !setSiteMedia($pdo, 'invite_qr', $newQrMedia['mime'], $newQrMedia['data'], $newQrMedia['name'])) {
                    throw new RuntimeException('ذخیره تصویر رمزینه در پایگاه داده انجام نشد.');
                }
                $pdo->commit();

                if ($newQrMedia !== null) {
                    $qrPreviewSrc = '../site_media.php?key=invite_qr';
                }

                $settings['invite_copy_url'] = $copyUrl;
                $settings['invite_share_url'] = $shareUrl;
                $settings['invite_sms_url'] = $smsUrl;
                $settings['home_eitaa_join_url'] = $eitaaUrl;
                $settings['charter_title'] = $charterTitle;
                $settings['charter_lead'] = $charterLead;
                $settings['charter_section_title'] = $charterSectionTitle;
                $settings['charter_section_text'] = $charterSectionText;
                $settings['charter_slogan'] = $charterSlogan;
                $message = '✅ تنظیمات سایت با موفقیت ذخیره شد.';
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                error_log('Site settings save failed: ' . $e->getMessage());
                $error = '❌ ذخیره تنظیمات انجام نشد: ' . $e->getMessage();
            }
        }
    }
}

$noteStmt = $pdo->prepare('SELECT * FROM daily_notes WHERE note_date = ? LIMIT 1');
$noteStmt->execute([$selectedNoteDateIso]);
$selectedNote = $noteStmt->fetch() ?: null;
?>
<!DOCTYPE html>
<html lang="fa" data-theme="light" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پایگاه داده | مدیریت</title>
    <link rel="stylesheet" href="../assets/css/style.css?v=20261001-database3">
    <style>
        body{min-height:100vh;display:flex;justify-content:center;align-items:flex-start;font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display","SF Pro Text","Segoe UI",Roboto,Helvetica,Arial,sans-serif;padding:24px 16px}
        .admin-container{max-width:980px;width:100%}
        .auth-card{width:100%}
        .admin-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;padding-bottom:16px;border-bottom:1px solid var(--divider);gap:12px;flex-wrap:wrap}
        .admin-header h1{font-size:24px;font-weight:800;color:var(--text-primary);margin:0 0 5px}
        .admin-header p{margin:0;color:var(--text-secondary);font-size:13px;line-height:1.8}
        .back-link{color:#007aff;text-decoration:none;font-weight:700;font-size:14px}
        .message{padding:12px 16px;border-radius:14px;margin-bottom:18px;font-size:14px;text-align:center;font-weight:600}
        .message.success{background:rgba(52,199,89,.14);color:#177c31;border:1px solid rgba(52,199,89,.22)}
        .message.error{background:rgba(255,59,48,.13);color:#b5221a;border:1px solid rgba(255,59,48,.20)}
        .settings-section{margin-top:18px;padding:22px;border-radius:22px;background:rgba(255,255,255,.25);border:1px solid var(--glass-border)}
        .settings-section h2{margin:0 0 5px;color:var(--text-primary);font-size:18px;font-weight:850}
        .section-desc{margin:0 0 18px;color:var(--text-secondary);font-size:12px;line-height:1.9}
        .fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
        .field{min-width:0}
        .field.full{grid-column:1/-1}
        .field label{display:block;margin:0 0 7px;color:var(--text-primary);font-size:13px;font-weight:750}
        .field input,.field textarea{width:100%;border:1px solid var(--glass-border);background:var(--card-bg);color:var(--text-primary);border-radius:14px;padding:11px 13px;font:inherit;font-size:14px;outline:none;transition:border-color .2s,box-shadow .2s}
        .field textarea{min-height:110px;resize:vertical;line-height:1.9}
        .field input:focus,.field textarea:focus{border-color:#007aff;box-shadow:0 0 0 3px rgba(0,122,255,.12)}
        .hint{margin-top:6px;color:var(--text-secondary);font-size:11px;line-height:1.8}
        .qr-box{display:flex;align-items:center;gap:18px;flex-wrap:wrap;padding:14px;border-radius:18px;background:rgba(255,255,255,.32);border:1px solid rgba(0,0,0,.05)}
        .qr-preview{width:120px;height:160px;object-fit:contain;border-radius:14px;background:#fff;border:1px solid rgba(0,0,0,.07);padding:5px}
        .upload-wrap{flex:1;min-width:240px}
        .upload-wrap input[type=file]{display:block;width:100%;font-size:13px}
        .save-btn{width:100%;padding:14px 18px;border:0;border-radius:99px;margin-top:20px;font:inherit;font-size:17px;font-weight:800;cursor:pointer;color:var(--icon-active);background:var(--glass-bg);backdrop-filter:blur(40px) saturate(180%);-webkit-backdrop-filter:blur(40px) saturate(180%);box-shadow:0 20px 40px -12px var(--glass-shadow),inset 0 2px 3px -1px var(--glass-highlight),inset 0 -2px 4px -1px var(--glass-caustic),inset 0 0 0 1px var(--glass-border);transition:transform .2s}
        .save-btn:hover{transform:scale(1.01)}
        .save-btn:active{transform:scale(.99)}
        .danger-note{margin-top:18px;padding:12px 14px;border-radius:14px;background:rgba(255,149,0,.10);border:1px solid rgba(255,149,0,.16);color:#725015;font-size:12px;line-height:1.9}
        .daily-note-editor{margin-top:16px;}
        .daily-note-editor .rich-editor{width:100%;border:1px solid #cfd5dc;border-radius:12px;background:#fff;overflow:hidden;box-shadow:0 1px 2px rgba(0,0,0,.05);}
        .daily-note-editor .rich-toolbar{display:flex;align-items:center;flex-wrap:wrap;gap:6px;padding:7px 8px;min-height:46px;border-bottom:1px solid #dfe3e8;background:#f7f8fa;direction:rtl;}
        .daily-note-editor .ri-group{display:flex;align-items:center;gap:2px;}
        .daily-note-editor .ri-divider{width:1px;height:26px;background:#d6dbe1;margin:0 3px;}
        .daily-note-editor .ri-btn,.daily-note-editor .ri-select,.daily-note-editor .ri-color{height:34px;border:1px solid transparent;border-radius:5px;background:transparent;color:#2f3439;font:500 13px/1 'Dana',Tahoma,Arial,sans-serif;}
        .daily-note-editor .ri-btn{min-width:34px;padding:0 9px;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;user-select:none;}
        .daily-note-editor .ri-btn:hover{background:#e9edf2;border-color:#d8dde3}
        .daily-note-editor .ri-btn:active,.daily-note-editor .ri-btn.active{background:#dde5ee;border-color:#c8d0d9}
        .daily-note-editor .ri-strong{font-weight:800;font-size:15px}.daily-note-editor .ri-italic{font-style:italic;font-weight:700;font-size:15px}.daily-note-editor .ri-underline{text-decoration:underline;font-weight:700;font-size:15px}
        .daily-note-editor .ri-select{min-width:108px;padding:0 28px 0 8px;border-color:#d4d9df;background:#fff;cursor:pointer;outline:none;}
        .daily-note-editor .ri-color{width:38px;display:inline-flex;align-items:center;justify-content:center;border-color:#d4d9df;background:#fff;position:relative;overflow:hidden;cursor:pointer}.daily-note-editor .ri-color span{font-weight:800;text-decoration:underline;font-size:15px;position:relative;z-index:1;pointer-events:none}.daily-note-editor .ri-color input{position:absolute;inset:0;width:100%;height:100%;padding:0;border:0;opacity:0;cursor:pointer}
        .daily-note-editor .rich-surface{min-height:300px;padding:18px 20px;background:#fff;color:#222;direction:rtl;text-align:right;font:400 16px/2 'Dana',Tahoma,Arial,sans-serif;outline:none;cursor:text;user-select:text;overflow-wrap:anywhere;}
        .daily-note-editor .rich-surface:empty:before{content:attr(data-placeholder);color:#8a939d;pointer-events:none}.daily-note-editor .rich-surface p{margin:0}.daily-note-editor .rich-surface h2,.daily-note-editor .rich-surface h3,.daily-note-editor .rich-surface h4{margin:1em 0 .55em;line-height:1.55}.daily-note-editor .rich-surface blockquote{margin:1em 0;padding:10px 15px;border-right:3px solid #9aa5b1;background:#f5f6f8;border-radius:4px}.daily-note-editor .rich-surface ul,.daily-note-editor .rich-surface ol{padding-right:28px}.daily-note-editor .rich-surface a{color:#075fb8;text-decoration:underline}.daily-note-editor .rich-surface hr{border:0;border-top:1px solid #d7dce1;margin:20px 0}.daily-note-editor .rich-surface table{border-collapse:collapse;width:100%;margin:16px 0}.daily-note-editor .rich-surface th,.daily-note-editor .rich-surface td{border:1px solid #cbd1d7;padding:7px}
        .note-image-preview{display:block;width:min(100%,320px);aspect-ratio:1/1;object-fit:cover;border-radius:18px;margin:16px auto 0;border:1px solid var(--glass-border);box-shadow:0 16px 40px rgba(0,0,0,.10)}
        @media(max-width:700px){.daily-note-editor .rich-toolbar{flex-wrap:nowrap;overflow-x:auto;justify-content:flex-start;padding:6px}.daily-note-editor .ri-btn,.daily-note-editor .ri-select,.daily-note-editor .ri-color{height:32px}.daily-note-editor .ri-select{min-width:96px}.daily-note-editor .rich-surface{min-height:280px;padding:15px 13px;font-size:15px}}
        @media(max-width:700px){body{padding:12px 9px}.settings-section{padding:18px 14px;border-radius:19px}.fields{grid-template-columns:1fr}.field.full{grid-column:auto}.admin-header h1{font-size:21px}.qr-preview{width:100px;height:135px}.upload-wrap{min-width:100%}}
    </style>
</head>
<body class="admin-page-body">
    <?php require __DIR__ . '/../includes/page_loader.php'; ?>
    <div class="bg-mesh"><div class="blob blob-1"></div><div class="blob blob-2"></div><div class="blob blob-3"></div></div>
    <div class="admin-container">
        <div class="auth-card">
            <div class="admin-header">
                <div>
                    <h1>🗄️ پایگاه داده</h1>
                    <p>تنظیمات محتوایی سایت را از یک جا مدیریت کنید.</p>
                </div>
                <a href="dashboard.php" class="back-link">← بازگشت به داشبورد</a>
            </div>

            <?php if ($message): ?><div class="message success"><?= e($message) ?></div><?php endif; ?>
            <?php if ($error): ?><div class="message error"><?= e($error) ?></div><?php endif; ?>

            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

                <section class="settings-section">
                    <h2>دعوت از دوستان</h2>
                    <p class="section-desc">تصویر رمزینه و نشانی‌هایی که در این صفحه استفاده می‌شوند.</p>
                    <div class="qr-box">
                        <img src="<?= e($qrPreviewSrc) ?>" alt="پیش‌نمایش رمزینه فعلی" class="qr-preview">
                        <div class="upload-wrap">
                            <label for="invite_qr_image" style="display:block;margin:0 0 7px;color:var(--text-primary);font-size:13px;font-weight:750">تغییر تصویر «دعوت از طریق رمزینه (QrCode)»</label>
                            <input type="file" id="invite_qr_image" name="invite_qr_image" accept="image/jpeg,image/png,image/webp">
                            <div class="hint">JPG، PNG یا WEBP — حداکثر ۳ مگابایت. تصویر پس از ذخیره مستقیماً داخل پایگاه داده نگهداری می‌شود.</div>
                        </div>
                    </div>
                    <div class="fields" style="margin-top:14px">
                        <div class="field">
                            <label for="invite_copy_url">نشانی‌ای که با دکمه کپی کپی می‌شود</label>
                            <input type="url" id="invite_copy_url" name="invite_copy_url" value="<?= e($settings['invite_copy_url']) ?>" dir="ltr" required>
                        </div>
                        <div class="field">
                            <label for="invite_share_url">نشانی‌ای که در اشتراک‌گذاری ارسال می‌شود</label>
                            <input type="url" id="invite_share_url" name="invite_share_url" value="<?= e($settings['invite_share_url']) ?>" dir="ltr" required>
                        </div>
                        <div class="field full">
                            <label for="invite_sms_url">نشانی / لینک دکمه ارسال پیامک</label>
                            <input type="text" id="invite_sms_url" name="invite_sms_url" value="<?= e($settings['invite_sms_url']) ?>" dir="ltr" required>
                            <div class="hint">می‌تواند لینک کامل یا یک نشانی با قالب <code>sms:</code> باشد.</div>
                        </div>
                    </div>
                </section>

                <section class="settings-section">
                    <h2>صفحه خانه</h2>
                    <p class="section-desc">نشانی دکمه «عضویت» در بخش «عضویت در پیشروان بصیرت».</p>
                    <div class="field">
                        <label for="home_eitaa_join_url">آدرس دکمه عضویت ایتا</label>
                        <input type="url" id="home_eitaa_join_url" name="home_eitaa_join_url" value="<?= e($settings['home_eitaa_join_url']) ?>" dir="ltr" required>
                    </div>
                </section>

                <section class="settings-section">
                    <h2>مرامنامه</h2>
                    <p class="section-desc">هر تیتر و نوشته‌ی قابل مشاهده در صفحه مرامنامه از اینجا قابل ویرایش است.</p>
                    <div class="fields">
                        <div class="field full">
                            <label for="charter_title">عنوان اصلی صفحه</label>
                            <input type="text" id="charter_title" name="charter_title" value="<?= e($settings['charter_title']) ?>" required>
                        </div>
                        <div class="field full">
                            <label for="charter_lead">متن اصلی زیر عنوان</label>
                            <textarea id="charter_lead" name="charter_lead" required><?= e($settings['charter_lead']) ?></textarea>
                        </div>
                        <div class="field">
                            <label for="charter_section_title">عنوان بخش</label>
                            <input type="text" id="charter_section_title" name="charter_section_title" value="<?= e($settings['charter_section_title']) ?>" required>
                        </div>
                        <div class="field full">
                            <label for="charter_section_text">متن بخش</label>
                            <textarea id="charter_section_text" name="charter_section_text" required><?= e($settings['charter_section_text']) ?></textarea>
                        </div>
                        <div class="field full">
                            <label for="charter_slogan">متن پایانی</label>
                            <textarea id="charter_slogan" name="charter_slogan" required><?= e($settings['charter_slogan']) ?></textarea>
                        </div>
                    </div>
                </section>

                <div class="danger-note">تغییرات این صفحه مستقیماً روی محتوای نمایش‌داده‌شده به کاربران اعمال می‌شود. برای حفظ ظاهر فعلی، فقط متن و نشانی‌ها را تغییر دهید.</div>
                <button type="submit" name="save_settings" value="1" class="save-btn">💾 ذخیره همه تنظیمات</button>
            </form>

                <section class="settings-section">
                    <h2>💡 مدیریت نکته روز</h2>
                    <p class="section-desc">نکته، حدیث یا محتوای آموزشی هر تاریخ را از همین‌جا مدیریت کنید. کاربران همان روز این محتوا را در صفحه خانه می‌بینند.</p>
                    <form method="POST" enctype="multipart/form-data" id="dailyNoteForm">
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                        <div class="fields">
                            <div class="field">
                                <label for="note_date">تاریخ</label>
                                <input type="text" id="note_date" name="note_date" value="<?= e(gregorianToJalali($selectedNoteDateIso)) ?>" placeholder="مثلاً ۱۴۰۵/۰۶/۱۱" inputmode="numeric" required>
                            </div>
                            <div class="field">
                                <label for="note_image">تصویر (اختیاری، حداکثر ۳ مگابایت)</label>
                                <input type="file" id="note_image" name="note_image" accept="image/jpeg,image/png,image/webp">
                            </div>
                            <div class="field full">
                                <label for="note_title">عنوان نکته</label>
                                <input type="text" id="note_title" name="note_title" value="<?= e($selectedNote['title'] ?? 'نکته امروز') ?>" placeholder="مثلاً حدیث امروز" required>
                            </div>
                        </div>
                        <div class="daily-note-editor">
                            <label style="display:block;margin:14px 0 7px;color:var(--text-primary);font-size:13px;font-weight:750">متن نکته</label>
                            <div class="rich-editor" id="dailyNoteEditor" data-editor="daily-note">
                                <div class="rich-toolbar" role="toolbar" aria-label="ابزارهای ویرایش نکته روز">
                                    <div class="ri-group">
                                        <button type="button" class="ri-btn" data-cmd="undo" title="واگرد">↶</button>
                                        <button type="button" class="ri-btn" data-cmd="redo" title="بازانجام">↷</button>
                                    </div>
                                    <div class="ri-divider"></div>
                                    <select class="ri-select" data-action="formatBlock" aria-label="نوع متن">
                                        <option value="p">متن عادی</option>
                                        <option value="h2">عنوان ۲</option>
                                        <option value="h3">عنوان ۳</option>
                                        <option value="h4">عنوان ۴</option>
                                        <option value="blockquote">نقل‌قول</option>
                                    </select>
                                    <div class="ri-divider"></div>
                                    <div class="ri-group">
                                        <button type="button" class="ri-btn ri-strong" data-cmd="bold" title="ضخیم">B</button>
                                        <button type="button" class="ri-btn ri-italic" data-cmd="italic" title="کج">I</button>
                                        <button type="button" class="ri-btn ri-underline" data-cmd="underline" title="زیرخط">U</button>
                                        <button type="button" class="ri-btn" data-cmd="strikeThrough" title="خط‌خورده">S̶</button>
                                    </div>
                                    <div class="ri-divider"></div>
                                    <div class="ri-group">
                                        <button type="button" class="ri-btn" data-cmd="justifyRight" title="راست‌چین">≡</button>
                                        <button type="button" class="ri-btn" data-cmd="justifyCenter" title="وسط‌چین">≣</button>
                                        <button type="button" class="ri-btn" data-cmd="justifyLeft" title="چپ‌چین">≡</button>
                                        <button type="button" class="ri-btn" data-cmd="justifyFull" title="تراز کامل">☷</button>
                                    </div>
                                    <div class="ri-divider"></div>
                                    <div class="ri-group">
                                        <button type="button" class="ri-btn" data-cmd="insertUnorderedList" title="فهرست">• فهرست</button>
                                        <button type="button" class="ri-btn" data-cmd="insertOrderedList" title="فهرست شماره‌دار">۱. فهرست</button>
                                    </div>
                                    <div class="ri-divider"></div>
                                    <div class="ri-group">
                                        <button type="button" class="ri-btn" data-cmd="createLink" title="افزودن پیوند">پیوند</button>
                                        <button type="button" class="ri-btn" data-cmd="unlink" title="حذف پیوند">حذف پیوند</button>
                                        <button type="button" class="ri-btn" data-cmd="removeFormat" title="پاک کردن قالب">پاک‌کردن قالب</button>
                                    </div>
                                    <label class="ri-color" title="رنگ متن"><span>A</span><input type="color" data-action="foreColor" value="#222222" aria-label="رنگ متن"></label>
                                </div>
                                <div class="rich-surface" contenteditable="true" spellcheck="true" data-for="note_content" data-placeholder="متن نکته امروز را اینجا وارد کنید..."><?= $selectedNote['content'] ?? '' ?></div>
                                <textarea name="note_content" id="note_content" hidden></textarea>
                            </div>
                        </div>
                        <button type="submit" name="save_note" value="1" class="save-btn">💾 ذخیره نکته روز</button>
                        <?php if ($selectedNote && !empty($selectedNote['image_path'])): ?>
                            <img src="../<?= e($selectedNote['image_path']) ?>" alt="تصویر نکته" class="note-image-preview">
                        <?php endif; ?>
                    </form>
                </section>

            </div>
    </div>
    <script>
    (function(){
      'use strict';
      var editor=document.getElementById('dailyNoteEditor');
      if(!editor) return;
      var surface=editor.querySelector('.rich-surface');
      var target=document.getElementById('note_content');
      if(!surface||!target) return;
      var savedRange=null;
      function saveSelection(){var sel=window.getSelection();if(!sel||!sel.rangeCount||!sel.anchorNode)return;if(surface.contains(sel.anchorNode))savedRange=sel.getRangeAt(0).cloneRange();}
      function restoreSelection(){if(!savedRange)return false;try{var sel=window.getSelection();sel.removeAllRanges();sel.addRange(savedRange);return true;}catch(e){return false;}}
      function caretEnd(){var r=document.createRange();r.selectNodeContents(surface);r.collapse(false);var sel=window.getSelection();sel.removeAllRanges();sel.addRange(r);}
      function sync(){target.value=surface.innerHTML.trim();}
      function state(){['bold','italic','underline','strikeThrough','insertUnorderedList','insertOrderedList','justifyRight','justifyCenter','justifyLeft','justifyFull'].forEach(function(cmd){var b=editor.querySelector('[data-cmd="'+cmd+'"]');if(!b)return;try{b.classList.toggle('active',document.queryCommandState(cmd));}catch(e){}});}
      function command(cmd,value){surface.focus();if(!restoreSelection())caretEnd();try{document.execCommand('styleWithCSS',false,true);}catch(e){}try{if(cmd==='formatBlock'){document.execCommand('formatBlock',false,value||'p');}else if(cmd==='createLink'){var url=window.prompt('آدرس لینک را وارد کنید:','https://');if(url)document.execCommand('createLink',false,url.trim());}else if(cmd==='foreColor'){document.execCommand('foreColor',false,value);}else{document.execCommand(cmd,false,null);}}catch(e){}sync();saveSelection();state();}
      surface.addEventListener('focus',saveSelection);
      surface.addEventListener('click',function(){saveSelection();state();});
      surface.addEventListener('keyup',function(){saveSelection();state();});
      surface.addEventListener('input',sync);
      surface.addEventListener('blur',sync);
      surface.addEventListener('paste',function(){setTimeout(sync,0);});
      editor.querySelectorAll('.ri-btn[data-cmd]').forEach(function(b){b.addEventListener('mousedown',function(e){e.preventDefault();saveSelection();});b.addEventListener('click',function(){command(b.dataset.cmd,b.dataset.value||'');});});
      editor.querySelectorAll('.ri-select').forEach(function(sel){sel.addEventListener('mousedown',saveSelection);sel.addEventListener('change',function(){command(sel.dataset.action,sel.value);});});
      editor.querySelectorAll('.ri-color input').forEach(function(input){input.addEventListener('pointerdown',saveSelection);input.addEventListener('change',function(){command(input.dataset.action,input.value);});});
      document.addEventListener('selectionchange',saveSelection);
      var form=document.getElementById('dailyNoteForm');
      if(form)form.addEventListener('submit',function(){sync();});
      sync();
    }());
    </script>
    <script src="../assets/js/app.js?v=20261001-database4" defer></script>
    <?php require __DIR__ . '/../includes/site_footer.php'; ?>
</body>
</html>
