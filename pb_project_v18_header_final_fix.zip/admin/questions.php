<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_admin('../login.php');

if (!studySessionTablesAvailable($pdo)) {
    http_response_code(503);
    exit('ابتدا فایل sessions_migration.sql را در دیتابیس اجرا کنید.');
}

$message = '';
$error = '';
$sessions = $pdo->query("SELECT s.id, s.title, s.sequence_no, c.title AS chapter_title FROM study_sessions s LEFT JOIN study_chapters c ON c.id = s.chapter_id ORDER BY s.sequence_no ASC, s.id ASC")->fetchAll();
$selectedId = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? 0);
if ($selectedId <= 0 && $sessions) {
    $selectedId = (int)$sessions[0]['id'];
}
$selected = null;
foreach ($sessions as $s) {
    if ((int)$s['id'] === $selectedId) {
        $selected = $s;
        break;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        $error = 'درخواست نامعتبر است.';
    } else {
        try {
            if (!$selected) {
                throw new RuntimeException('جلسه نامعتبر است.');
            }
            $questionId = (int)($_POST['question_id'] ?? 0);
            $questionNumber = (int)($_POST['question_number'] ?? 0);
            $questionText = trim((string)($_POST['question_text'] ?? ''));
            $options = [];
            for ($i = 1; $i <= 4; $i++) {
                $options[$i] = trim((string)($_POST['option_' . $i] ?? ''));
            }
            $correct = (int)($_POST['correct_answer'] ?? 0);

            if (isset($_POST['add_question']) || isset($_POST['edit_question'])) {
                if ($questionText === '' || in_array('', $options, true) || $correct < 1 || $correct > 4 || $questionNumber < 1 || $questionNumber > 5) {
                    throw new RuntimeException('همه اطلاعات سؤال را کامل کنید؛ شماره سؤال باید بین ۱ تا ۵ باشد.');
                }
            }

            if (isset($_POST['add_question'])) {
                $countStmt = $pdo->prepare('SELECT COUNT(*) FROM session_questions WHERE session_id = ?');
                $countStmt->execute([$selectedId]);
                if ((int)$countStmt->fetchColumn() >= 5) throw new RuntimeException('برای هر خودآزمایی دقیقاً ۵ سؤال تعریف می‌شود؛ ابتدا یکی از سؤالات فعلی را ویرایش کنید.');
                $stmt = $pdo->prepare('INSERT INTO session_questions (session_id, question_number, question_text, option_1, option_2, option_3, option_4, correct_answer, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, NOW(), NOW())');
                $stmt->execute([$selectedId, $questionNumber, $questionText, $options[1], $options[2], $options[3], $options[4], $correct]);
                $message = 'سؤال با موفقیت اضافه شد.';
            } elseif (isset($_POST['edit_question'])) {
                if ($questionId <= 0) throw new RuntimeException('شناسه سؤال نامعتبر است.');
                $stmt = $pdo->prepare('UPDATE session_questions SET question_number = ?, question_text = ?, option_1 = ?, option_2 = ?, option_3 = ?, option_4 = ?, correct_answer = ?, updated_at = NOW() WHERE id = ? AND session_id = ?');
                $stmt->execute([$questionNumber, $questionText, $options[1], $options[2], $options[3], $options[4], $correct, $questionId, $selectedId]);
                $message = 'سؤال ویرایش شد؛ نتیجه آزمون‌های قبلی دست‌نخورده می‌ماند.';
            } elseif (isset($_POST['toggle_question'])) {
                $qStmt = $pdo->prepare('SELECT is_active FROM session_questions WHERE id = ? AND session_id = ? LIMIT 1');
                $qStmt->execute([$questionId, $selectedId]);
                $qRow = $qStmt->fetch();
                if (!$qRow) throw new RuntimeException('سؤال پیدا نشد.');
                if ((int)$qRow['is_active'] === 1) {
                    $activeCountStmt = $pdo->prepare('SELECT COUNT(*) FROM session_questions WHERE session_id = ? AND is_active = 1');
                    $activeCountStmt->execute([$selectedId]);
                    if ((int)$activeCountStmt->fetchColumn() <= 5) throw new RuntimeException('برای هر خودآزمایی باید همیشه ۵ سؤال فعال باقی بماند.');
                }
                $stmt = $pdo->prepare('UPDATE session_questions SET is_active = 1 - is_active, updated_at = NOW() WHERE id = ? AND session_id = ?');
                $stmt->execute([$questionId, $selectedId]);
                $message = 'وضعیت سؤال تغییر کرد.';
            } elseif (isset($_POST['delete_question'])) {
                $countStmt = $pdo->prepare('SELECT COUNT(*) FROM session_questions WHERE session_id = ?');
                $countStmt->execute([$selectedId]);
                if ((int)$countStmt->fetchColumn() <= 5) throw new RuntimeException('برای حفظ ساختار ثابت خودآزمایی، وقتی جلسه ۵ سؤال دارد حذف سؤال مجاز نیست؛ سؤال را ویرایش کنید.');
                $stmt = $pdo->prepare('DELETE FROM session_questions WHERE id = ? AND session_id = ?');
                $stmt->execute([$questionId, $selectedId]);
                $message = 'سؤال حذف شد.';
            }
        } catch (Throwable $e) {
            error_log('Session question operation failed: ' . $e->getMessage());
            $error = ($e instanceof PDOException && (int)($e->errorInfo[1] ?? 0) === 1062)
                ? 'شماره این سؤال قبلاً در همین جلسه استفاده شده است.'
                : 'عملیات انجام نشد: ' . $e->getMessage();
        }
    }
}

$questions = [];
if ($selected) {
    $stmt = $pdo->prepare('SELECT * FROM session_questions WHERE session_id = ? ORDER BY question_number ASC, id ASC');
    $stmt->execute([$selectedId]);
    $questions = $stmt->fetchAll();
}
$editId = (int)($_GET['edit'] ?? 0);
$edit = null;
foreach ($questions as $q) {
    if ((int)$q['id'] === $editId) {
        $edit = $q;
        break;
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>مدیریت سؤالات جلسات</title>
<link rel="stylesheet" href="../assets/css/style.css?v=20260921-session4">
<style>
body.admin-q{display:block!important;min-height:100vh!important;padding:20px!important;overflow-x:hidden}.wrap{width:min(1050px,100%);margin:auto}.panel{background:rgba(255,255,255,.68);backdrop-filter:blur(28px);-webkit-backdrop-filter:blur(28px);border:1px solid rgba(255,255,255,.55);border-radius:24px;padding:22px;margin-bottom:18px;box-shadow:0 22px 60px -38px rgba(0,0,0,.3)}.top{display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap}.top h1{margin:0;font-size:24px;color:var(--text-primary)}.link{color:#007aff;text-decoration:none;font-weight:800;font-size:13px}.select{width:100%;padding:11px;border:1px solid rgba(0,0,0,.08);border-radius:13px;background:#fff;font-family:inherit}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.field{display:flex;flex-direction:column;gap:6px}.field.full{grid-column:1/-1}.field label{font-size:13px;font-weight:800}.field input,.field textarea,.field select{width:100%;padding:10px 12px;border:1px solid rgba(0,0,0,.08);border-radius:12px;font-family:inherit;background:#fff}.field textarea{min-height:90px;resize:vertical}.btn{border:none;border-radius:999px;padding:10px 17px;font-family:inherit;font-weight:800;cursor:pointer}.primary{background:linear-gradient(135deg,#10ad9a,#0d8d7f);color:#fff}.secondary{background:#fff;color:var(--text-primary);border:1px solid rgba(0,0,0,.07)}.danger{background:rgba(255,59,48,.1);color:#b42318;border:1px solid rgba(255,59,48,.12)}.msg{padding:12px;border-radius:14px;margin-bottom:14px;text-align:center;font-size:13px}.ok{background:rgba(52,199,89,.12);color:#198c41}.err{background:rgba(255,59,48,.1);color:#b42318}.qcard{padding:16px;border:1px solid rgba(0,0,0,.06);border-radius:18px;background:rgba(255,255,255,.7);margin-bottom:12px}.qhead{display:flex;justify-content:flex-start;gap:10px;align-items:flex-start}.qnum{width:40px;height:40px;border-radius:13px;background:rgba(16,173,154,.1);color:#108e7f;display:flex;align-items:center;justify-content:center;font-weight:900;flex:0 0 40px}.qmain{flex:1}.qtext{font-weight:800;line-height:1.9;font-size:15px}.opts{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:11px}.opt{padding:9px;border-radius:12px;background:#fff;border:1px solid rgba(0,0,0,.05);font-size:13px}.opt.correct{border-color:rgba(52,199,89,.25);background:rgba(52,199,89,.06)}.qa{display:flex;gap:7px;flex-wrap:wrap;margin-top:11px}.qa form{margin:0}.hint{font-size:12px;color:var(--text-secondary);line-height:1.8}
@media(max-width:700px){body.admin-q{padding:10px!important}.panel{padding:16px;border-radius:20px}.grid{grid-template-columns:1fr}.field.full{grid-column:auto}.opts{grid-template-columns:1fr}.qhead{align-items:flex-start}}
</style>
</head>
<body class="admin-q admin-page-body">
<div class="bg-mesh"><div class="blob blob-1"></div><div class="blob blob-2"></div><div class="blob blob-3"></div></div>
<?php require __DIR__.'/../includes/page_loader.php'; ?>
<div class="wrap">
<div class="top"><h1>📋 مدیریت سؤالات جلسات</h1><a class="link" href="dashboard.php">← داشبورد</a></div>
<?php if($message): ?><div class="msg ok">✅ <?=e($message)?></div><?php endif; ?>
<?php if($error): ?><div class="msg err">❌ <?=e($error)?></div><?php endif; ?>
<?php if(!$selected): ?>
<section class="panel">هنوز جلسه‌ای ساخته نشده است. ابتدا از <a class="link" href="sessions.php">مدیریت جلسات</a> یک جلسه ایجاد کنید.</section>
<?php else: ?>
<section class="panel">
<div style="font-size:13px;font-weight:800;margin-bottom:8px;">انتخاب جلسه</div>
<form method="GET"><select class="select" name="session_id" onchange="this.form.submit()">
<?php foreach($sessions as $s): ?><option value="<?= (int)$s['id'] ?>" <?= ((int)$s['id']===$selectedId?'selected':'') ?>>جلسه <?=e((string)$s['sequence_no'])?> — <?=e((string)$s['chapter_title'])?> — <?=e((string)$s['title'])?></option><?php endforeach; ?>
</select></form>
<div class="hint" style="margin-top:10px;">برای عبور به جلسه بعد، کاربر باید هر ۵ سؤال فعال این جلسه را پاسخ دهد و حداقل ۳ پاسخ درست داشته باشد.</div>
</section>
<section class="panel">
<h2 style="margin:0 0 14px;font-size:18px;"><?= $edit ? '✏️ ویرایش سؤال' : '➕ افزودن سؤال' ?></h2>
<form method="POST"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="session_id" value="<?= (int)$selectedId ?>"><?php if($edit): ?><input type="hidden" name="question_id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>
<div class="grid"><div class="field"><label>شماره سؤال</label><input type="number" min="1" max="5" name="question_number" value="<?= (int)($edit['question_number'] ?? (count($questions)+1)) ?>" required></div><div class="field"><label>گزینه صحیح</label><select name="correct_answer"><?php for($i=1;$i<=4;$i++): ?><option value="<?= $i ?>" <?= ((int)($edit['correct_answer'] ?? 1)===$i?'selected':'') ?>><?=e(optionLabel($i))?></option><?php endfor; ?></select></div><div class="field full"><label>متن سؤال</label><textarea name="question_text" required><?=e((string)($edit['question_text']??''))?></textarea></div><?php for($i=1;$i<=4;$i++): ?><div class="field"><label>گزینه <?=e(optionLabel($i))?></label><input name="option_<?=$i?>" value="<?=e((string)($edit['option_'.$i]??''))?>" required></div><?php endfor; ?></div>
<button class="btn primary" style="margin-top:12px" name="<?= $edit?'edit_question':'add_question' ?>"><?= $edit?'ذخیره سؤال':'افزودن سؤال' ?></button><?php if($edit): ?><a class="btn secondary" style="display:inline-flex;text-decoration:none;margin-top:12px" href="questions.php?session_id=<?= (int)$selectedId ?>">انصراف</a><?php endif; ?>
</form></section>
<section class="panel"><h2 style="margin:0 0 6px;font-size:18px;">سؤالات «<?=e($selected['title'])?>»</h2><div class="hint">هر خودآزمایی دقیقاً از ۵ سؤال فعال همین جلسه استفاده می‌کند.</div>
<?php if(!$questions): ?><div class="hint" style="margin-top:16px">هنوز سؤالی ثبت نشده است.</div><?php else: foreach($questions as $q): ?>
<div class="qcard"><div class="qhead"><div class="qnum"><?=e((string)$q['question_number'])?></div><div class="qmain"><div class="qtext"><?=e((string)$q['question_text'])?></div><div class="opts"><?php for($i=1;$i<=4;$i++): ?><div class="opt <?=((int)$q['correct_answer']===$i?'correct':'')?>"><strong><?=e(optionLabel($i))?>)</strong> <?=e((string)$q['option_'.$i])?></div><?php endfor; ?></div><div class="qa"><a class="btn secondary" style="text-decoration:none" href="questions.php?session_id=<?= (int)$selectedId ?>&edit=<?= (int)$q['id'] ?>">ویرایش</a></div></div></div></div>
<?php endforeach; endif; ?></section>
<?php endif; ?></div>
<script src="../assets/js/app.js?v=20260921-session4" defer></script>
<?php require __DIR__.'/../includes/site_footer.php'; ?>
</body></html>
