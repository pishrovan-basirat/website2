<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

require_admin('../login.php');

$tab = in_array(($_GET['tab'] ?? 'overview'), ['overview', 'progress', 'members'], true)
    ? (string)$_GET['tab']
    : 'overview';

$perPage = 20;
$today = date('Y-m-d');
$currentPage = max(1, (int)($_GET['page'] ?? 1));
$membersPage = max(1, (int)($_GET['members_page'] ?? 1));
$progressPage = max(1, (int)($_GET['progress_page'] ?? 1));

$memberSearch = trim((string)($_GET['member_search'] ?? ''));
$memberLocation = trim((string)($_GET['member_location'] ?? ''));
$memberSkill = (int)($_GET['member_skill'] ?? 0);
$memberActivity = (string)($_GET['member_activity'] ?? 'all');

$progressSearch = trim((string)($_GET['progress_search'] ?? ''));

function formatIranJalaliDateTime(?string $dateTime): string {
    if (!$dateTime) return '—';
    try {
        $iran = new DateTimeImmutable($dateTime, new DateTimeZone('Asia/Tehran'));
        return formatJalaliDate($iran->format('Y-m-d')) . ' - ' . $iran->format('H:i');
    } catch (Throwable $e) {
        return $dateTime;
    }
}


function toFaDigits(string $value): string {
    return strtr($value, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']);
}

function buildReportsUrl(array $overrides = []): string {
    $base = [
        'tab' => $_GET['tab'] ?? 'overview',
        'member_search' => $_GET['member_search'] ?? '',
        'member_location' => $_GET['member_location'] ?? '',
        'member_skill' => $_GET['member_skill'] ?? '',
        'member_activity' => $_GET['member_activity'] ?? 'all',
        'progress_search' => $_GET['progress_search'] ?? '',
    ];
    foreach ($overrides as $key => $value) {
        $base[$key] = $value;
    }
    $base = array_filter($base, static fn($value) => $value !== '' && $value !== null);
    return 'reports.php?' . http_build_query($base);
}

$skillOptions = [];
try {
    $skillOptions = $pdo->query('SELECT id, name FROM skill_options WHERE is_active = 1 ORDER BY sort_order, id')->fetchAll();
} catch (Throwable $e) {}

// آمار کلی
$stats = ['users' => 0, 'studied' => 0, 'attempts' => 0, 'passed' => 0, 'incomplete' => 0];
try {
    $stats['users'] = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'user'")->fetchColumn();

    if (studySessionTablesAvailable($pdo)) {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM session_exam_attempts WHERE DATE(attempted_at) = ?');
        $stmt->execute([$today]);
        $stats['attempts'] = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM session_exam_attempts WHERE DATE(attempted_at) = ? AND passed = 1');
        $stmt->execute([$today]);
        $stats['passed'] = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare('SELECT COUNT(DISTINCT user_id) FROM user_session_progress WHERE DATE(viewed_at) = ? OR DATE(completed_at) = ?');
        $stmt->execute([$today, $today]);
        $stats['studied'] = (int)$stmt->fetchColumn();
    }
    $stats['incomplete'] = max(0, $stats['users'] - $stats['studied']);
} catch (Throwable $e) {}

// فهرست اعضا
$memberTotal = 0;
$memberPages = 1;
$members = [];
try {
    $memberWhere = ["u.role = 'user'"];
    $memberParams = [];

    if ($memberSearch !== '') {
        $memberWhere[] = '(u.full_name LIKE ? OR u.phone LIKE ?)';
        $like = '%' . $memberSearch . '%';
        $memberParams[] = $like;
        $memberParams[] = $like;
    }
    if ($memberLocation !== '') {
        $memberWhere[] = 'u.location LIKE ?';
        $memberParams[] = '%' . $memberLocation . '%';
    }
    if ($memberSkill > 0) {
        $memberWhere[] = 'EXISTS (SELECT 1 FROM user_skills usf WHERE usf.user_id = u.id AND usf.skill_option_id = ?)';
        $memberParams[] = $memberSkill;
    }
    if ($memberActivity === 'completed' && studySessionTablesAvailable($pdo)) {
        $memberWhere[] = 'EXISTS (SELECT 1 FROM session_exam_attempts a2 WHERE a2.user_id = u.id AND DATE(a2.attempted_at) = ? AND a2.passed = 1)';
        $memberParams[] = $today;
    } elseif ($memberActivity === 'incomplete' && studySessionTablesAvailable($pdo)) {
        $memberWhere[] = 'NOT EXISTS (SELECT 1 FROM session_exam_attempts a2 WHERE a2.user_id = u.id AND DATE(a2.attempted_at) = ? AND a2.passed = 1)';
        $memberParams[] = $today;
    }

    $whereSql = implode(' AND ', $memberWhere);
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users u WHERE $whereSql");
    $stmt->execute($memberParams);
    $memberTotal = (int)$stmt->fetchColumn();
    $memberPages = max(1, (int)ceil($memberTotal / $perPage));
    $membersPage = min($membersPage, $memberPages);
    $memberOffset = ($membersPage - 1) * $perPage;

    $memberSql = "
        SELECT
            u.id, u.full_name, u.phone, u.skill, u.location, u.role, u.created_at,
            COALESCE(
                GROUP_CONCAT(
                    DISTINCT CASE
                        WHEN so.name = 'سایر' AND us.custom_text IS NOT NULL AND us.custom_text <> ''
                            THEN CONCAT(so.name, ': ', us.custom_text)
                        ELSE so.name
                    END
                    ORDER BY so.sort_order, so.id SEPARATOR '، '
                ),
                NULLIF(u.skill, ''),
                'ثبت نشده'
            ) AS skills_label,
            CASE WHEN studySessionAvailable AND EXISTS (
                SELECT 1 FROM session_exam_attempts a3 WHERE a3.user_id = u.id AND DATE(a3.attempted_at) = ? AND a3.passed = 1
            ) THEN 1 ELSE 0 END AS display_completed
        FROM users u
        LEFT JOIN user_skills us ON us.user_id = u.id
        LEFT JOIN skill_options so ON so.id = us.skill_option_id
        CROSS JOIN (SELECT ? AS studySessionAvailable) params
        WHERE $whereSql
        GROUP BY u.id, u.full_name, u.phone, u.skill, u.location, u.role, u.created_at, params.studySessionAvailable
        ORDER BY u.id DESC
        LIMIT $perPage OFFSET $memberOffset
    ";
    $stmt = $pdo->prepare($memberSql);
    $sessionAvail = studySessionTablesAvailable($pdo) ? 1 : 0;
    $stmt->execute(array_merge([$today, $sessionAvail], $memberParams));
    $members = $stmt->fetchAll();
} catch (Throwable $e) {
    error_log('Member report load failed: ' . $e->getMessage());
}

// گزارش پیشرفت کاربران — یک ردیف برای هر کاربر
$progressTotal = 0;
$progressPages = 1;
$progressRows = [];
if (studySessionTablesAvailable($pdo)) {
    try {
        $where = ["u.role = 'user'"];
        $params = [];
        if ($progressSearch !== '') {
            $where[] = '(u.full_name LIKE ? OR u.phone LIKE ?)';
            $like = '%' . $progressSearch . '%';
            $params[] = $like;
            $params[] = $like;
        }
        $whereSql = implode(' AND ', $where);

        $st = $pdo->prepare("SELECT COUNT(*) FROM users u WHERE $whereSql");
        $st->execute($params);
        $progressTotal = (int)$st->fetchColumn();
        $progressPages = max(1, (int)ceil($progressTotal / $perPage));
        $progressPage = min($progressPage, $progressPages);
        $progressOffset = ($progressPage - 1) * $perPage;

        $st = $pdo->prepare("
            SELECT
                u.id, u.full_name, u.phone, u.location,
                (
                    active_total.total + COALESCE(inactive_seen.cnt, 0)
                ) AS total_sessions,
                COALESCE(completed.cnt, 0) AS completed_count,
                ROUND(
                    COALESCE(completed.cnt, 0) / NULLIF(active_total.total + COALESCE(inactive_seen.cnt, 0), 0) * 100
                ) AS percent,
                last_completed.session_title AS last_session_title,
                last_completed.chapter_title AS last_chapter_title,
                last_completed.sequence_no AS last_sequence_no,
                last_completed.completed_at AS last_completed_at,
                last_activity.last_activity_at AS last_activity_at
            FROM users u
            CROSS JOIN (
                SELECT COUNT(*) AS total
                FROM study_sessions s
                JOIN study_chapters c ON c.id = s.chapter_id
                WHERE s.is_active = 1 AND c.is_active = 1
            ) active_total
            LEFT JOIN (
                SELECT usp.user_id, COUNT(*) AS cnt
                FROM user_session_progress usp
                JOIN study_sessions s ON s.id = usp.session_id
                JOIN study_chapters c ON c.id = s.chapter_id
                WHERE usp.is_completed = 1
                  AND (s.is_active = 0 OR c.is_active = 0)
                GROUP BY usp.user_id
            ) inactive_seen ON inactive_seen.user_id = u.id
            LEFT JOIN (
                SELECT usp.user_id, COUNT(*) AS cnt
                FROM user_session_progress usp
                WHERE usp.is_completed = 1
                GROUP BY usp.user_id
            ) completed ON completed.user_id = u.id
            LEFT JOIN (
                SELECT
                    usp.user_id,
                    s.title AS session_title,
                    c.title AS chapter_title,
                    c.sort_order AS chapter_sort_order,
                    s.sequence_no AS sequence_no,
                    s.id AS session_id,
                    usp.completed_at
                FROM user_session_progress usp
                JOIN study_sessions s ON s.id = usp.session_id
                JOIN study_chapters c ON c.id = s.chapter_id
                WHERE usp.is_completed = 1
                  AND NOT EXISTS (
                    SELECT 1
                    FROM user_session_progress usp2
                    JOIN study_sessions s2 ON s2.id = usp2.session_id
                    JOIN study_chapters c2 ON c2.id = s2.chapter_id
                    WHERE usp2.user_id = usp.user_id
                      AND usp2.is_completed = 1
                      AND (
                        usp2.completed_at > usp.completed_at
                        OR (usp2.completed_at = usp.completed_at AND usp2.id > usp.id)
                      )
                  )
            ) last_completed ON last_completed.user_id = u.id
            LEFT JOIN (
                SELECT user_id, MAX(updated_at) AS last_activity_at
                FROM user_session_progress
                GROUP BY user_id
            ) last_activity ON last_activity.user_id = u.id
            WHERE $whereSql
            ORDER BY COALESCE(completed.cnt, 0) DESC, u.full_name ASC
            LIMIT $perPage OFFSET $progressOffset
        ");
        $st->execute($params);
        $progressRows = $st->fetchAll();
    } catch (Throwable $e) {
        error_log('Progress report load failed: ' . $e->getMessage());
    }
}

function renderPagination(int $current, int $totalPages, string $param, array $extra = []): void {
    if ($totalPages <= 1) return;
    $start = max(1, $current - 2);
    $end = min($totalPages, $current + 2);
    echo '<div class="pagination">';
    if ($current > 1) {
        $query = array_merge($extra, [$param => $current - 1]);
        echo '<a href="reports.php?' . e(http_build_query($query)) . '" class="page-link">قبلی</a>';
    }
    if ($start > 1) {
        $query = array_merge($extra, [$param => 1]);
        echo '<a href="reports.php?' . e(http_build_query($query)) . '" class="page-link">۱</a>';
        if ($start > 2) echo '<span class="page-dots">…</span>';
    }
    for ($p = $start; $p <= $end; $p++) {
        $query = array_merge($extra, [$param => $p]);
        $active = $p === $current ? ' active' : '';
        echo '<a href="reports.php?' . e(http_build_query($query)) . '" class="page-link' . $active . '">' . e((string)$p) . '</a>';
    }
    if ($end < $totalPages) {
        if ($end < $totalPages - 1) echo '<span class="page-dots">…</span>';
        $query = array_merge($extra, [$param => $totalPages]);
        echo '<a href="reports.php?' . e(http_build_query($query)) . '" class="page-link">' . e((string)$totalPages) . '</a>';
    }
    if ($current < $totalPages) {
        $query = array_merge($extra, [$param => $current + 1]);
        echo '<a href="reports.php?' . e(http_build_query($query)) . '" class="page-link">بعدی</a>';
    }
    echo '</div>';
}

$memberPaginationExtra = [
    'tab' => 'members', 'member_search' => $memberSearch, 'member_location' => $memberLocation,
    'member_skill' => $memberSkill ?: '', 'member_activity' => $memberActivity,
];
$progressPaginationExtra = ['tab' => 'progress', 'progress_search' => $progressSearch];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>گزارشات مدیریت</title>
<link rel="stylesheet" href="../assets/css/style.css?v=20260924-reports4">
<style>
.admin-page-body{min-height:100vh;background:transparent;display:flex;flex-direction:column!important;align-items:center;justify-content:flex-start!important;padding:24px 14px 0!important;overflow-x:hidden}
.admin-page-main{width:min(1120px,100%);margin:0 auto;flex:1 0 auto}
.admin-panel{padding:28px}
.admin-header{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;margin-bottom:18px}
.admin-title{font-size:26px;font-weight:900;color:var(--text-primary)}
.admin-actions{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
.admin-link{display:inline-flex;align-items:center;justify-content:center;padding:10px 16px;border-radius:999px;text-decoration:none;color:var(--text-primary);background:rgba(255,255,255,.45);border:1px solid var(--glass-border);font-weight:700}
.tabs{display:flex;gap:8px;flex-wrap:wrap;background:rgba(255,255,255,.22);border:1px solid var(--glass-border);border-radius:18px;padding:7px;margin-bottom:22px}
.tab-link{flex:1 1 160px;min-width:140px;text-align:center;text-decoration:none;color:var(--text-secondary);font-weight:850;padding:11px 14px;border-radius:13px;transition:.2s ease}
.tab-link:hover{background:rgba(255,255,255,.35);color:var(--text-primary)}
.tab-link.active{background:rgba(0,191,165,.16);color:#087f72;box-shadow:inset 0 0 0 1px rgba(0,191,165,.18)}
.section-title{font-size:21px;font-weight:900;color:var(--text-primary);margin:24px 0 14px;border-right:4px solid #00bfa5;padding-right:12px}
.summary-grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px;margin-bottom:24px}
.summary-card{padding:17px;border:1px solid var(--glass-border);border-radius:18px;background:rgba(255,255,255,.26);text-align:center}
.summary-card .icon{font-size:23px;display:block;margin-bottom:5px}.summary-card .label{font-size:12px;color:var(--text-secondary);font-weight:700}.summary-card .value{font-size:25px;font-weight:950;color:var(--text-primary);margin-top:2px}
.filters{display:grid;grid-template-columns:2fr 1fr 1fr 1fr auto;gap:9px;padding:12px;border:1px solid var(--glass-border);border-radius:18px;background:rgba(255,255,255,.18);margin-bottom:13px}
.filters input,.filters select{width:100%;border:1px solid var(--glass-border);border-radius:12px;padding:10px 11px;background:rgba(255,255,255,.58);color:var(--text-primary);font:inherit;outline:none}
.filters button{border:0;border-radius:12px;padding:10px 15px;background:linear-gradient(135deg,#0aa994,#00b9d0);color:#fff;font:inherit;font-weight:850;cursor:pointer}
.filters .reset{display:inline-flex;align-items:center;justify-content:center;padding:10px 14px;border-radius:12px;border:1px solid var(--glass-border);text-decoration:none;color:var(--text-primary);background:rgba(255,255,255,.38);font-weight:800}
.table-wrap{overflow:auto;background:rgba(255,255,255,.3);border:1px solid var(--glass-border);border-radius:20px;padding:10px}
table{width:100%;border-collapse:collapse;min-width:760px}th,td{padding:11px 10px;border-bottom:1px solid var(--divider);text-align:right;vertical-align:top;color:var(--text-primary);font-size:13px}th{font-weight:850;background:rgba(255,255,255,.24)}tbody tr:last-child td{border-bottom:0}
.badge{display:inline-flex;align-items:center;gap:4px;padding:4px 9px;border-radius:999px;font-size:12px;font-weight:850;white-space:nowrap}.badge.success{background:rgba(52,199,89,.15);color:#169447}.badge.fail{background:rgba(255,59,48,.12);color:#d42f27}.badge.warning{background:rgba(245,166,35,.14);color:#9b6700}.badge.neutral{background:rgba(100,100,100,.1);color:#6d6d6d}
.skill-chips{display:flex;flex-wrap:wrap;gap:5px}.skill-chip{display:inline-flex;align-items:center;padding:4px 8px;border-radius:999px;background:rgba(0,191,165,.10);color:#126f66;font-size:11px;font-weight:800}
.empty-state{text-align:center;color:var(--text-secondary);padding:28px}
.notice{padding:12px 14px;border-radius:14px;margin-bottom:15px;background:rgba(52,199,89,.12);color:#166534;font-weight:700}.notice.error{background:rgba(255,59,48,.12);color:#991b1b}
.section-note{font-size:12px;color:var(--text-secondary);margin:-5px 0 12px;line-height:1.9}
.pagination{display:flex;justify-content:center;align-items:center;gap:6px;flex-wrap:wrap;margin:15px 0 2px}.page-link{display:inline-flex;align-items:center;justify-content:center;min-width:34px;height:34px;padding:0 10px;border-radius:10px;text-decoration:none;color:var(--text-primary);background:rgba(255,255,255,.35);border:1px solid var(--glass-border);font-size:12px;font-weight:800}.page-link.active{background:#00ad98;color:#fff;border-color:#00ad98}.page-dots{padding:0 3px;color:var(--text-secondary)}
.progress-bar{width:100px;height:8px;border-radius:99px;background:#e5e7eb;overflow:hidden;display:inline-block;vertical-align:middle}.progress-bar-fill{height:100%;border-radius:99px;background:linear-gradient(90deg,#10b981,#34d399)}
.last-session{font-size:12px;color:var(--text-secondary);line-height:1.8}
.last-session strong{color:var(--text-primary)}
@media(max-width:900px){.summary-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.filters{grid-template-columns:1fr 1fr}.filters .wide{grid-column:1/-1}.filters button,.filters .reset{width:100%}}
@media(max-width:700px){.admin-panel{padding:18px 12px}.admin-title{font-size:22px}.section-title{font-size:19px}.admin-page-body{padding:12px 8px 0!important}.summary-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.summary-card .value{font-size:22px}.tabs{border-radius:15px}.tab-link{flex:1 1 30%;min-width:0;font-size:12px;padding:10px 7px}.members-table,table{min-width:760px}.filters{grid-template-columns:1fr}.filters .wide{grid-column:auto}}
</style>
</head>
<body class="admin-page-body">
<?php require __DIR__ . '/../includes/page_loader.php'; ?>
<div class="bg-mesh"><div class="blob blob-1"></div><div class="blob blob-2"></div><div class="blob blob-3"></div></div>
<main class="admin-page-main">
<div class="auth-card admin-panel">
<div class="admin-header"><div class="admin-title">📊 گزارشات مدیریت</div><div class="admin-actions"><a class="admin-link" href="dashboard.php">← داشبورد</a></div></div>

<div class="tabs">
    <a class="tab-link <?= $tab === 'overview' ? 'active' : '' ?>" href="reports.php?tab=overview">📈 نمای کلی</a>
    <a class="tab-link <?= $tab === 'progress' ? 'active' : '' ?>" href="reports.php?tab=progress">📊 پیشرفت کاربران</a>
    <a class="tab-link <?= $tab === 'members' ? 'active' : '' ?>" href="reports.php?tab=members">👥 اعضا</a>
</div>

<?php if ($tab === 'overview'): ?>
    <div class="summary-grid">
        <div class="summary-card"><span class="icon">👥</span><div class="label">کل کاربران</div><div class="value"><?= toFaDigits((string)$stats['users']) ?></div></div>
        <div class="summary-card"><span class="icon">📖</span><div class="label">فعالیت امروز</div><div class="value"><?= toFaDigits((string)$stats['studied']) ?></div></div>
        <div class="summary-card"><span class="icon">📝</span><div class="label">تلاش آزمون امروز</div><div class="value"><?= toFaDigits((string)$stats['attempts']) ?></div></div>
        <div class="summary-card"><span class="icon">✅</span><div class="label">قبولی امروز</div><div class="value"><?= toFaDigits((string)$stats['passed']) ?></div></div>
        <div class="summary-card"><span class="icon">⏳</span><div class="label">غیرفعال امروز</div><div class="value"><?= toFaDigits((string)$stats['incomplete']) ?></div></div>
    </div>

    <h2 class="section-title">📖 وضعیت مطالعه امروز</h2>
    <div class="section-note">بر اساس وضعیت جلسه و قبولی خودآزمایی.</div>
    <div class="table-wrap">
    <?php
    $studyReports = [];
    $studyTotal = 0;
    $studyPages = 1;
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'user'");
        $stmt->execute();
        $studyTotal = (int)$stmt->fetchColumn();
        $studyPages = max(1, (int)ceil($studyTotal / $perPage));
        $studyPage = min($currentPage, $studyPages);
        $studyOffset = ($studyPage - 1) * $perPage;

        if (studySessionTablesAvailable($pdo)) {
            $stmt = $pdo->prepare("
                SELECT u.id, u.full_name, u.phone, u.skill, u.location,
                       CASE WHEN COALESCE(usp.is_completed, 0) = 1 THEN 1 ELSE 0 END AS display_completed,
                       COALESCE(
                           GROUP_CONCAT(
                               DISTINCT CASE
                                   WHEN so.name = 'سایر' AND us.custom_text IS NOT NULL AND us.custom_text <> ''
                                       THEN CONCAT(so.name, ': ', us.custom_text)
                                   ELSE so.name
                               END
                               ORDER BY so.sort_order, so.id SEPARATOR '، '
                           ),
                           NULLIF(u.skill, ''),
                           'ثبت نشده'
                       ) AS skills_label
                FROM users u
                LEFT JOIN user_session_progress usp ON usp.user_id = u.id AND DATE(usp.updated_at) = ?
                LEFT JOIN user_skills us ON us.user_id = u.id
                LEFT JOIN skill_options so ON so.id = us.skill_option_id
                WHERE u.role = 'user'
                GROUP BY u.id, u.full_name, u.phone, u.skill, u.location, usp.is_completed
                ORDER BY display_completed DESC, u.full_name ASC
                LIMIT $perPage OFFSET $studyOffset
            ");
            $stmt->execute([$today]);
            $studyReports = $stmt->fetchAll();
        } else {
            $stmt = $pdo->prepare("
                SELECT u.id, u.full_name, u.phone, u.skill, u.location, 0 AS display_completed,
                       COALESCE(GROUP_CONCAT(DISTINCT so.name ORDER BY so.sort_order, so.id SEPARATOR '، '), NULLIF(u.skill, ''), 'ثبت نشده') AS skills_label
                FROM users u
                LEFT JOIN user_skills us ON us.user_id = u.id
                LEFT JOIN skill_options so ON so.id = us.skill_option_id
                WHERE u.role = 'user'
                GROUP BY u.id, u.full_name, u.phone, u.skill, u.location
                ORDER BY u.full_name ASC
                LIMIT $perPage OFFSET $studyOffset
            ");
            $stmt->execute();
            $studyReports = $stmt->fetchAll();
        }
    } catch (Throwable $e) {
        error_log('Study report load failed: ' . $e->getMessage());
    }
    ?>
    <?php if ($studyReports): ?>
        <table><thead><tr><th>نام کاربر</th><th>شماره همراه</th><th>توانمندی‌ها</th><th>محدوده سکونت</th><th>وضعیت</th></tr></thead><tbody>
        <?php foreach ($studyReports as $row): ?>
            <tr>
                <td><?= e($row['full_name']) ?></td>
                <td dir="ltr"><?= e($row['phone']) ?></td>
                <td><div class="skill-chips"><?php foreach (array_filter(array_map('trim', explode('،', (string)$row['skills_label']))) as $skill): ?><span class="skill-chip"><?= e($skill) ?></span><?php endforeach; ?></div></td>
                <td><?= e($row['location'] ?: 'ثبت نشده') ?></td>
                <td><?= (int)$row['display_completed'] ? '<span class="badge success">✅ تکمیل‌شده</span>' : '<span class="badge warning">⏳ ناقص</span>' ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody></table>
    <?php else: ?><div class="empty-state">📭 کاربری برای نمایش وجود ندارد.</div><?php endif; ?>
    </div>
    <?php renderPagination($currentPage, $studyPages, 'page', ['tab' => 'overview']); ?>

<?php elseif ($tab === 'progress'): ?>
    <h2 class="section-title">📊 پیشرفت کاربران در مسیر مطالعه</h2>
    <div class="section-note">نمای کلی از پیشرفت هر کاربر — «آخرین جلسه تکمیل‌شده» و «آخرین فعالیت» به‌صورت مستقل نمایش داده می‌شوند. غیرفعال شدن یک جلسه، سابقه تکمیل کاربر را از بین نمی‌برد.</div>
    <form class="filters" method="get">
        <input type="hidden" name="tab" value="progress">
        <input class="wide" type="text" name="progress_search" value="<?= e($progressSearch) ?>" placeholder="جستجو با نام یا شماره همراه">
        <div style="display:flex;gap:7px;grid-column:auto"><button type="submit">اعمال</button><a class="reset" href="reports.php?tab=progress">پاک‌سازی</a></div>
    </form>
    <div class="section-note"><?= toFaDigits((string)$progressTotal) ?> کاربر یافت شد.</div>
    <div class="table-wrap">
    <?php if ($progressRows): ?>
        <table><thead><tr><th>نام کاربر</th><th>شماره همراه</th><th>آخرین فصل و جلسه تکمیل‌شده</th><th>جلسات تکمیل‌شده</th><th>درصد پیشرفت</th><th>آخرین فعالیت</th><th>آخرین تکمیل</th></tr></thead><tbody>
        <?php foreach ($progressRows as $r): ?>
            <tr>
                <td><?= e($r['full_name']) ?></td>
                <td dir="ltr"><?= e($r['phone']) ?></td>
                <td>
                    <?php if ($r['last_session_title']): ?>
                        <div class="last-session">
                            <strong><?= e($r['last_chapter_title'] ?: '—') ?></strong><br>
                            جلسه <?= toFaDigits((string)$r['last_sequence_no']) ?>: <?= e($r['last_session_title']) ?>
                        </div>
                    <?php else: ?>
                        <span class="badge neutral">شروع نکرده</span>
                    <?php endif; ?>
                </td>
                <td><?= toFaDigits((string)((int)$r['completed_count'])) ?> از <?= toFaDigits((string)((int)$r['total_sessions'])) ?></td>
                <td>
                    <?php $pct = (int)($r['percent'] ?? 0); ?>
                    <span class="badge <?= $pct >= 80 ? 'success' : ($pct >= 40 ? 'warning' : 'neutral') ?>"><?= toFaDigits((string)$pct) ?>٪</span>
                    <div class="progress-bar"><div class="progress-bar-fill" style="width:<?= $pct ?>%"></div></div>
                </td>
                <td>
                    <?php if ($r['last_activity_at']): ?>
                        <span class="last-session"><?= e(formatIranJalaliDateTime($r['last_activity_at'])) ?></span>
                    <?php else: ?>
                        <span class="badge neutral">—</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($r['last_completed_at']): ?>
                        <span class="last-session"><?= e(formatIranJalaliDateTime($r['last_completed_at'])) ?></span>
                    <?php else: ?>
                        <span class="badge neutral">—</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody></table>
    <?php else: ?><div class="empty-state">📭 کاربری برای نمایش وجود ندارد.</div><?php endif; ?>
    </div>
    <?php renderPagination($progressPage, $progressPages, 'progress_page', $progressPaginationExtra); ?>

<?php else: ?>
    <h2 class="section-title">👥 اعضای ثبت‌نام‌شده</h2>
    <form class="filters" method="get">
        <input type="hidden" name="tab" value="members">
        <input class="wide" type="text" name="member_search" value="<?= e($memberSearch) ?>" placeholder="جستجو با نام یا شماره همراه">
        <input type="text" name="member_location" value="<?= e($memberLocation) ?>" placeholder="فیلتر محدوده">
        <select name="member_skill"><option value="0">همه توانمندی‌ها</option><?php foreach ($skillOptions as $skill): ?><option value="<?= (int)$skill['id'] ?>" <?= $memberSkill === (int)$skill['id'] ? 'selected' : '' ?>><?= e($skill['name']) ?></option><?php endforeach; ?></select>
        <select name="member_activity"><option value="all" <?= $memberActivity === 'all' ? 'selected' : '' ?>>همه وضعیت‌ها</option><option value="completed" <?= $memberActivity === 'completed' ? 'selected' : '' ?>>قبولی امروز</option><option value="incomplete" <?= $memberActivity === 'incomplete' ? 'selected' : '' ?>>بدون قبولی امروز</option></select>
        <div style="display:flex;gap:7px"><button type="submit">اعمال</button><a class="reset" href="reports.php?tab=members">پاک‌سازی</a></div>
    </form>
    <div class="section-note"><?= toFaDigits((string)$memberTotal) ?> کاربر مطابق فیلتر فعلی پیدا شد.</div>
    <div class="table-wrap">
    <?php if ($members): ?>
        <table class="members-table"><thead><tr><th>شناسه</th><th>نام و نام خانوادگی</th><th>شماره همراه</th><th>توانمندی‌ها</th><th>محدوده</th><th>قبولی امروز</th><th>تاریخ ثبت‌نام</th></tr></thead><tbody>
        <?php foreach ($members as $m): ?>
            <tr>
                <td>#<?= toFaDigits((string)$m['id']) ?></td><td><?= e($m['full_name']) ?></td><td dir="ltr"><?= e($m['phone']) ?></td>
                <td><div class="skill-chips"><?php foreach (array_filter(array_map('trim', explode('،', (string)$m['skills_label']))) as $skill): ?><span class="skill-chip"><?= e($skill) ?></span><?php endforeach; ?></div></td>
                <td><?= e($m['location'] ?: 'ثبت نشده') ?></td>
                <td><?= (int)$m['display_completed'] ? '<span class="badge success">✅ قبول</span>' : '<span class="badge warning">⏳ بدون قبولی</span>' ?></td>
                <td><?= e(formatJalaliDate($m['created_at'] ?? null)) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody></table>
    <?php else: ?><div class="empty-state">📭 کاربری مطابق فیلترها پیدا نشد.</div><?php endif; ?>
    </div>
    <?php renderPagination($membersPage, $memberPages, 'members_page', $memberPaginationExtra); ?>
<?php endif; ?>

</div>
</main>
<script src="../assets/js/app.js?v=20260924-reports4" defer></script>
<?php require __DIR__ . '/../includes/site_footer.php'; ?>
</body>
</html>
