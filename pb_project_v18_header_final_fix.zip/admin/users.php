<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

require_admin('../login.php');
$currentUserId = (int)($_SESSION['user_id'] ?? 0);
$message = '';
$error = '';

function toFaDigitsAdmin(string $value): string {
    return strtr($value, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        $error = '❌ درخواست نامعتبر است. صفحه را تازه کنید و دوباره تلاش کنید.';
    } elseif (isset($_POST['create_user'])) {
        $fullName = trim((string)($_POST['full_name'] ?? ''));
        $phone = trim((string)($_POST['phone'] ?? ''));
        $location = trim((string)($_POST['location'] ?? ''));
        $role = ($_POST['role'] ?? 'user') === 'admin' ? 'admin' : 'user';
        $selectedSkills = isset($_POST['skills']) && is_array($_POST['skills'])
            ? array_values(array_unique(array_filter(array_map('intval', $_POST['skills']), static fn($v) => $v > 0)))
            : [];
        $otherSkillText = trim((string)($_POST['other_skill'] ?? ''));

        if ($fullName === '' || $phone === '' || $location === '') {
            $error = '❌ نام، شماره همراه و محدوده محل سکونت الزامی است.';
        } elseif (!preg_match('/^09[0-9]{9}$/', $phone)) {
            $error = '❌ شماره همراه معتبر نیست.';
        } else {
            try {
                $stmt = $pdo->prepare('SELECT id FROM users WHERE phone = ? LIMIT 1');
                $stmt->execute([$phone]);
                if ($stmt->fetch()) {
                    throw new RuntimeException('این شماره همراه قبلاً ثبت شده است.');
                }

                $skillRows = [];
                if ($selectedSkills) {
                    $ph = implode(',', array_fill(0, count($selectedSkills), '?'));
                    $stmt = $pdo->prepare("SELECT id, name FROM skill_options WHERE id IN ($ph) AND is_active = 1 ORDER BY sort_order, id");
                    $stmt->execute($selectedSkills);
                    $skillRows = $stmt->fetchAll();
                    if (count($skillRows) !== count($selectedSkills)) {
                        throw new RuntimeException('یکی از توانمندی‌های انتخاب‌شده معتبر نیست.');
                    }
                }

                $skillNames = array_map(static fn($row) => (string)$row['name'], $skillRows);
                if (in_array('سایر', $skillNames, true) && $otherSkillText !== '') {
                    $skillNames[] = 'سایر: ' . $otherSkillText;
                }
                $skillLabel = implode('، ', $skillNames);

                $pdo->beginTransaction();
                $stmt = $pdo->prepare('INSERT INTO users (full_name, phone, password_hash, skill, location, role, created_at) VALUES (?, ?, NULL, ?, ?, ?, ?)');
                $stmt->execute([$fullName, $phone, $skillLabel, $location, $role, now()]);
                $newUserId = (int)$pdo->lastInsertId();

                if ($skillRows) {
                    $link = $pdo->prepare('INSERT INTO user_skills (user_id, skill_option_id, custom_text) VALUES (?, ?, ?)');
                    foreach ($skillRows as $row) {
                        $custom = ((string)$row['name'] === 'سایر' && $otherSkillText !== '') ? $otherSkillText : null;
                        $link->execute([$newUserId, (int)$row['id'], $custom]);
                    }
                }
                $pdo->commit();
                $message = '✅ کاربر با موفقیت اضافه شد.';
            } catch (RuntimeException $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $error = '❌ ' . $e->getMessage();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                error_log('Admin user create failed: ' . $e->getMessage());
                $error = '❌ ایجاد کاربر انجام نشد. جزئیات خطا در لاگ سرور ثبت شد.';
            }
        }
    } elseif (isset($_POST['update_session_access'])) {
        $targetId = (int)($_POST['user_id'] ?? 0);
        $maxSessionId = (int)($_POST['max_session_id'] ?? 0);
        if ($targetId <= 0) {
            $error = '❌ شناسه کاربر نامعتبر است.';
        } elseif (!tableExists($pdo, 'user_session_access')) {
            $error = '❌ جدول دسترسی ویژه هنوز در دیتابیس ساخته نشده است. ابتدا فایل user_session_access_migration.sql را اجرا کنید.';
        } else {
            try {
                $stmt = $pdo->prepare('SELECT id, full_name FROM users WHERE id = ? LIMIT 1');
                $stmt->execute([$targetId]);
                $target = $stmt->fetch();
                if (!$target) throw new RuntimeException('کاربر پیدا نشد.');

                if ($maxSessionId === 0) {
                    if (tableExists($pdo, 'user_session_access')) {
                        $stmt = $pdo->prepare('DELETE FROM user_session_access WHERE user_id = ?');
                        $stmt->execute([$targetId]);
                    }
                    $message = '✅ دسترسی ویژه کاربر «' . e((string)$target['full_name']) . '» حذف شد.';
                } else {
                    $activeSessions = getActiveStudySessions($pdo);
                    $validSession = false;
                    foreach ($activeSessions as $item) {
                        if ((int)$item['id'] === $maxSessionId) { $validSession = true; break; }
                    }
                    if (!$validSession) throw new RuntimeException('جلسه انتخاب‌شده فعال یا معتبر نیست.');
                    $stmt = $pdo->prepare('INSERT INTO user_session_access (user_id, max_session_id, granted_by, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW()) ON DUPLICATE KEY UPDATE max_session_id = VALUES(max_session_id), granted_by = VALUES(granted_by), updated_at = NOW()');
                    $stmt->execute([$targetId, $maxSessionId, $currentUserId]);
                    $message = '✅ دسترسی «تا جلسه انتخاب‌شده» برای کاربر «' . e((string)$target['full_name']) . '» ذخیره شد.';
                }
            } catch (RuntimeException $e) {
                $error = '❌ ' . $e->getMessage();
            } catch (Throwable $e) {
                error_log('Admin session access update failed: ' . $e->getMessage());
                $error = '❌ تغییر دسترسی انجام نشد. جزئیات خطا در لاگ سرور ثبت شد.';
            }
        }
    } elseif (isset($_POST['delete_user'])) {
        $targetId = (int)($_POST['user_id'] ?? 0);
        if ($targetId <= 0) {
            $error = '❌ شناسه کاربر نامعتبر است.';
        } elseif ($targetId === $currentUserId) {
            $error = '❌ برای جلوگیری از از دست رفتن دسترسی، نمی‌توانید حساب مدیر فعلی را حذف کنید.';
        } else {
            try {
                $stmt = $pdo->prepare('SELECT id, full_name FROM users WHERE id = ? LIMIT 1');
                $stmt->execute([$targetId]);
                $target = $stmt->fetch();
                if (!$target) {
                    throw new RuntimeException('کاربر پیدا نشد.');
                }
                deleteUserData($pdo, $targetId);
                $message = '✅ کاربر «' . e((string)$target['full_name']) . '» و اطلاعات وابسته حذف شد.';
            } catch (RuntimeException $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $error = '❌ ' . $e->getMessage();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                error_log('Admin user delete failed: ' . $e->getMessage());
                $error = '❌ حذف انجام نشد. ممکن است جدول دیگری به کاربر وابسته باشد.';
            }
        }
    }
}

$skillOptions = $pdo->query('SELECT id, name FROM skill_options WHERE is_active = 1 ORDER BY sort_order, id')->fetchAll();
$users = $pdo->query('SELECT id, full_name, phone, skill, location, role, created_at FROM users ORDER BY id DESC')->fetchAll();
$accessByUser = [];
$accessReady = tableExists($pdo, 'user_session_access');
if ($accessReady) {
    $accessStmt = $pdo->query('SELECT user_id, max_session_id FROM user_session_access');
    foreach ($accessStmt->fetchAll() as $accessRow) $accessByUser[(int)$accessRow['user_id']] = (int)$accessRow['max_session_id'];
}
$accessSessions = studySessionTablesAvailable($pdo) ? getActiveStudySessions($pdo) : [];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت کاربران</title>
    <link rel="stylesheet" href="../assets/css/style.css?v=20260911-users1">
    <style>
        body{min-height:100vh;padding:20px;font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display","Segoe UI",Roboto,Arial,sans-serif;}
        .users-container{width:min(1100px,100%);margin:0 auto;}
        .auth-card{width:100%;}
        .admin-header{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:22px;padding-bottom:15px;border-bottom:1px solid var(--divider)}
        .admin-header h1{margin:0;font-size:24px;color:var(--text-primary)}
        .back-link{color:#007aff;text-decoration:none;font-weight:700;font-size:14px}
        .users-section{background:rgba(255,255,255,.18);border:1px solid var(--glass-border);border-radius:20px;padding:20px;margin-bottom:20px}
        .users-section h2{margin:0 0 8px;color:var(--text-primary);font-size:20px}
        .users-section p{margin:0 0 16px;color:var(--text-secondary);font-size:13px;line-height:1.9}
        .users-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
        .users-form-grid .full{grid-column:1/-1}
        .field label{display:block;margin-bottom:7px;font-weight:800;color:var(--text-primary);font-size:13px}
        .field input,.field select{width:100%;border:1px solid var(--glass-border);border-radius:13px;padding:12px 13px;background:rgba(255,255,255,.58);color:var(--text-primary);font:inherit;outline:none}
        .field input:focus,.field select:focus{border-color:rgba(0,122,255,.45);box-shadow:0 0 0 3px rgba(0,122,255,.1)}
        .skill-list{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
        .skill-list label{display:flex;align-items:center;gap:6px;padding:9px 10px;border:1px solid var(--glass-border);border-radius:11px;background:rgba(255,255,255,.22);font-size:12px;color:var(--text-primary);cursor:pointer}
        .skill-list input{accent-color:#00a88f}
        .submit-user{width:100%;margin-top:16px;border:0;border-radius:999px;padding:13px 18px;background:linear-gradient(135deg,#10ad9a,#00bcd4);color:#fff;font:inherit;font-weight:900;font-size:16px;cursor:pointer}
        .message{padding:12px 15px;border-radius:14px;margin-bottom:16px;text-align:center;font-size:13px;font-weight:700}
        .message.success{background:rgba(52,199,89,.16);color:#167f3d}.message.error{background:rgba(255,59,48,.14);color:#bb2319}
        .users-table-wrap{overflow:auto}
        .access-cell{min-width:290px}
        .access-form{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:7px;align-items:center}
        .access-form select{width:100%;min-width:220px;border:1px solid var(--glass-border);border-radius:10px;padding:9px 10px;background:rgba(255,255,255,.62);color:var(--text-primary);font:inherit;font-size:12px;outline:none}
        .access-save{border:0;border-radius:10px;padding:9px 12px;background:linear-gradient(135deg,#10ad9a,#0d8d7f);color:#fff;font:inherit;font-size:12px;font-weight:900;cursor:pointer;white-space:nowrap}
        .access-current{margin-top:5px;font-size:11px;color:var(--text-secondary)}
    </style>
</head>
<body class="admin-page-body">
<div class="bg-mesh"><div class="blob blob-1"></div><div class="blob blob-2"></div><div class="blob blob-3"></div></div>
<div class="users-container">
    <div class="auth-card">
        <div class="admin-header">
            <h1>👥 مدیریت کاربران</h1>
            <a href="dashboard.php" class="back-link">← بازگشت به داشبورد</a>
        </div>
        <?php if ($message): ?><div class="message success"><?= $message ?></div><?php endif; ?>
        <?php if ($error): ?><div class="message error"><?= e($error) ?></div><?php endif; ?>

        <section class="users-section">
            <h2>➕ افزودن دستی کاربر</h2>
            <p>از این فرم می‌توانید کاربر جدید را بدون نیاز به طی کردن فرم ثبت‌نام عمومی ایجاد کنید.</p>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <div class="users-form-grid">
                    <div class="field"><label>نام و نام خانوادگی</label><input type="text" name="full_name" required></div>
                    <div class="field"><label>شماره همراه</label><input type="tel" name="phone" placeholder="09123456789" pattern="09[0-9]{9}" required></div>
                    <div class="field"><label>محدوده محل سکونت</label><input type="text" name="location" required></div>
                    <div class="field"><label>نقش</label><select name="role"><option value="user">کاربر عادی</option><option value="admin">مدیر</option></select></div>
                    <div class="field full"><label>توانمندی‌ها</label><div class="skill-list">
                        <?php foreach ($skillOptions as $option): ?>
                            <label><input type="checkbox" name="skills[]" value="<?= (int)$option['id'] ?>" data-skill-name="<?= e($option['name']) ?>"> <?= e($option['name']) ?></label>
                        <?php endforeach; ?>
                    </div></div>
                    <div class="field full"><label>توضیح «سایر» (اختیاری)</label><input type="text" name="other_skill" placeholder="در صورت انتخاب سایر"></div>
                </div>
                <button type="submit" name="create_user" class="submit-user">✅ ایجاد کاربر</button>
            </form>
        </section>

        <section class="users-section">
            <h2>🗂 کاربران ثبت‌شده</h2>
            <p>از این قسمت می‌توانید کاربران را بررسی و در صورت نیاز حذف کنید. حساب مدیر فعلی برای جلوگیری از قطع دسترسی قابل حذف نیست.</p>
            <div class="users-table-wrap">
                <table class="users-table">
                    <thead><tr><th>نام</th><th>شماره</th><th>توانمندی</th><th>محدوده</th><th>نقش</th><th>ثبت‌نام</th><th>دسترسی جلسات</th><th>عملیات</th></tr></thead>
                    <tbody>
                    <?php foreach ($users as $row): ?>
                        <tr>
                            <td><?= e($row['full_name']) ?></td>
                            <td dir="ltr"><?= e($row['phone']) ?></td>
                            <td class="muted"><?= e($row['skill'] ?? '') ?></td>
                            <td><?= e($row['location'] ?? '') ?></td>
                            <td><span class="user-role-badge <?= $row['role']==='admin' ? 'user-role-admin' : 'user-role-user' ?>"><?= $row['role']==='admin' ? 'مدیر' : 'کاربر' ?></span></td>
                            <td class="muted"><?= e(formatJalaliDateTime($row['created_at'] ?? null)) ?></td>
                            <td class="access-cell">
                                <?php if (!$accessReady): ?>
                                    <span class="self-delete-note">migration دسترسی اجرا نشده</span>
                                <?php else: ?>
                                    <form method="POST" class="access-form">
                                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                        <input type="hidden" name="user_id" value="<?= (int)$row['id'] ?>">
                                        <select name="max_session_id" aria-label="حداکثر جلسه قابل دسترسی برای <?= e($row['full_name']) ?>">
                                            <option value="0" <?= empty($accessByUser[(int)$row['id']]) ? 'selected' : '' ?>>بدون دسترسی ویژه</option>
                                            <?php foreach ($accessSessions as $accessIndex => $accessSession): ?>
                                                <?php $accessSid=(int)$accessSession['id']; $accessLabel='مسیر ' . toFaDigitsAdmin((string)($accessIndex + 1)) . ' — فصل ' . toFaDigitsAdmin((string)($accessSession['chapter_sort_order'] ?? 1)) . ' / جلسه ' . toFaDigitsAdmin((string)$accessSession['sequence_no']) . ': ' . (string)$accessSession['title']; ?>
                                                <option value="<?= $accessSid ?>" <?= (($accessByUser[(int)$row['id']] ?? 0) === $accessSid) ? 'selected' : '' ?>><?= e($accessLabel) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <button type="submit" name="update_session_access" class="access-save">ذخیره</button>
                                    </form>
                                    <?php if (!empty($accessByUser[(int)$row['id']])): ?>
                                        <?php $grantSid=(int)$accessByUser[(int)$row['id']]; $grantIndex=null; foreach($accessSessions as $gidx=>$gitem){ if((int)$gitem['id']===$grantSid){$grantIndex=$gidx;break;} } ?>
                                        <div class="access-current"><?= $grantIndex !== null ? 'دسترسی فعلی: تا مسیر ' . toFaDigitsAdmin((string)($grantIndex+1)) : 'دسترسی فعلی نیاز به بازبینی دارد' ?></div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ((int)$row['id'] === $currentUserId): ?>
                                    <span class="self-delete-note">حساب جاری</span>
                                <?php else: ?>
                                    <form method="POST" onsubmit="return confirm('آیا از حذف این کاربر و اطلاعات مرتبط او مطمئن هستید؟');">
                                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                        <input type="hidden" name="user_id" value="<?= (int)$row['id'] ?>">
                                        <button type="submit" name="delete_user" class="user-delete-btn">🗑️ حذف</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$users): ?><tr><td colspan="8" style="text-align:center;padding:25px;color:var(--text-secondary)">کاربری ثبت نشده است.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</div>
<script src="../assets/js/app.js?v=20260911-users1" defer></script>
<?php require __DIR__ . '/../includes/site_footer.php'; ?>
</body>
</html>
