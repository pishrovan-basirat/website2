<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

require_admin('../login.php');
$user = getUser($pdo);
$message = '';
$error = '';

if (!studySessionTablesAvailable($pdo)) {
    http_response_code(503);
    exit('ابتدا فایل sessions_migration.sql را در دیتابیس اجرا کنید.');
}

function saveSessionAudio(array $file): string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return '';
    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) throw new RuntimeException('آپلود صوت ناموفق بود.');
    if ((int)($file['size'] ?? 0) > 25 * 1024 * 1024) throw new RuntimeException('حجم فایل صوتی باید حداکثر ۲۵ مگابایت باشد.');
    $tmp = (string)$file['tmp_name'];
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);
    $allowed = [
        'audio/mpeg' => 'mp3', 'audio/mp3' => 'mp3', 'audio/ogg' => 'ogg', 'audio/wav' => 'wav',
        'audio/x-wav' => 'wav', 'audio/mp4' => 'm4a', 'audio/x-m4a' => 'm4a', 'audio/aac' => 'aac',
    ];
    if (!isset($allowed[$mime])) throw new RuntimeException('فرمت صوتی باید MP3، OGG، WAV، M4A یا AAC باشد.');
    $dir = __DIR__ . '/../assets/uploads/sessions';
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) throw new RuntimeException('پوشه ذخیره صوت قابل ایجاد نیست.');
    $name = bin2hex(random_bytes(14)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($tmp, $dir . '/' . $name)) throw new RuntimeException('ذخیره فایل صوتی انجام نشد.');
    return 'assets/uploads/sessions/' . $name;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        $error = 'درخواست نامعتبر است.';
    } else {
        try {
            if (isset($_POST['add_chapter'])) {
                $title = trim((string)($_POST['chapter_title'] ?? ''));
                $desc = trim((string)($_POST['chapter_description'] ?? ''));
                $sort = max(1, (int)($_POST['chapter_sort'] ?? 1));
                if ($title === '') throw new RuntimeException('عنوان فصل را وارد کنید.');
                $stmt = $pdo->prepare('INSERT INTO study_chapters (title, description, sort_order, is_active, created_at, updated_at) VALUES (?, ?, ?, 1, NOW(), NOW())');
                $stmt->execute([$title, $desc !== '' ? $desc : null, $sort]);
                $message = 'فصل با موفقیت ایجاد شد.';
            } elseif (isset($_POST['edit_chapter'])) {
                $id = (int)($_POST['chapter_id'] ?? 0);
                $title = trim((string)($_POST['chapter_title'] ?? ''));
                $desc = trim((string)($_POST['chapter_description'] ?? ''));
                $sort = max(1, (int)($_POST['chapter_sort'] ?? 1));
                if ($id <= 0 || $title === '') throw new RuntimeException('اطلاعات فصل نامعتبر است.');
                $stmt = $pdo->prepare('UPDATE study_chapters SET title = ?, description = ?, sort_order = ?, updated_at = NOW() WHERE id = ?');
                $stmt->execute([$title, $desc !== '' ? $desc : null, $sort, $id]);
                $message = 'تغییرات فصل ذخیره شد.';
            } elseif (isset($_POST['add_session'])) {
                $chapterId = (int)($_POST['chapter_id'] ?? 0);
                $title = trim((string)($_POST['session_title'] ?? ''));
                $summary = trim((string)($_POST['session_summary'] ?? ''));
                $footnote = trim((string)($_POST['session_footnote'] ?? ''));
                $content = sanitizeStudyHtml((string)($_POST['session_content'] ?? ''));
                $sequence = max(1, (int)($_POST['sequence_no'] ?? 0));
                $active = isset($_POST['is_active']) ? 1 : 0;
                if ($sequence <= 0) {
                    // Auto-calculate next sequence within this chapter
                    $seqStmt = $pdo->prepare('SELECT COALESCE(MAX(sequence_no), 0) + 1 FROM study_sessions WHERE chapter_id = ?');
                    $seqStmt->execute([$chapterId]);
                    $sequence = (int)$seqStmt->fetchColumn();
                }
                if ($chapterId <= 0 || $title === '' || $content === '') throw new RuntimeException('فصل، عنوان و متن جلسه الزامی است.');
                $audioPath = '';
                if (!empty($_FILES['audio_file']['name'])) $audioPath = saveSessionAudio($_FILES['audio_file']);
                $stmt = $pdo->prepare('INSERT INTO study_sessions (chapter_id, title, summary, footnote, content, audio_path, sequence_no, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())');
                $stmt->execute([$chapterId, $title, $summary !== '' ? $summary : null, $footnote !== '' ? $footnote : null, $content, $audioPath !== '' ? $audioPath : null, $sequence, $active]);
                $message = 'جلسه با موفقیت ایجاد شد.';
            } elseif (isset($_POST['edit_session'])) {
                $id = (int)($_POST['session_id'] ?? 0);
                $chapterId = (int)($_POST['chapter_id'] ?? 0);
                $title = trim((string)($_POST['session_title'] ?? ''));
                $summary = trim((string)($_POST['session_summary'] ?? ''));
                $footnote = trim((string)($_POST['session_footnote'] ?? ''));
                $content = sanitizeStudyHtml((string)($_POST['session_content'] ?? ''));
                $sequence = max(1, (int)($_POST['sequence_no'] ?? 0));
                $active = isset($_POST['is_active']) ? 1 : 0;
                if ($id <= 0 || $chapterId <= 0 || $title === '' || $content === '') throw new RuntimeException('اطلاعات جلسه نامعتبر است.');
                $oldStmt = $pdo->prepare('SELECT audio_path FROM study_sessions WHERE id = ? LIMIT 1');
                $oldStmt->execute([$id]);
                $old = $oldStmt->fetch();
                if (!$old) throw new RuntimeException('جلسه موردنظر پیدا نشد.');
                $audioPath = (string)($old['audio_path'] ?? '');
                if (!empty($_POST['remove_audio'])) $audioPath = '';
                if (!empty($_FILES['audio_file']['name'])) $audioPath = saveSessionAudio($_FILES['audio_file']);
                $stmt = $pdo->prepare('UPDATE study_sessions SET chapter_id = ?, title = ?, summary = ?, footnote = ?, content = ?, audio_path = ?, sequence_no = ?, is_active = ?, updated_at = NOW() WHERE id = ?');
                $stmt->execute([$chapterId, $title, $summary !== '' ? $summary : null, $footnote !== '' ? $footnote : null, $content, $audioPath !== '' ? $audioPath : null, $sequence, $active, $id]);
                $message = 'جلسه با موفقیت ویرایش شد؛ همه کاربران از این لحظه محتوای جدید را می‌بینند.';
            } elseif (isset($_POST['toggle_session'])) {
                $id = (int)($_POST['session_id'] ?? 0);
                $stmt = $pdo->prepare('UPDATE study_sessions SET is_active = 1 - is_active, updated_at = NOW() WHERE id = ?');
                $stmt->execute([$id]);
                $message = 'وضعیت انتشار جلسه تغییر کرد.';
            } elseif (isset($_POST['archive_session'])) {
                $id = (int)($_POST['session_id'] ?? 0);
                if ($id <= 0) throw new RuntimeException('شناسه جلسه نامعتبر است.');
                $stmt = $pdo->prepare('UPDATE study_sessions SET is_active = 0, updated_at = NOW() WHERE id = ?');
                $stmt->execute([$id]);
                if ($stmt->rowCount() < 1) throw new RuntimeException('جلسه موردنظر پیدا نشد.');
                $message = 'جلسه آرشیو شد؛ سابقه پیشرفت و نتایج خودآزمایی کاربران حفظ شد.';
            }
        } catch (Throwable $e) {
            error_log('Session admin operation failed: ' . $e->getMessage());
            $error = $e instanceof PDOException && (int)$e->errorInfo[1] === 1062 ? 'شماره ترتیب این جلسه در همین فصل قبلاً استفاده شده است. یک شماره دیگر انتخاب کنید.' : 'عملیات انجام نشد: ' . $e->getMessage();
        }
    }
}

$chapters = getStudyChapters($pdo);
$sessions = $pdo->query('SELECT s.*, c.title AS chapter_title FROM study_sessions s LEFT JOIN study_chapters c ON c.id = s.chapter_id ORDER BY c.sort_order ASC, s.sequence_no ASC, s.id ASC')->fetchAll();
$editSessionId = (int)($_GET['edit'] ?? 0);
$editSession = null;
if ($editSessionId > 0) {
    $stmt = $pdo->prepare('SELECT * FROM study_sessions WHERE id = ? LIMIT 1');
    $stmt->execute([$editSessionId]);
    $editSession = $stmt->fetch() ?: null;
}
$editChapterId = (int)($_GET['edit_chapter'] ?? 0);
$editChapter = null;
if ($editChapterId > 0) {
    $stmt = $pdo->prepare('SELECT * FROM study_chapters WHERE id = ? LIMIT 1');
    $stmt->execute([$editChapterId]);
    $editChapter = $stmt->fetch() ?: null;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>مدیریت جلسات مطالعه</title><link rel="stylesheet" href="../assets/css/style.css?v=20260928-sessions5">
<style>
body.admin-sessions-page{display:block!important;min-height:100vh!important;padding:20px!important;overflow-x:hidden}
.admin-sessions-wrap{width:min(1100px,100%);margin:0 auto}
.panel{background:rgba(255,255,255,.72);backdrop-filter:blur(28px);-webkit-backdrop-filter:blur(28px);border:1px solid rgba(255,255,255,.58);border-radius:24px;padding:22px;margin-bottom:18px;box-shadow:0 24px 60px -38px rgba(0,0,0,.3)}
h1,h2,h3{color:var(--text-primary)}
.topbar{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:18px}.topbar h1{margin:0;font-size:24px}.back-link{color:#007aff;text-decoration:none;font-weight:800;font-size:13px}
.message{padding:12px 14px;border-radius:14px;margin-bottom:14px;text-align:center;font-size:13px}.success{background:rgba(52,199,89,.12);color:#198c41}.error{background:rgba(255,59,48,.1);color:#b42318}
.form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.field{display:flex;flex-direction:column;gap:6px}.field.full{grid-column:1/-1}.field label{font-size:13px;font-weight:800;color:var(--text-primary)}
.field input,.field select,.field textarea{width:100%;box-sizing:border-box;border:1px solid rgba(0,0,0,.08);border-radius:13px;padding:10px 12px;background:rgba(255,255,255,.84);font-family:inherit;font-size:14px;outline:none;transition:border-color .18s ease,box-shadow .18s ease}.field input:focus,.field select:focus,.field textarea:focus{border-color:rgba(16,173,154,.48);box-shadow:0 0 0 4px rgba(16,173,154,.09)}.field textarea{min-height:80px;resize:vertical}
.btn{border:none;border-radius:999px;padding:11px 18px;font-family:inherit;font-weight:800;cursor:pointer}.btn-primary{background:linear-gradient(135deg,#10ad9a,#0d8d7f);color:#fff}.btn-secondary{background:rgba(255,255,255,.78);border:1px solid rgba(0,0,0,.06);color:var(--text-primary)}.btn-danger{background:rgba(255,59,48,.1);color:#b42318;border:1px solid rgba(255,59,48,.12)}
.chapter{padding:14px;border:1px solid rgba(0,0,0,.06);border-radius:18px;background:rgba(255,255,255,.55);margin-bottom:12px}.chapter-title{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px}.chapter-title h3{margin:0;font-size:17px}.chapter-desc{font-size:12px;color:var(--text-secondary);margin-bottom:10px}
.session-row{display:flex;align-items:center;gap:12px;padding:12px;border-radius:16px;background:rgba(255,255,255,.7);border:1px solid rgba(0,0,0,.05);margin-top:8px}.session-num{width:42px;height:42px;border-radius:14px;background:linear-gradient(135deg,#e7faf7,#e7f0ff);display:flex;align-items:center;justify-content:center;font-weight:900;color:#108e7f;flex:0 0 42px}.session-main{min-width:0;flex:1}.session-main strong{display:block;font-size:14px;margin-bottom:3px}.session-meta{font-size:11px;color:var(--text-secondary)}.session-actions{display:flex;gap:7px;flex-wrap:wrap}.session-actions a,.session-actions button{font-size:11px;padding:7px 10px}.checkline{display:flex;align-items:center;gap:7px;font-size:13px;color:var(--text-secondary)}

/* ویرایشگر حرفه‌ای متن جلسه */
.rich-editor{border:1px solid #cfd6dd;border-radius:18px;background:#fff;overflow:hidden;box-shadow:0 10px 30px rgba(15,23,42,.06);transition:border-color .18s ease,box-shadow .18s ease}
.rich-editor.is-focused{border-color:rgba(16,173,154,.55);box-shadow:0 0 0 4px rgba(16,173,154,.08),0 12px 32px rgba(15,23,42,.06)}
.rich-toolbar{display:flex;align-items:center;flex-wrap:wrap;gap:6px;padding:9px;background:linear-gradient(180deg,#fcfcfd,#f3f5f7);border-bottom:1px solid #e1e5e9;position:sticky;top:0;z-index:3}
.ri-group{display:inline-flex;align-items:center;gap:4px;padding-left:6px;margin-left:1px;border-left:1px solid #dfe3e7}.ri-group:first-child{border-left:0;margin-left:0;padding-left:0}
.ri-btn,.ri-select{height:36px;border:1px solid #d5dbe1;background:#fff;color:#20252b;border-radius:10px;font:800 13px/1 inherit;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;user-select:none;transition:background .15s ease,border-color .15s ease,box-shadow .15s ease,transform .05s ease}.ri-btn{min-width:36px;padding:0 10px}.ri-btn:hover,.ri-select:hover{background:#f8fbfb;border-color:#b9c5cb}.ri-btn:active{transform:translateY(1px)}.ri-btn.active{background:#e7f8f5;border-color:#8bd2c7;color:#0d766b;box-shadow:inset 0 0 0 1px rgba(16,173,154,.08)}.ri-btn:focus-visible,.ri-select:focus-visible{outline:3px solid rgba(16,173,154,.18);outline-offset:1px}.ri-select{min-width:118px;padding:0 10px;font-weight:800}
.ri-btn[data-action="link"]{min-width:68px}.ri-btn[data-action="clear"]{min-width:92px}.ri-btn[data-action="code"]{min-width:70px}
.rich-surface{min-height:360px;max-height:62vh;overflow:auto;padding:18px 20px;outline:none;color:#222;font-size:15px;line-height:2.05;direction:rtl;text-align:right;background:#fff;caret-color:#0d8d7f;word-break:break-word;overflow-wrap:anywhere}.rich-surface:focus{outline:none}.rich-surface:empty:before{content:attr(data-placeholder);color:#a2a8ae;pointer-events:none}.rich-surface p{margin:0 !important}.rich-surface p:last-child{margin-bottom:0 !important}.rich-surface h2,.rich-surface h3,.rich-surface h4{margin:1.05em 0 .55em;line-height:1.65;color:#18221d}.rich-surface h2{font-size:1.5rem;font-weight:900}.rich-surface h3{font-size:1.28rem;font-weight:800}.rich-surface h4{font-size:1.12rem;font-weight:800}.rich-surface blockquote{margin:1em 0;padding:10px 14px;border-right:4px solid #10ad9a;background:rgba(16,173,154,.06);border-radius:10px;color:#3b4743}.rich-surface ul,.rich-surface ol{padding-right:1.6em;margin:0 0 1em}.rich-surface li{margin:.25em 0}.rich-surface a{color:#0d8d7f;text-decoration:underline}.rich-surface img{max-width:100%;height:auto;border-radius:10px}.rich-surface hr{border:0;border-top:1px solid #d7dce0;margin:1.5em 0}.rich-surface sub{vertical-align:sub}.rich-surface sup{vertical-align:super}
.rich-editor-hint{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:7px 12px;border-top:1px solid #eef0f2;background:#fbfcfd;color:#7b838a;font-size:11px}.rich-editor-status{min-width:0}.rich-editor-count{direction:ltr;white-space:nowrap}.rich-editor.is-dirty .rich-editor-status{color:#0d8d7f}.footnote-admin-help{font-size:11px;color:var(--text-secondary)}
.audio-current{display:flex;flex-direction:column;gap:8px;margin-top:8px}.audio-current audio{width:100%;max-width:440px}
@media(max-width:700px){body.admin-sessions-page{padding:10px!important}.panel{padding:16px;border-radius:20px}.form-grid{grid-template-columns:1fr}.field.full{grid-column:auto}.session-row{align-items:flex-start}.session-actions{flex-direction:column}.session-actions a,.session-actions button{width:100%}.rich-toolbar{position:static;gap:5px;padding:8px}.ri-group{border-left:0;margin-left:0;padding-left:0}.ri-btn,.ri-select{height:34px;padding:0 8px}.ri-select{min-width:100px}.rich-surface{min-height:300px;max-height:56vh;padding:14px;font-size:15px;line-height:2}.rich-editor-hint{font-size:10px}}
</style>
</head>
<body class="admin-sessions-page admin-page-body">
<div class="bg-mesh"><div class="blob blob-1"></div><div class="blob blob-2"></div><div class="blob blob-3"></div></div>
<?php require __DIR__ . '/../includes/page_loader.php'; ?>
<div class="admin-sessions-wrap">
<div class="topbar"><h1>📚 مدیریت جلسات مطالعه</h1><a class="back-link" href="dashboard.php">← بازگشت به داشبورد</a></div>
<?php if ($message): ?><div class="message success">✅ <?= e($message) ?></div><?php endif; ?>
<?php if ($error): ?><div class="message error">❌ <?= e($error) ?></div><?php endif; ?>

<?php if ($editChapter): ?>
<section class="panel"><h2 style="margin:0 0 14px;font-size:18px;">✏️ ویرایش فصل</h2>
<form method="POST"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="chapter_id" value="<?= (int)$editChapter['id'] ?>"><div class="form-grid"><div class="field"><label>عنوان فصل</label><input name="chapter_title" value="<?= e($editChapter['title']) ?>" required></div><div class="field"><label>ترتیب فصل</label><input type="number" min="1" name="chapter_sort" value="<?= (int)$editChapter['sort_order'] ?>"></div><div class="field full"><label>توضیح کوتاه</label><input name="chapter_description" maxlength="500" value="<?= e((string)$editChapter['description']) ?>"></div></div><button class="btn btn-primary" name="edit_chapter" style="margin-top:12px;">ذخیره فصل</button><a href="sessions.php" class="btn btn-secondary" style="display:inline-flex;text-decoration:none;margin-top:12px;">انصراف</a></form></section>
<?php endif; ?>

<section class="panel"><h2 style="margin:0 0 14px;font-size:18px;">➕ ایجاد فصل</h2>
<form method="POST"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><div class="form-grid">
<div class="field"><label>عنوان فصل</label><input name="chapter_title" required placeholder="مثلاً فصل اول: آشنایی"></div>
<div class="field"><label>ترتیب فصل</label><input type="number" min="1" name="chapter_sort" value="1"></div>
<div class="field full"><label>توضیح کوتاه (اختیاری)</label><input name="chapter_description" maxlength="500" placeholder="توضیح مختصر فصل"></div>
</div><button class="btn btn-primary" name="add_chapter" style="margin-top:12px;">ایجاد فصل</button></form></section>

<section class="panel"><h2 style="margin:0 0 14px;font-size:18px;"><?= $editSession ? '✏️ ویرایش جلسه' : '➕ ایجاد جلسه جدید' ?></h2>
<form method="POST" enctype="multipart/form-data" class="session-editor-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
<?php if ($editSession): ?><input type="hidden" name="session_id" value="<?= (int)$editSession['id'] ?>"><?php endif; ?>
<div class="form-grid">
<div class="field"><label>فصل</label><select name="chapter_id" required><?php foreach($chapters as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (($editSession['chapter_id']??0)==$c['id'])?'selected':'' ?>><?= e($c['title']) ?></option><?php endforeach; ?></select></div>
<div class="field"><label>شماره ترتیب جلسه (داخل فصل)</label><input type="number" min="1" name="sequence_no" value="<?= e((string)($editSession['sequence_no'] ?? ((int)$pdo->query('SELECT COALESCE(MAX(sequence_no),0)+1 FROM study_sessions WHERE chapter_id = ' . ((int)($editSession['chapter_id'] ?? 0)))->fetchColumn()))) ?>" required></div>
<div class="field full"><label>عنوان جلسه</label><input name="session_title" value="<?= e((string)($editSession['title'] ?? '')) ?>" required placeholder="مثلاً اهمیت امر به معروف"></div>
<div class="field full"><label>خلاصه کوتاه</label><input name="session_summary" value="<?= e((string)($editSession['summary'] ?? '')) ?>" maxlength="500" placeholder="یک توضیح کوتاه برای فهرست جلسات"></div>
<div class="field full"><label>پاورقی</label><textarea name="session_footnote" rows="3" maxlength="2000" placeholder="در صورت نیاز، متن پاورقی یا پی‌نوشت را وارد کنید..." ><?= e((string)($editSession['footnote'] ?? '')) ?></textarea><div class="footnote-admin-help">این متن زیر محتوای اصلی جلسه با فونت ریز و خاکستری نمایش داده می‌شود.</div></div>
<div class="field full"><label>متن جلسه</label>
<div class="rich-editor" data-editor-instance="session" data-editor-id="session-rich-editor">
  <div class="rich-toolbar" role="toolbar" aria-label="ابزارهای ویرایش متن جلسه" aria-controls="session_rich_surface">
    <span class="ri-group">
      <button type="button" class="ri-btn" data-cmd="bold" title="ضخیم" aria-label="ضخیم">B</button>
      <button type="button" class="ri-btn" data-cmd="italic" title="مورب" aria-label="مورب"><em>I</em></button>
      <button type="button" class="ri-btn" data-cmd="underline" title="زیرخط" aria-label="زیرخط"><u>U</u></button>
      <button type="button" class="ri-btn" data-cmd="strikeThrough" title="خط‌خورده" aria-label="خط‌خورده"><s>S</s></button>
    </span>
    <span class="ri-group">
      <select class="ri-select" data-format="formatBlock" title="سبک متن" aria-label="سبک متن">
        <option value="P">متن عادی</option>
        <option value="H2">عنوان ۲</option>
        <option value="H3">عنوان ۳</option>
        <option value="H4">عنوان ۴</option>
        <option value="BLOCKQUOTE">نقل‌قول</option>
      </select>
    </span>
    <span class="ri-group">
      <button type="button" class="ri-btn" data-cmd="justifyRight" title="راست‌چین" aria-label="راست‌چین">راست</button>
      <button type="button" class="ri-btn" data-cmd="justifyCenter" title="وسط‌چین" aria-label="وسط‌چین">وسط</button>
      <button type="button" class="ri-btn" data-cmd="justifyLeft" title="چپ‌چین" aria-label="چپ‌چین">چپ</button>
      <button type="button" class="ri-btn" data-cmd="justifyFull" title="تراز کامل" aria-label="تراز کامل">تراز</button>
    </span>
    <span class="ri-group">
      <button type="button" class="ri-btn" data-cmd="insertUnorderedList" title="فهرست نقطه‌ای" aria-label="فهرست نقطه‌ای">•</button>
      <button type="button" class="ri-btn" data-cmd="insertOrderedList" title="فهرست شماره‌دار" aria-label="فهرست شماره‌دار">1.</button>
      <button type="button" class="ri-btn" data-cmd="outdent" title="کاهش تورفتگی" aria-label="کاهش تورفتگی">←</button>
      <button type="button" class="ri-btn" data-cmd="indent" title="افزایش تورفتگی" aria-label="افزایش تورفتگی">→</button>
    </span>
    <span class="ri-group">
      <button type="button" class="ri-btn" data-cmd="superscript" title="بالانویس" aria-label="بالانویس">x<sup>2</sup></button>
      <button type="button" class="ri-btn" data-cmd="subscript" title="زیرنویس" aria-label="زیرنویس">x<sub>2</sub></button>
    </span>
    <span class="ri-group">
      <button type="button" class="ri-btn" data-action="link" title="درج پیوند" aria-label="درج پیوند">پیوند</button>
      <button type="button" class="ri-btn" data-cmd="unlink" title="حذف پیوند" aria-label="حذف پیوند">حذف پیوند</button>
      <button type="button" class="ri-btn" data-action="hr" title="خط جداکننده" aria-label="خط جداکننده">خط</button>
    </span>
    <span class="ri-group">
      <button type="button" class="ri-btn" data-action="clear" title="حذف قالب‌بندی" aria-label="حذف قالب‌بندی">پاک‌کردن قالب</button>
      <button type="button" class="ri-btn" data-cmd="undo" title="واگردانی" aria-label="واگردانی">↶</button>
      <button type="button" class="ri-btn" data-cmd="redo" title="بازگردانی" aria-label="بازگردانی">↷</button>
    </span>
  </div>
  <div class="rich-surface" id="session_rich_surface" contenteditable="true" role="textbox" aria-multiline="true" aria-label="متن جلسه" spellcheck="true" data-target="session_content" data-placeholder="متن جلسه را اینجا وارد کنید...">
    <?= $editSession['content'] ?? '' ?>
  </div>
  <div class="rich-editor-hint"><span class="rich-editor-status" aria-live="polite">متن ویرایش نشده</span><span class="rich-editor-count">۰ نویسه</span></div>
  <textarea hidden name="session_content" id="session_content"></textarea>
</div></div>
<div class="field"><label>فایل صوتی (اختیاری، حداکثر ۲۵MB)</label><input type="file" name="audio_file" accept="audio/*"><input type="hidden" name="remove_audio" value="0"><label class="checkline"><input type="checkbox" name="is_active" value="1" <?= (!isset($editSession) || (int)($editSession['is_active']??1)===1) ? 'checked' : '' ?>> منتشر و قابل مشاهده باشد</label>
<?php if ($editSession && !empty($editSession['audio_path'])): ?><div class="audio-current">صوت فعلی: <audio controls preload="none" src="../<?= e($editSession['audio_path']) ?>"></audio><label class="checkline"><input type="checkbox" name="remove_audio" value="1"> حذف صوت فعلی</label></div><?php endif; ?></div>
</div>
<button class="btn btn-primary" name="<?= $editSession ? 'edit_session' : 'add_session' ?>" style="margin-top:12px;"><?= $editSession ? 'ذخیره ویرایش جلسه' : 'ایجاد جلسه' ?></button>
<?php if($editSession): ?><a href="sessions.php" class="btn btn-secondary" style="display:inline-flex;text-decoration:none;margin-top:12px;">انصراف از ویرایش</a><?php endif; ?>
</form></section>

<section class="panel"><h2 style="margin:0 0 14px;font-size:18px;">📖 جلسات موجود</h2>
<?php foreach($chapters as $chapter): $chapterItems=array_values(array_filter($sessions,fn($s)=>(int)$s['chapter_id']===(int)$chapter['id'])); ?>
<div class="chapter"><div class="chapter-title"><h3><?= e($chapter['title']) ?></h3><a class="back-link" href="sessions.php?edit_chapter=<?= (int)$chapter['id'] ?>">ویرایش فصل</a></div><?php if($chapter['description']): ?><div class="chapter-desc"><?= e($chapter['description']) ?></div><?php endif; ?>
<?php if(!$chapterItems): ?><div class="chapter-desc">هنوز جلسه‌ای در این فصل ساخته نشده است.</div><?php else: foreach($chapterItems as $s): ?>
<div class="session-row"><div class="session-num"><?= e((string)$s['sequence_no']) ?></div><div class="session-main"><strong><?= e($s['title']) ?></strong><div class="session-meta"><?= ((int)$s['is_active']===1?'منتشر شده':'غیرفعال') ?> · <?= !empty($s['audio_path'])?'🎧 صوت دارد':'بدون صوت' ?></div></div><div class="session-actions"><a class="btn btn-secondary" href="sessions.php?edit=<?= (int)$s['id'] ?>">ویرایش</a><a class="btn btn-secondary" href="questions.php?session_id=<?= (int)$s['id'] ?>">سؤالات</a><form method="POST" style="margin:0"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="session_id" value="<?= (int)$s['id'] ?>"><button type="submit" class="btn btn-secondary" name="toggle_session"><?= ((int)$s['is_active']===1)?'غیرفعال‌سازی':'انتشار' ?></button></form><?php if ((int)$s['is_active']===1): ?><form method="POST" style="margin:0" onsubmit="return confirm('این جلسه آرشیو شود؟ سابقه پیشرفت و نتایج کاربران حفظ خواهند شد.')"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="session_id" value="<?= (int)$s['id'] ?>"><button class="btn btn-danger" name="archive_session">🗄 آرشیو</button></form><?php endif; ?></div></div>
<?php endforeach; endif; ?></div>
<?php endforeach; ?>
</section>
</div>
<script>
(function () {
    'use strict';

    const state = new WeakMap();
    const COMMAND_STATE = new Set([
        'bold', 'italic', 'underline', 'strikeThrough',
        'insertUnorderedList', 'insertOrderedList',
        'superscript', 'subscript'
    ]);

    const hasSelectionApi = () => typeof window.getSelection === 'function';

    function getState(editor) {
        let value = state.get(editor);
        if (!value) {
            value = { range: null, dirty: false };
            state.set(editor, value);
        }
        return value;
    }

    function getSurface(editor) {
        return editor ? editor.querySelector('.rich-surface') : null;
    }

    function selectionInside(surface) {
        if (!surface || !hasSelectionApi()) return false;
        const selection = window.getSelection();
        if (!selection || !selection.rangeCount) return false;
        const range = selection.getRangeAt(0);
        return surface.contains(range.commonAncestorContainer);
    }

    function saveSelection(editor) {
        const surface = getSurface(editor);
        if (!surface || !hasSelectionApi()) return;
        const selection = window.getSelection();
        if (!selection || !selection.rangeCount) return;
        const range = selection.getRangeAt(0);
        if (surface.contains(range.commonAncestorContainer)) {
            getState(editor).range = range.cloneRange();
        }
    }

    function restoreSelection(editor) {
        const surface = getSurface(editor);
        const stored = getState(editor).range;
        if (!surface || !stored || !hasSelectionApi()) return false;
        try {
            if (!surface.contains(stored.commonAncestorContainer)) return false;
            const selection = window.getSelection();
            selection.removeAllRanges();
            selection.addRange(stored);
            return true;
        } catch (error) {
            return false;
        }
    }

    function ensureCaret(editor) {
        const surface = getSurface(editor);
        if (!surface) return false;
        surface.focus({ preventScroll: true });
        if (restoreSelection(editor)) return true;
        try {
            const range = document.createRange();
            range.selectNodeContents(surface);
            range.collapse(false);
            const selection = window.getSelection();
            selection.removeAllRanges();
            selection.addRange(range);
            saveSelection(editor);
            return true;
        } catch (error) {
            return false;
        }
    }

    function markDirty(editor) {
        const editorState = getState(editor);
        editorState.dirty = true;
        editor.classList.add('is-dirty');
        const status = editor.querySelector('.rich-editor-status');
        if (status) status.textContent = 'تغییرات آماده ذخیره';
    }

    function textLength(surface) {
        return (surface?.innerText || '').replace(/\u00a0/g, ' ').trim().length;
    }

    function updateCount(editor) {
        const surface = getSurface(editor);
        const count = editor.querySelector('.rich-editor-count');
        if (!surface || !count) return;
        count.textContent = new Intl.NumberFormat('fa-IR').format(textLength(surface)) + ' نویسه';
    }

    function safeExecCommand(command, value) {
        try {
            if (document.queryCommandSupported && !document.queryCommandSupported(command)) return false;
        } catch (error) {}
        try {
            return document.execCommand(command, false, value ?? null);
        } catch (error) {
            return false;
        }
    }

    function updateToolbarState(editor) {
        const surface = getSurface(editor);
        if (!surface || !selectionInside(surface)) return;

        editor.querySelectorAll('[data-cmd]').forEach((button) => {
            const command = button.dataset.cmd;
            if (!COMMAND_STATE.has(command)) return;
            try {
                button.classList.toggle('active', !!document.queryCommandState(command));
            } catch (error) {
                button.classList.remove('active');
            }
        });

        const format = editor.querySelector('[data-format="formatBlock"]');
        if (format) {
            let block = '';
            try { block = String(document.queryCommandValue('formatBlock') || '').toLowerCase().replace(/[<>]/g, ''); } catch (error) {}
            const normalized = block === 'div' || block === 'normal' ? 'P' : block.toUpperCase();
            const allowed = ['P', 'H2', 'H3', 'H4', 'BLOCKQUOTE'];
            format.value = allowed.includes(normalized) ? normalized : 'P';
        }
    }

    function runCommand(editor, command, value = null) {
        const surface = getSurface(editor);
        if (!surface) return;
        surface.focus({ preventScroll: true });
        restoreSelection(editor);
        const ok = safeExecCommand(command, value);
        saveSelection(editor);
        if (ok) {
            markDirty(editor);
            updateToolbarState(editor);
            updateCount(editor);
        }
    }

    function runFormat(editor, tagName) {
        const surface = getSurface(editor);
        if (!surface) return;
        ensureCaret(editor);
        const tag = String(tagName || 'p').toLowerCase();
        let ok = safeExecCommand('formatBlock', '<' + tag + '>');
        if (!ok) ok = safeExecCommand('formatBlock', tag);
        saveSelection(editor);
        if (ok) {
            markDirty(editor);
            updateToolbarState(editor);
            updateCount(editor);
        }
    }

    function insertLink(editor) {
        const surface = getSurface(editor);
        if (!surface) return;
        ensureCaret(editor);
        const selection = window.getSelection();
        const selectedText = selection && selection.rangeCount ? selection.toString().trim() : '';
        let url = window.prompt('آدرس پیوند را وارد کنید:', 'https://');
        if (url === null) return;
        url = url.trim();
        if (!url) return;
        if (!/^(https?:\/\/|mailto:|tel:)/i.test(url)) url = 'https://' + url;
        if (selectedText) {
            runCommand(editor, 'createLink', url);
        } else {
            const label = window.prompt('متن پیوند را وارد کنید:', url);
            if (label === null) return;
            const html = '<a href="' + escapeHtmlAttr(url) + '">' + escapeHtml(label || url) + '</a>';
            surface.focus({ preventScroll: true });
            restoreSelection(editor);
            if (!safeExecCommand('insertHTML', html)) insertHtmlFallback(editor, html);
            saveSelection(editor);
            markDirty(editor);
            updateToolbarState(editor);
            updateCount(editor);
        }
    }

    function escapeHtml(value) {
        return String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }

    function escapeHtmlAttr(value) {
        return escapeHtml(value);
    }

    function insertHtmlFallback(editor, html) {
        const surface = getSurface(editor);
        if (!surface || !hasSelectionApi()) return;
        const selection = window.getSelection();
        if (!selection || !selection.rangeCount) return;
        const range = selection.getRangeAt(0);
        if (!surface.contains(range.commonAncestorContainer)) return;
        range.deleteContents();
        const wrapper = document.createElement('div');
        wrapper.innerHTML = html;
        const fragment = document.createDocumentFragment();
        while (wrapper.firstChild) fragment.appendChild(wrapper.firstChild);
        range.insertNode(fragment);
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);
    }

    function insertHorizontalRule(editor) {
        ensureCaret(editor);
        if (!safeExecCommand('insertHorizontalRule')) insertHtmlFallback(editor, '<hr>');
        saveSelection(editor);
        markDirty(editor);
        updateCount(editor);
    }

    function clearFormatting(editor) {
        runCommand(editor, 'removeFormat');
        runFormat(editor, 'p');
    }

    function sanitizePastedHtml(html) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const allowedTags = new Set(['P','BR','STRONG','B','EM','I','U','S','SUP','SUB','H2','H3','H4','UL','OL','LI','BLOCKQUOTE','A','SPAN','DIV','HR']);
        const allowedStyle = new Set(['text-align','font-weight','font-style','text-decoration','color','background-color','font-size','font-family']);

        function cleanNode(node) {
            for (const child of Array.from(node.childNodes)) {
                if (child.nodeType === Node.TEXT_NODE) continue;
                if (child.nodeType !== Node.ELEMENT_NODE) {
                    child.remove();
                    continue;
                }
                const el = /** @type {HTMLElement} */ (child);
                const tag = el.tagName.toUpperCase();
                if (['SCRIPT','STYLE','IFRAME','OBJECT','EMBED','FORM','INPUT','BUTTON','META','LINK','NOSCRIPT'].includes(tag)) {
                    el.remove();
                    continue;
                }
                if (!allowedTags.has(tag)) {
                    const frag = document.createDocumentFragment();
                    while (el.firstChild) frag.appendChild(el.firstChild);
                    el.replaceWith(frag);
                    continue;
                }
                for (const attr of Array.from(el.attributes)) {
                    const name = attr.name.toLowerCase();
                    if (tag === 'A' && name === 'href') continue;
                    if (name === 'style') {
                        const safe = [];
                        for (const decl of attr.value.split(';')) {
                            const idx = decl.indexOf(':');
                            if (idx < 0) continue;
                            const prop = decl.slice(0, idx).trim().toLowerCase();
                            const val = decl.slice(idx + 1).trim();
                            if (allowedStyle.has(prop) && val && !/url\s*\(|expression\s*\(|javascript\s*:|[<>]/i.test(val)) safe.push(prop + ': ' + val);
                        }
                        if (safe.length) el.setAttribute('style', safe.join('; ')); else el.removeAttribute('style');
                        continue;
                    }
                    el.removeAttribute(attr.name);
                }
                if (tag === 'A') {
                    const href = el.getAttribute('href') || '';
                    if (!/^(https?:\/\/|mailto:|tel:)/i.test(href.trim())) el.removeAttribute('href');
                    else { el.setAttribute('target', '_blank'); el.setAttribute('rel', 'noopener noreferrer'); }
                }
                cleanNode(el);
            }
        }

        cleanNode(doc.body);
        return doc.body.innerHTML;
    }

    function plainTextToHtml(text) {
        const lines = String(text || '').replace(/\r\n?/g, '\n').split('\n');
        return lines.map(line => line.trim() ? '<p>' + escapeHtml(line) + '</p>' : '<p><br></p>').join('');
    }

    function pasteIntoEditor(editor, event) {
        const surface = getSurface(editor);
        if (!surface) return;
        event.preventDefault();
        ensureCaret(editor);
        const clipboard = event.clipboardData;
        if (!clipboard) return;
        const html = clipboard.getData('text/html');
        const text = clipboard.getData('text/plain');
        const cleanHtml = html ? sanitizePastedHtml(html) : '';
        const payload = cleanHtml || plainTextToHtml(text);
        if (!payload) return;
        const inserted = safeExecCommand('insertHTML', payload);
        if (!inserted) insertHtmlFallback(editor, payload);
        saveSelection(editor);
        markDirty(editor);
        updateToolbarState(editor);
        updateCount(editor);
    }

    function handleKeydown(editor, event) {
        const surface = getSurface(editor);
        if (!surface) return;
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
            event.preventDefault();
            const form = surface.closest('form');
            if (form) form.requestSubmit();
            return;
        }
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
            event.preventDefault();
            insertLink(editor);
            return;
        }
        if (event.key === 'Tab') {
            event.preventDefault();
            runCommand(editor, event.shiftKey ? 'outdent' : 'indent');
        }
    }

    function initEditor(editor) {
        const surface = getSurface(editor);
        if (!surface) return;

        surface.addEventListener('focus', () => {
            editor.classList.add('is-focused');
            saveSelection(editor);
            updateToolbarState(editor);
            updateCount(editor);
        });
        surface.addEventListener('blur', () => {
            editor.classList.remove('is-focused');
            saveSelection(editor);
        });
        surface.addEventListener('mouseup', () => { saveSelection(editor); updateToolbarState(editor); });
        surface.addEventListener('keyup', () => { saveSelection(editor); updateToolbarState(editor); updateCount(editor); });
        surface.addEventListener('input', () => { saveSelection(editor); markDirty(editor); updateToolbarState(editor); updateCount(editor); });
        surface.addEventListener('paste', (event) => pasteIntoEditor(editor, event));
        surface.addEventListener('keydown', (event) => handleKeydown(editor, event));

        editor.addEventListener('mousedown', (event) => {
            const control = event.target.closest('button, select');
            if (!control) return;
            saveSelection(editor);
            if (control.tagName === 'BUTTON') event.preventDefault();
        });
        editor.addEventListener('click', (event) => {
            const button = event.target.closest('button');
            if (!button) return;
            const command = button.dataset.cmd;
            const action = button.dataset.action;
            if (command) runCommand(editor, command);
            else if (action === 'link') insertLink(editor);
            else if (action === 'hr') insertHorizontalRule(editor);
            else if (action === 'clear') clearFormatting(editor);
        });
        editor.querySelectorAll('[data-format]').forEach((select) => {
            select.addEventListener('change', () => {
                saveSelection(editor);
                runFormat(editor, select.value);
            });
        });

        updateCount(editor);
        updateToolbarState(editor);
    }

    window.syncEditorForm = function (form) {
        form.querySelectorAll('.rich-surface').forEach((surface) => {
            const targetId = surface.dataset.target;
            const target = targetId ? document.getElementById(targetId) : null;
            if (target) target.value = sanitizePastedHtml(surface.innerHTML.trim());
        });
        return true;
    };

    document.addEventListener('selectionchange', () => {
        document.querySelectorAll('.rich-editor').forEach((editor) => {
            const surface = getSurface(editor);
            if (surface && selectionInside(surface)) {
                saveSelection(editor);
                updateToolbarState(editor);
            }
        });
    });

    document.querySelectorAll('.rich-editor').forEach(initEditor);
    document.querySelectorAll('.session-editor-form').forEach((form) => {
        form.addEventListener('submit', function () { window.syncEditorForm(form); });
    });
})();
</script>
<script src="../assets/js/app.js?v=20260928-sessions5" defer></script>
<?php require __DIR__ . '/../includes/site_footer.php'; ?>
</body>
</html>
