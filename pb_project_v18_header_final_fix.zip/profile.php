<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

require_login('login.php');
$user = getUser($pdo);
$userId = (int)$_SESSION['user_id'];
if (!$user) {
    redirect('login.php');
}

/* همان منطق پیشرفت صفحه خانه، برای جلوگیری از نمایش نادرست «سامانه فعال نشده» */
$sessionSystem = studySessionTablesAvailable($pdo);
$totalSessions = 0;
$completedCount = 0;
$overallPercent = 0;
$nextSession = null;
$accessTitle = 'دسترسی عادی مسیر مطالعه';
if ($sessionSystem) {
    $allSessions = getActiveStudySessions($pdo);
    $progressMap = getUserSessionProgressMap($pdo, $userId);
    $activeSessionIds = [];
    foreach ($allSessions as $session) $activeSessionIds[(int)$session['id']] = true;
    $archivedCompletedCount = 0;
    foreach ($progressMap as $sid => $pr) {
        if (!isset($activeSessionIds[(int)$sid]) && (int)($pr['is_completed'] ?? 0) === 1) $archivedCompletedCount++;
    }
    $totalSessions = count($allSessions) + $archivedCompletedCount;
    foreach ($allSessions as $session) {
        $sid = (int)$session['id'];
        $progressMap[$sid] = $progressMap[$sid] ?? getUserSessionProgress($pdo, $userId, $sid);
        if ((int)($progressMap[$sid]['is_completed'] ?? 0) === 1) $completedCount++;
    }
    $completedCount += $archivedCompletedCount;
    $overallPercent = $totalSessions > 0 ? (int)round(($completedCount / $totalSessions) * 100) : 0;
    $nextSession = getNextStudySessionForUser($pdo, $userId, $progressMap);
    $grant = getUserSessionAccessGrant($pdo, $userId);
    $grantSessionId = (int)($grant['max_session_id'] ?? 0);
    if ($grantSessionId > 0) {
        $grantSession = getStudySession($pdo, $grantSessionId);
        $accessTitle = $grantSession ? 'دسترسی تا ' . (string)$grantSession['title'] : 'دسترسی ویژه';
    }
}

function toFaDigits(string $value): string {
    return strtr($value, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']);
}

$userSkills = [];
$selectedSkillIds = [];
$selectedOtherText = '';
$skillsAvailable = tableExists($pdo, 'user_skills') && tableExists($pdo, 'skill_options');
$profileMessage = '';
$profileError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['profile_action'])) {
    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        $profileError = '❌ درخواست نامعتبر است. صفحه را تازه کنید و دوباره تلاش کنید.';
    } elseif ($_POST['profile_action'] === 'save_skills' && $skillsAvailable) {
        $postedSkillIds = isset($_POST['skills']) && is_array($_POST['skills'])
            ? array_values(array_unique(array_filter(array_map('intval', $_POST['skills']), static fn(int $id): bool => $id > 0)))
            : [];
        $otherText = trim((string)($_POST['other_skill'] ?? ''));
        try {
            $pdo->beginTransaction();
            $validRows = [];
            if ($postedSkillIds) {
                $ph = implode(',', array_fill(0, count($postedSkillIds), '?'));
                $st = $pdo->prepare("SELECT id, name FROM skill_options WHERE is_active = 1 AND id IN ($ph) ORDER BY sort_order, id");
                $st->execute($postedSkillIds);
                $validRows = $st->fetchAll();
            }
            $pdo->prepare('DELETE FROM user_skills WHERE user_id = ?')->execute([$userId]);
            if ($validRows) {
                $ins = $pdo->prepare('INSERT INTO user_skills (user_id, skill_option_id, custom_text) VALUES (?, ?, ?)');
                foreach ($validRows as $row) {
                    $custom = ((string)$row['name'] === 'سایر') ? $otherText : null;
                    $ins->execute([$userId, (int)$row['id'], $custom]);
                }
            }
            $labels = [];
            foreach ($validRows as $row) {
                $label = trim((string)$row['name']);
                if ($label === 'سایر' && $otherText !== '') $label .= ' — ' . $otherText;
                if ($label !== '') $labels[] = $label;
            }
            $pdo->prepare('UPDATE users SET skill = ? WHERE id = ?')->execute([implode('، ', $labels), $userId]);
            $pdo->commit();
            $profileMessage = '✅ توانمندی‌ها و مهارت‌ها با موفقیت به‌روزرسانی شد.';
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $profileError = '❌ ذخیره توانمندی‌ها انجام نشد. دوباره تلاش کنید.';
            error_log('Profile skills update failed: ' . $e->getMessage());
        }
    }
}

if ($skillsAvailable) {
    try {
        $skillStmt = $pdo->prepare('SELECT us.skill_option_id, so.name, us.custom_text FROM user_skills us INNER JOIN skill_options so ON so.id = us.skill_option_id WHERE us.user_id = ? ORDER BY so.sort_order ASC, so.id ASC');
        $skillStmt->execute([$userId]);
        $userSkills = $skillStmt->fetchAll();
    } catch (Throwable $e) {
        $userSkills = [];
    }
}

foreach ($userSkills as $skill) {
    $selectedSkillIds[] = (int)$skill['skill_option_id'];
    if (trim((string)$skill['name']) === 'سایر') $selectedOtherText = trim((string)($skill['custom_text'] ?? ''));
}

$skillLabels = [];
foreach ($userSkills as $skill) {
    $label = trim((string)($skill['name'] ?? ''));
    $custom = trim((string)($skill['custom_text'] ?? ''));
    if ($label === '') continue;
    if ($label === 'سایر' && $custom !== '') $label .= ' — ' . $custom;
    $skillLabels[] = $label;
}
if (!$skillLabels && trim((string)($user['skill'] ?? '')) !== '') {
    $skillLabels = array_values(array_filter(array_map('trim', preg_split('/،/u', (string)$user['skill']) ?: [])));
}

$skillOptions = [];
if ($skillsAvailable) {
    try {
        $skillOptions = $pdo->query("SELECT id, name FROM skill_options WHERE is_active = 1 ORDER BY sort_order, id")->fetchAll();
    } catch (Throwable $e) {
        $skillOptions = [];
    }
}

$fullName = trim((string)($user['full_name'] ?? 'کاربر'));
$initial = function_exists('mb_substr') ? mb_substr($fullName, 0, 1, 'UTF-8') : substr($fullName, 0, 1);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>بخش کاربری | پیشروان بصیرت</title>
<link rel="stylesheet" href="assets/css/style.css?v=20261001-profile3">
<style>
body.profile-page{display:block!important;min-height:100vh;margin:0;padding:0;overflow-x:hidden}
.profile-main{width:min(900px,calc(100% - 24px));margin:20px auto 48px}
.profile-card{background:rgba(255,255,255,.70);backdrop-filter:blur(34px) saturate(120%);-webkit-backdrop-filter:blur(34px) saturate(120%);border:1px solid rgba(255,255,255,.60);border-radius:30px;box-shadow:0 25px 65px -32px rgba(0,0,0,.30),inset 0 1px 0 rgba(255,255,255,.78);overflow:hidden}
.profile-hero{padding:28px 30px;background:linear-gradient(135deg,rgba(16,173,154,.13),rgba(255,255,255,.32));display:flex;align-items:center;gap:18px}
.profile-avatar{width:72px;height:72px;flex:0 0 72px;border-radius:22px;display:flex;align-items:center;justify-content:center;background:linear-gradient(145deg,#10ad9a,#0d8d7f);color:#fff;font-size:28px;font-weight:900;box-shadow:0 18px 30px -15px rgba(16,173,154,.68)}
.profile-kicker{margin:0 0 4px;color:#0e8b7d;font-size:12px;font-weight:800}
.profile-name{margin:0;color:var(--text-primary);font-size:28px;font-weight:900;line-height:1.45}
.profile-subtitle{margin:5px 0 0;color:var(--text-secondary);font-size:13px;line-height:1.8}
.profile-content{padding:24px}
.profile-section-title{display:flex;align-items:center;gap:8px;margin:0 0 14px;color:var(--text-primary);font-size:16px;font-weight:900}
.profile-info-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
.info-item{padding:16px;border-radius:18px;background:rgba(255,255,255,.52);border:1px solid rgba(0,0,0,.055);min-width:0}
.info-label{font-size:11px;color:#8b95a1;margin-bottom:5px;font-weight:700}
.info-value{font-size:14px;color:var(--text-primary);font-weight:800;line-height:1.7;overflow-wrap:anywhere}
.info-value.ltr{direction:ltr;text-align:right;unicode-bidi:plaintext}
.skill-list{display:flex;flex-wrap:wrap;gap:8px}
.skill-tag{display:inline-flex;align-items:center;max-width:100%;padding:7px 11px;border-radius:999px;background:rgba(16,173,154,.09);border:1px solid rgba(16,173,154,.14);color:#0d8577;font-size:12px;font-weight:800;line-height:1.5}
.profile-divider{height:1px;background:rgba(0,0,0,.07);margin:24px 0}
.progress-box{padding:18px;border-radius:22px;background:rgba(255,255,255,.46);border:1px solid rgba(0,0,0,.05)}
.progress-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px}
.progress-title{margin:0;color:var(--text-primary);font-size:14px;font-weight:900}
.progress-desc{margin:5px 0 0;color:var(--text-secondary);font-size:12px;line-height:1.8}
.progress-value{font-size:29px;line-height:1;font-weight:950;color:#10ad9a;white-space:nowrap}
.profile-track{height:9px;margin-top:15px;border-radius:999px;background:#e8ecef;overflow:hidden}
.profile-fill{height:100%;border-radius:inherit;background:linear-gradient(90deg,#10ad9a,#73d8ca);width:<?= max(0,min(100,$overallPercent)) ?>%}
.progress-foot{display:flex;justify-content:space-between;gap:10px;margin-top:9px;font-size:11px;color:#7c858f}
.next-session{margin-top:12px;padding:14px 16px;border-radius:18px;background:rgba(16,173,154,.07);border:1px solid rgba(16,173,154,.10);color:#2b4f4a;font-size:12px;line-height:1.8}
.next-session strong{color:#0b806f}
.profile-access{margin-top:12px;padding:13px 16px;border-radius:18px;background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.14);color:#74561d;font-size:12px;line-height:1.8}

.profile-message{margin-bottom:14px;padding:12px 14px;border-radius:15px;font-size:13px;font-weight:800}.profile-message.success{background:rgba(16,185,129,.09);color:#0f8b72;border:1px solid rgba(16,185,129,.14)}.profile-message.error{background:rgba(255,59,48,.08);color:#bd2f28;border:1px solid rgba(255,59,48,.14)}
.skills-editor{margin-top:14px;padding:18px;border-radius:22px;background:rgba(255,255,255,.44);border:1px solid rgba(0,0,0,.055);box-shadow:inset 0 1px 0 rgba(255,255,255,.7)}
.skills-editor-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px}
.skill-edit-option{position:relative;display:flex;align-items:center;gap:10px;min-height:48px;padding:10px 12px;border-radius:15px;background:rgba(255,255,255,.58);font-size:12px;font-weight:800;color:var(--text-primary);cursor:pointer;border:1px solid rgba(0,0,0,.05);transition:background .18s ease,border-color .18s ease,transform .18s ease,box-shadow .18s ease}
.skill-edit-option:hover{transform:translateY(-1px);border-color:rgba(16,173,154,.20);box-shadow:0 7px 18px -14px rgba(0,0,0,.32)}
.skill-edit-option input{width:18px;height:18px;flex:0 0 18px;accent-color:#10ad9a;margin:0}
.skill-edit-option input:checked + span{color:#0d8577}
.skill-edit-option:has(input:checked){border-color:rgba(16,173,154,.23);background:rgba(16,173,154,.085);box-shadow:inset 0 1px 0 rgba(255,255,255,.75)}
.skill-edit-other{margin-top:14px;padding-top:14px;border-top:1px dashed rgba(0,0,0,.09)}
.skill-edit-other label{display:block;font-size:11px;font-weight:800;color:#6f7882;margin-bottom:6px}.skill-edit-other input{width:100%;border:1px solid rgba(0,0,0,.08);border-radius:13px;padding:11px 12px;background:rgba(255,255,255,.76);font:inherit;font-size:12px;outline:none}.skill-edit-other input:focus{border-color:rgba(16,173,154,.35);box-shadow:0 0 0 3px rgba(16,173,154,.08)}
.skill-editor-actions{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-top:14px}.skill-editor-actions button{min-height:44px;border:0;border-radius:14px;padding:10px 15px;font:inherit;font-size:12px;font-weight:900;cursor:pointer}.skill-save-btn{background:linear-gradient(135deg,#10ad9a,#0d8d7f);color:#fff;box-shadow:0 10px 22px -14px rgba(13,141,127,.7)}.skill-cancel-btn{background:rgba(0,0,0,.045);color:#4b5560}
.skills-empty-note{font-size:12px;color:#7d858e;line-height:1.8;margin-top:12px}.profile-edit-trigger{display:inline-flex;align-items:center;justify-content:center;margin:14px 0 0;padding:10px 14px;border:1px solid rgba(16,173,154,.16);background:rgba(16,173,154,.07);color:#0d8577;border-radius:14px;font:inherit;font-size:12px;font-weight:900;cursor:pointer}
.profile-logout-wrap{margin-top:24px;padding-top:20px;border-top:1px solid rgba(0,0,0,.07);text-align:center}.profile-logout-btn{display:inline-flex;align-items:center;justify-content:center;min-height:54px;width:min(360px,100%);border-radius:18px;text-decoration:none;color:#fff;font-weight:900;background:linear-gradient(135deg,#ff5a52,#d9362e);box-shadow:0 10px 28px rgba(217,54,46,.28),0 0 42px rgba(255,59,48,.12),inset 0 1px 2px rgba(255,255,255,.72),inset 0 -1px 2px rgba(130,20,15,.28)}
@media(max-width:900px){.skills-editor-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:700px){.skills-editor-grid{grid-template-columns:1fr}.skill-editor-actions{grid-template-columns:1fr}.profile-logout-btn{width:100%}}

.profile-footer-note{text-align:center;margin-top:20px;color:#9aa1a8;font-size:11px;line-height:1.8}
@media(max-width:700px){.profile-main{width:min(100% - 16px,900px);margin-top:12px}.profile-hero{padding:20px 18px;gap:14px}.profile-avatar{width:60px;height:60px;flex-basis:60px;border-radius:19px;font-size:24px}.profile-name{font-size:23px}.profile-content{padding:18px 14px}.profile-info-grid{grid-template-columns:1fr}.info-item{padding:14px}.progress-head{align-items:center}.progress-value{font-size:26px}.progress-foot{flex-direction:column;gap:3px}.profile-divider{margin:20px 0}}
</style>
</head>
<body class="user-page profile-page">
<div class="bg-mesh"><div class="blob blob-1"></div><div class="blob blob-2"></div><div class="blob blob-3"></div></div>
<?php require __DIR__ . '/includes/page_loader.php'; ?>
<div class="site-shell">
<?php require __DIR__ . '/includes/site_header.php'; ?>
<main class="profile-main">
<section class="profile-card">
    <header class="profile-hero">
        <div class="profile-avatar" aria-hidden="true"><?= e($initial) ?></div>
        <div>
            <p class="profile-kicker">بخش کاربری</p>
            <h1 class="profile-name"><?= e($fullName) ?></h1>
            <p class="profile-subtitle">اطلاعات ثبت‌نام و وضعیت مسیر مطالعه شما</p>
        </div>
    </header>

    <div class="profile-content">
        <h2 class="profile-section-title">👤 اطلاعات ثبت‌نام</h2>
        <div class="profile-info-grid">
            <div class="info-item"><div class="info-label">نام و نام خانوادگی</div><div class="info-value"><?= e($fullName) ?></div></div>
            <div class="info-item"><div class="info-label">شماره همراه</div><div class="info-value ltr"><?= e((string)($user['phone'] ?? '—')) ?></div></div>
            <div class="info-item"><div class="info-label">محدوده محل سکونت</div><div class="info-value"><?= e((string)($user['location'] ?? '—')) ?></div></div>
            
        </div>

        <div class="profile-divider"></div>
        <h2 class="profile-section-title">🧩 توانمندی‌ها و مهارت‌ها</h2>
        <?php if ($profileMessage): ?><div class="profile-message success"><?= e($profileMessage) ?></div><?php endif; ?>
        <?php if ($profileError): ?><div class="profile-message error"><?= e($profileError) ?></div><?php endif; ?>
        <?php if ($skillLabels): ?>
        <div class="skill-list">
            <?php foreach ($skillLabels as $label): ?><span class="skill-tag"><?= e($label) ?></span><?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="info-item">هنوز توانمندی‌ای برای این حساب ثبت نشده است.</div>
        <?php endif; ?>

        <?php if ($skillsAvailable): ?>
        <button type="button" class="profile-edit-trigger" id="skillsEditorTrigger">✏️ ویرایش یا حذف توانمندی‌ها</button>
        <div class="skills-editor" id="skillsEditor" hidden>
            <form method="post" action="" id="skillsEditorForm">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="profile_action" value="save_skills">
                <div class="skills-editor-grid">
                    <?php foreach ($skillOptions as $option): ?>
                    <label class="skill-edit-option"><input type="checkbox" name="skills[]" value="<?= (int)$option['id'] ?>" data-skill-name="<?= e($option['name']) ?>" <?= in_array((int)$option['id'], $selectedSkillIds, true) ? 'checked' : '' ?>> <span><?= e($option['name']) ?></span></label>
                    <?php endforeach; ?>
                </div>
                <div class="skill-edit-other" id="profileOtherSkillWrap"<?= in_array('سایر', array_map(static fn($o)=>(string)$o['name'],$skillOptions), true) && in_array('سایر', array_map(static fn($s)=>(string)$s['name'],$userSkills), true) ? '' : ' hidden' ?>>
                    <label for="profileOtherSkill">توضیح توانمندی «سایر»</label>
                    <input type="text" name="other_skill" id="profileOtherSkill" value="<?= e($selectedOtherText) ?>" maxlength="255" placeholder="مثلاً: عکاسی، تدوین، ...">
                </div>
                <div class="skill-editor-actions">
                    <button type="submit" class="skill-save-btn">ذخیره تغییرات</button>
                    <button type="button" class="skill-cancel-btn" id="skillsEditorCancel">انصراف</button>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <div class="profile-divider"></div>
        <h2 class="profile-section-title">📚 وضعیت آموزشی</h2>
        <div class="progress-box">
            <?php if ($sessionSystem && $totalSessions > 0): ?>
                <div class="progress-head">
                    <div><p class="progress-title">پیشرفت مسیر مطالعه</p><p class="progress-desc">جلسات تکمیل‌شده و پیشرفت فعلی شما در مسیر مطالعه</p></div>
                    <div class="progress-value"><?= toFaDigits((string)$overallPercent) ?>٪</div>
                </div>
                <div class="profile-track"><div class="profile-fill"></div></div>
                <div class="progress-foot"><span><?= toFaDigits((string)$completedCount) ?> جلسه تکمیل شده</span><span><?= toFaDigits((string)$totalSessions) ?> جلسه فعال</span></div>
                <?php if ($nextSession): ?><div class="next-session">جلسه بعدی برای ادامه مسیر: <strong><?= e((string)$nextSession['title']) ?></strong></div><?php endif; ?>
                <div class="profile-access">وضعیت دسترسی: <strong><?= e($accessTitle) ?></strong></div>
            <?php else: ?>
                <div class="info-item"><?= $sessionSystem ? 'هنوز جلسه فعالی برای نمایش منتشر نشده است.' : 'سامانه جلسات مطالعه هنوز راه‌اندازی نشده است.' ?></div>
            <?php endif; ?>
        </div>

        <div class="profile-logout-wrap"><a href="logout.php" class="profile-logout-btn">🚪 خروج از حساب کاربری</a></div>
        <div class="profile-footer-note">PB v1.0.15</div>
    </div>
</section>
</main>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
</div>
<script>
(function(){
 const trigger=document.getElementById('skillsEditorTrigger');
 const editor=document.getElementById('skillsEditor');
 const cancel=document.getElementById('skillsEditorCancel');
 const otherWrap=document.getElementById('profileOtherSkillWrap');
 if(!trigger||!editor) return;
 const syncOther=()=>{
   const other=[...editor.querySelectorAll('input[type="checkbox"][data-skill-name="سایر"]')][0];
   if(otherWrap) otherWrap.hidden=!(other&&other.checked);
 };
 trigger.addEventListener('click',()=>{editor.hidden=!editor.hidden; syncOther(); if(!editor.hidden) editor.scrollIntoView({behavior:'smooth',block:'nearest'});});
 cancel?.addEventListener('click',()=>{editor.hidden=true;});
 editor.querySelectorAll('input[type="checkbox"]').forEach(el=>el.addEventListener('change',syncOther));
 syncOther();
})();
</script>
<script src="assets/js/app.js?v=20261001-v14" defer></script>
</body>
</html>
