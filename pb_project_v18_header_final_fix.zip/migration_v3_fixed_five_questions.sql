-- ============================================================
-- Migration: fixed 5 exam questions per session
-- سوالات شماره ۱ تا ۵ فعال می‌مانند؛ سوالات شماره بالاتر غیرفعال می‌شوند.
-- اگر یک جلسه کمتر از ۵ سوال فعال دارد، مدیر باید کمبود را تکمیل کند.
-- ============================================================
UPDATE session_questions
SET is_active = CASE WHEN question_number BETWEEN 1 AND 5 THEN 1 ELSE 0 END, updated_at = NOW();

